"""Private reviewed-input runner; public prepare/predict/serve commands do the work.

Adapted from the original 4090 pi05 worker. This module has no launch side effects.
The caller must bind every pending input to actual terminal receipts before launch.
"""
import argparse
import csv
import datetime
import fcntl
import hashlib
import json
import os
import re
import shutil
import signal
import subprocess
import time
import traceback
from pathlib import Path

ROOT = Path("/workspace/ifl_rtx5090_20260916")
PROTOCOL = {"stateless": {"warmup": 5, "measured": 20},
            "history": {"warmup_episodes": 1, "measured_episodes": 6, "cycles_per_episode": 3},
            "pi05_queue_calls": 51}


class CapacityStopped(RuntimeError):
    pass


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            digest.update(block)
    return digest.hexdigest()


def require(condition, message):
    if not condition:
        raise ValueError(message)


def stamp():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def owned_path(value):
    require(isinstance(value, str) and Path(value).is_absolute(), "unbound absolute task path")
    path = Path(value)
    require(path.is_relative_to(ROOT) and ".." not in path.parts, "path outside owned task root")
    return path


def validate_config(config):
    require(config["schema"] == "instinctflash.rtx5090_model_worker_config.v1", "wrong config schema")
    require(config["target"] == {"name": "rtx5090", "capability": [12, 0]}, "wrong target")
    require(config["family"] in {"pi05", "vla4", "vla2", "groot", "va", "edge", "nano", "dreamzero"}, "wrong family")
    require(isinstance(config["source_commit"], str) and re.fullmatch(r"[0-9a-f]{40}", config["source_commit"]), "final source commit must be bound")
    require(config["gpu_uuid"] == "GPU-004614f4-173a-187b-4e67-a2e1799e4d42", "wrong admitted 5090 device")
    for key in ("output", "source_directory", "wheel_directory", "python", "input_cache", "public_assets"):
        owned_path(config[key])
    for key in ("stage_manifest", "bootstrap_completion", "input_completion", "primitive_report"):
        value = config[key]
        owned_path(value["path"])
        require(isinstance(value["sha256"], str) and re.fullmatch(r"[0-9a-f]{64}", value["sha256"]), key + " must bind an actual SHA")
    require(isinstance(config["installed_probe_sha256"], str)
            and re.fullmatch(r"[0-9a-f]{64}", config["installed_probe_sha256"]), "installed probe must be hash-bound")
    require(config["protocol"] == PROTOCOL and config["expected_api_cells"] == 3, "paired protocol changed")
    require(config["serve_arms"] == ["runtime_default", "runtime_selected"], "both WebSocket arms required")
    require(config["cell_timeout_seconds"] == 7200 and config["api_timeout_seconds"] >= 3 * 7200 + 300, "API outer deadline too short")
    require(config["serve_timeout_seconds"] >= 1200 + 6 * 600 + 60, "WebSocket outer deadline too short")
    memory = config["memory"]
    require(type(memory["expected_limit_bytes"]) is int and memory["expected_limit_bytes"] > 4 << 30, "actual cgroup limit must be bound")
    require(memory["reserve_bytes"] == 4 << 30 and memory["sample_seconds"] == 2, "memory guard contract changed")
    for key in ("stat_path", "limit_path", "usage_path"):
        require(isinstance(memory[key], str) and Path(memory[key]).is_absolute()
                and Path(memory[key]).is_relative_to("/sys/fs/cgroup"), "cgroup v1 path must be bound")


def read_bound(config, key):
    reference = config[key]
    require(sha(reference["path"]) == reference["sha256"], key + " changed")
    return json.loads(Path(reference["path"]).read_text())


def validate_bootstrap(bootstrap, config):
    require(bootstrap["status"] == "packages_checked" and bootstrap["family"] == config["family"]
            and bootstrap["deployment_target"] == "rtx5090" and bootstrap["python"] == config["python"]
            and bootstrap["CPU_doctor_passed"] is True and bootstrap["CPU_doctor_deferred"] is False,
            "actual bootstrap/doctor is not complete")
    for label in ("install_source_wheels", "pip_check", "uv_pip_check", "cpu_doctor"):
        rows = [row for row in bootstrap["commands"] if row["label"] == label]
        require(len(rows) == 1 and rows[0]["returncode"] == 0, "bootstrap command not passed: " + label)
        require(sha(rows[0]["log"]) == rows[0]["log_sha256"], "bootstrap command log changed: " + label)


def validate_primitive(primitive, config, stage):
    require(primitive["schema"] == "instinctflash.sm120_fp8_primitive_qualification.v1"
            and primitive["passed"] is True and primitive["device"]["capability"] == [12, 0]
            and primitive["device"]["name"] == "NVIDIA GeForce RTX 5090"
            and primitive["device"]["uuid"].removeprefix("GPU-") == config["gpu_uuid"].removeprefix("GPU-")
            and primitive["runtime"]["torch"] == config["expected_torch_runtime"]
            and primitive["runtime"]["python_executable"] == config["python"]
            and primitive["runtime"]["torch_cuda"] == "13.0"
            and primitive["runtime"]["triton"] == config["expected_distributions"]["triton"]
            and primitive["script_sha256"] == stage["files"]["scripts/qualify_sm120_fp8.py"]["sha256"],
            "actual SM120 primitive differs")
    require(set(primitive["source"]) == {"desktop_fp8.py", "fp8_pack.py", "sm89_fp8.py", "sm120_fp8.py",
                "torch_fp8_linear.py", "module_residency.py", "qualify_sm89_fp8.py"},
            "primitive source inventory incomplete")
    expected = [(1, 16, 16, False), (7, 768, 768, True), (40, 2048, 2048, False),
                (16, 3072, 3072, True), (3, 4096, 1024, False), (7, 5120, 13824, True)]
    require([(row["rows"], row["in_features"], row["out_features"], row["bias"])
             for row in primitive["projections"]] == expected
            and all(row["passed"] is True for row in primitive["projections"])
            and len(primitive["packing"]) > 0 and all(row["passed"] is True for row in primitive["packing"])
            and [row["precision"] for row in primitive["module_residency"]] == ["native", "fp8"]
            and all(row["passed"] is True for row in primitive["module_residency"]),
            "primitive projection/packing/residency coverage incomplete")


def process(pid):
    try:
        raw = Path(f"/proc/{pid}/stat").read_text().rsplit(")", 1)[1].split()
        return {"pid": int(pid), "state": raw[0], "ppid": int(raw[1]),
                "pgrp": int(raw[2]), "start_ticks": raw[19]}
    except (OSError, ValueError, IndexError):
        return None


def memory_value(stat, limit, reserve):
    require("total_rss" in stat and "total_shmem" in stat, "cgroup v1 hierarchical RSS/shmem counters missing")
    value = stat["total_rss"] + stat["total_shmem"]
    return value, value > limit - reserve


class Runner:
    def __init__(self, config, config_path):
        self.config, self.config_path = config, config_path
        self.output = owned_path(config["output"])
        self.child, self.locks, self.identities = None, [], {}
        self.state = {"schema": "instinctflash.rtx5090_model_e2e.v1", "family": config["family"],
            "source_commit": config["source_commit"], "target": config["target"],
            "GPU_uuid": config["gpu_uuid"], "worker_pid": os.getpid(),
            "worker_start_ticks": process(os.getpid())["start_ticks"], "started_at": stamp(),
            "config_sha256": sha(config_path), "worker_sha256": sha(__file__),
            "status": "admission", "passed": False, "stages": [], "automatic_retries": 0,
            "task_quality_validated": False, "minimum_host_RAM_certified": False}

    def write(self, name, value):
        path = self.output / name
        temporary = path.with_suffix(path.suffix + ".tmp")
        temporary.write_text(json.dumps(value, indent=2, sort_keys=True) + "\n")
        temporary.replace(path)

    def save(self):
        self.write("status.json", self.state)

    def descendants(self):
        rows = {int(path.name): info for path in Path("/proc").iterdir()
                if path.name.isdigit() and (info := process(path.name)) is not None}
        if self.child is None:
            return []
        # Known PID/start pairs remain owned if a wrapper exits and they are reparented.
        owned = {pid for pid, ticks in self.identities.items()
                 if pid in rows and rows[pid]["start_ticks"] == ticks}
        changed = True
        while changed:
            additions = {pid for pid, info in rows.items() if info["ppid"] in owned} - owned
            changed = bool(additions)
            owned.update(additions)
        for pid in owned:
            self.identities[pid] = rows[pid]["start_ticks"]
        return [rows[pid] for pid in owned]

    def sample_memory(self):
        contract = self.config["memory"]
        stat = {key: int(value) for key, value in
                (line.split() for line in Path(contract["stat_path"]).read_text().splitlines())}
        limit = int(Path(contract["limit_path"]).read_text())
        require(limit == contract["expected_limit_bytes"], "cgroup memory limit changed")
        nonreclaimable, exceeded = memory_value(stat, limit, contract["reserve_bytes"])
        processes = []
        for info in self.descendants():
            try:
                lines = Path(f"/proc/{info['pid']}/status").read_text().splitlines()
                metrics = {key.rstrip(":"): int(value.split()[0]) * 1024
                    for key, value in (line.split(":", 1) for line in lines if ":" in line)
                    if key in {"VmHWM", "VmRSS", "RssAnon", "RssFile", "RssShmem"}}
                processes.append({**info, **metrics})
            except (OSError, ValueError):
                continue
        sample = {"at": stamp(), "stage": self.state["status"], "cgroup_limit_bytes": limit,
            "cgroup_usage_bytes": int(Path(contract["usage_path"]).read_text()),
            "cgroup_total_rss_bytes": stat["total_rss"], "cgroup_total_shmem_bytes": stat["total_shmem"],
            "cgroup_total_cache_bytes": stat.get("total_cache"), "guard_nonreclaimable_bytes": nonreclaimable,
            "reserve_bytes": contract["reserve_bytes"], "capacity_threshold_exceeded": exceeded,
            "shm_filesystem": {"free_bytes": shutil.disk_usage("/dev/shm").free}, "processes": processes}
        with (self.output / "memory_samples.jsonl").open("a") as stream:
            stream.write(json.dumps(sample, sort_keys=True) + "\n")
        if exceeded:
            self.state["capacity_event"] = sample
            raise CapacityStopped("cgroup total_rss + total_shmem exceeds limit minus 4 GiB; no OOM observed")

    def stop_owned(self):
        if self.child is None:
            return
        targets = self.descendants()
        self.state.setdefault("owned_cleanup", []).append({"at": stamp(), "targets": targets})
        # Every signal is bound to a recorded descendant's still-matching start tick.
        # Kill nested new sessions too: public reproduce/serve own additional process groups.
        for sig in (signal.SIGTERM, signal.SIGKILL):
            for info in reversed(targets):
                live = process(info["pid"])
                if live and live["start_ticks"] == info["start_ticks"] and live["state"] != "Z":
                    try:
                        if live["pgrp"] == info["pid"]:
                            os.killpg(info["pid"], sig)
                        else:
                            os.kill(info["pid"], sig)
                    except ProcessLookupError:
                        pass
            if sig == signal.SIGTERM:
                try:
                    self.child.wait(timeout=15)
                except subprocess.TimeoutExpired:
                    pass
        self.child.wait(timeout=10)
        survivors = [row for row in self.descendants() if row["state"] != "Z"]
        self.state["owned_processes_terminal"] = not survivors
        require(not survivors, "owned stage descendants did not terminate; manual review required")

    def stage(self, name, argv, environment, timeout):
        self.sample_memory()
        row = {"name": name, "command": argv, "started_at": stamp(), "timeout_seconds": timeout}
        self.state["stages"].append(row)
        self.state["status"] = name
        self.save()
        started = time.monotonic()
        log_path = self.output / (name + ".log")
        try:
            with log_path.open("xb") as log:
                self.child = subprocess.Popen(argv, env=environment, cwd=self.output,
                    stdin=subprocess.DEVNULL, stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
                identity = process(self.child.pid)
                require(identity is not None, "stage identity disappeared before binding")
                self.identities = {self.child.pid: identity["start_ticks"]}
                row.update(pid=self.child.pid, start_ticks=identity["start_ticks"])
                self.save()
                while self.child.poll() is None:
                    self.sample_memory()
                    if time.monotonic() - started > timeout:
                        raise TimeoutError("stage deadline exceeded: " + name)
                    try:
                        self.child.wait(timeout=self.config["memory"]["sample_seconds"])
                    except subprocess.TimeoutExpired:
                        pass
                require(self.child.returncode == 0, name + " failed; preserved logs")
                self.stop_owned()  # Do not carry a leftover server or nested capture into another stage.
        except BaseException:
            self.stop_owned()
            raise
        finally:
            row.update(exit_code=None if self.child is None else self.child.poll(),
                       elapsed_seconds=time.monotonic() - started,
                       log_sha256=sha(log_path) if log_path.exists() else None)
            self.save()

    def lock(self, path):
        path.parent.mkdir(parents=True, exist_ok=True)
        stream = path.open("a")
        try:
            fcntl.flock(stream, fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BaseException:
            stream.close()
            raise
        self.locks.append(stream)

    def execute(self):
        config, family = self.config, self.config["family"]
        stage = read_bound(config, "stage_manifest")
        require(stage["schema"] == "instinctflash.public_release_stage.v1"
                and stage["head"] == config["source_commit"] and stage["source_scope"] == "full"
                and stage["status"] in {"wheels_built_and_inspected_CPU_only",
                                        "source_staged_with_original_audited_wheels"}, "final public stage differs")
        source = owned_path(config["source_directory"])
        for relative in ("scripts/prepare_auxiliary_assets.py", "scripts/qualify_sm120_fp8.py",
                         "scripts/qualify_sm89_fp8.py", "release/rtx5090/deployment_profiles.json",
                         "release/vendor/asset_profiles.json", "release/vendor/auxiliary_assets.json",
                         f"release/vendor/rtx5090/{family}/bootstrap.json"):
            require(sha(source / relative) == stage["files"][relative]["sha256"], "staged source changed: " + relative)
        bootstrap = read_bound(config, "bootstrap_completion")
        validate_bootstrap(bootstrap, config)
        require(sha(Path(__file__).with_name("installed_source_probe.py")) == config["installed_probe_sha256"], "private installed-source probe changed")
        inputs = read_bound(config, "input_completion")
        require(inputs["status"] == "complete" and inputs["family"] == family
                and inputs["target"] == "rtx5090" and inputs["cache_dir"] == config["input_cache"]
                and inputs["file_count"] == config["input_file_count"]
                and inputs["total_asset_bytes"] == config["input_total_asset_bytes"]
                and inputs["source_manifest_sha256"] == config["input_source_manifest_sha256"], "original input completion differs")
        primitive = read_bound(config, "primitive_report")
        validate_primitive(primitive, config, stage)
        self.state["admitted_input_hashes"] = {key: config[key]["sha256"] for key in
            ("stage_manifest", "bootstrap_completion", "input_completion", "primitive_report")}
        environment = {key: value for key, value in os.environ.items()
                       if key not in {"PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "CONDA_PREFIX",
                                      "LOAD_TRT_ENGINE", "DYNAMIC_CACHE_SCHEDULE", "NUM_DIT_STEPS"}
                       and not key.startswith(("IFL_", "UV_", "PIP_"))}
        environment.update((bootstrap.get("compiler_preparation") or {}).get("environment", {}))
        profile = json.loads((source / f"release/vendor/rtx5090/{family}/bootstrap.json").read_text())
        if profile.get("root_env"):
            environment[profile["root_env"]] = str(owned_path(bootstrap["vendor"]))
        if family == "dreamzero":
            environment["NO_ALBUMENTATIONS_UPDATE"] = "1"
        environment.update((bootstrap.get("native_tool_preparation") or {}).get("environment", {}))
        environment["PATH"] = str(Path(config["python"]).parent) + os.pathsep + environment.get("PATH", "")
        environment.update(CUDA_VISIBLE_DEVICES="", CUDA_DEVICE_ORDER="PCI_BUS_ID",
            PYTHONDONTWRITEBYTECODE="1", PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1",
            TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1", UV_OFFLINE="1")
        for key, name in {"TRITON_CACHE_DIR": "triton-cache", "TORCHINDUCTOR_CACHE_DIR": "inductor-cache",
                "CUDA_CACHE_PATH": "cuda-cache", "TORCH_EXTENSIONS_DIR": "extensions-cache",
                "XDG_CACHE_HOME": "xdg-cache", "TMPDIR": "tmp"}.items():
            path = self.output / name
            path.mkdir()
            environment[key] = str(path)
        self.lock(ROOT / "host-timing.lock")
        self.stage("installed_source_probe", [config["python"], "-I", "-B",
            str(Path(__file__).with_name("installed_source_probe.py")), str(self.config_path),
            str(self.output / "installed_source.json")], environment, 300)
        installed = json.loads((self.output / "installed_source.json").read_text())
        require(installed["passed"] is True, "installed source proof failed")
        installed_wheels = {row["wheel_sha256"] for row in installed["distributions"].values()}
        require(installed_wheels.issubset({row["sha256"] for row in bootstrap["wheels"]}),
                "bootstrap did not install the admitted public wheels")
        installed_files = {key: value for row in installed["distributions"].values() for key, value in row["files"].items()}
        for name, item in primitive["source"].items():
            relative = "scripts/qualify_sm89_fp8.py" if name == "qualify_sm89_fp8.py" else "instinctflash/runtime/" + name
            expected = stage["files"][relative]["sha256"]
            require(item["sha256"] == expected, "primitive source differs from final stage")
            if relative.startswith("instinctflash/"):
                require(installed_files[relative]["sha256"] == expected, "primitive source differs from installed Runtime")
        assets = owned_path(config["public_assets"])
        self.stage("prepare_public_assets", [config["python"], "-I", str(source / "scripts/prepare_auxiliary_assets.py"),
            "prepare", family, "--include-primary", "--local-files-only", "--materialization", "hardlink",
            "--cache-dir", config["input_cache"], "--root", str(assets)], environment, 1200)
        prepared_assets = json.loads((assets / "completion.json").read_text())
        require(prepared_assets["status"] == "assets_hash_verified", "public assets not verified")
        environment.update(prepared_assets["environment"])
        self.state["assets_completion_sha256"] = sha(assets / "completion.json")
        prepared = self.output / "prepared"
        self.stage("prepare_public_reproduction", [config["python"], "-I", "-m", "benchmarks.regression.reproduce",
            "prepare", "--model", family, "--mode", config["selected_mode"], "--target", "rtx5090",
            "--cache-dir", str(assets / "hf/hub"), "--local-files-only", "--output", str(prepared)], environment, 1200)
        plan = json.loads((prepared / "plan.json").read_text())
        require(plan["target"] == config["target"] and plan["matrix"]["protocol"] == PROTOCOL
                and len(plan["matrix"]["cells"]) == 3, "public full paired plan differs")
        self.lock(ROOT / "gpu-leases" / (config["gpu_uuid"] + ".lock"))
        smi = shutil.which("nvidia-smi")
        require(smi is not None, "nvidia-smi missing from PATH")
        gpu_text = subprocess.check_output([smi, "--query-gpu=uuid,name,memory.used,utilization.gpu",
            "--format=csv,noheader,nounits"], text=True, timeout=30)
        rows = [[cell.strip() for cell in row] for row in csv.reader(gpu_text.splitlines())]
        selected = [row for row in rows if row[0] == config["gpu_uuid"]]
        require(len(selected) == 1 and selected[0][1] == "NVIDIA GeForce RTX 5090"
                and int(selected[0][2]) <= 64 and int(selected[0][3]) == 0, "bound GPU is not idle")
        applications = subprocess.check_output([smi, "--query-compute-apps=gpu_uuid,pid,process_name,used_memory",
            "--format=csv,noheader,nounits"], text=True, timeout=30)
        require(not any(row and row[0].strip() == config["gpu_uuid"] for row in csv.reader(applications.splitlines())), "bound GPU has another process")
        self.state.update(GPU_before_csv=gpu_text, compute_before_csv=applications)
        environment["CUDA_VISIBLE_DEVICES"] = config["gpu_uuid"]
        self.stage("paired_public_api", [config["python"], "-I", "-m", "benchmarks.regression.reproduce", "run",
            "--prepared", str(prepared), "--output", str(self.output / "capture"), "--cell-timeout", "7200"], environment, config["api_timeout_seconds"])
        capture = self.output / "capture/run.json"
        require(json.loads(capture.read_text())["status"] == "passed", "paired capture is not complete")
        self.state["capture_run_sha256"] = sha(capture)
        for arm in config["serve_arms"]:
            cell = family + "-" + arm
            destination = self.output / ("serve_" + cell)
            self.stage("serve_" + cell, [config["python"], "-I", "-m", "benchmarks.regression.serve_smoke",
                "--prepared", str(prepared), "--output", str(destination), "--cell", cell,
                "--startup-timeout", "1200", "--request-timeout", "600"], environment, config["serve_timeout_seconds"])
            receipt = destination / "receipt.json"
            require(json.loads(receipt.read_text())["status"] == "passed", "WebSocket capture incomplete")
            self.state.setdefault("serve_receipts", {})[cell] = {"path": str(receipt), "sha256": sha(receipt)}
        self.state.update(status="complete", passed=True)


def main(config_path):
    config_path = Path(config_path).absolute()
    config = json.loads(config_path.read_text())
    validate_config(config)  # Pending values refuse before output creation or commands.
    runner = Runner(config, config_path)
    runner.output.mkdir(parents=True, exist_ok=False)
    (runner.output / "config.json").write_bytes(config_path.read_bytes())
    def interrupted(number, _frame):
        raise InterruptedError("owned worker received signal " + str(number))
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        runner.save()
        runner.execute()
    except BaseException as error:  # noqa: BLE001 - preserve failures and terminate only owned children.
        runner.state.update(status="capacity_stopped" if isinstance(error, CapacityStopped) else "failed_preserved",
            passed=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        if isinstance(error, CapacityStopped):
            runner.state.update(benchmark_admission="not_measured", partial_measurements_preserved=True,
                                observed_OOM=False, automatic_retries=0)
    finally:
        try:
            runner.stop_owned()
        except BaseException as error:  # noqa: BLE001 - cleanup failure must refuse completion.
            runner.state.update(status="cleanup_failed", passed=False, cleanup_error=str(error))
        for lock in reversed(runner.locks):
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        runner.state.update(lease_released=True, finished_at=stamp(),
            memory_measurement_scope="Process VmHWM and sampled RSS components are distinct from cgroup usage; no minimum-RAM or whole-machine peak claim.")
        samples = runner.output / "memory_samples.jsonl"
        runner.state["memory_samples_sha256"] = sha(samples) if samples.is_file() else None
        runner.save()
        runner.write("completion.json" if runner.state["passed"] else "failure.json", runner.state)
        print(json.dumps(runner.state))
    return 0 if runner.state["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    raise SystemExit(main(parser.parse_args().config))
