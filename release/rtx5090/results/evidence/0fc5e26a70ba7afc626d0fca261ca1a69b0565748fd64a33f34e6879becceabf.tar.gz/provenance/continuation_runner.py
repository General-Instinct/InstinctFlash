"""Continue only two never-started VA WebSockets after a preserved CPU UUID-reader failure."""
import argparse
import csv
import fcntl
import hashlib
import importlib.util
import json
import os
import shutil
import signal
import subprocess
import traceback
from pathlib import Path

ROOT = Path("/workspace/ifl_rtx5090_20260916")
ORIGINAL = ROOT / "va-2v4a-supplement-v1"
OUTPUT = ROOT / "va-2v4a-continuation-v1"
CONTROL = ROOT / "prepared-va-2v4a-continuation-v1"
SOURCE = "0a53125c5af6d76260be96e39077cdcc3c01126d"
WORKER_SHA = "fbd9c063cbcbb49aca1304aa256ab8a85441a39e6fa99afb78c5b94bdfbf2709"
ORIGINAL_WORKER_SHA = "bddbc426143f78ea0b79ca697192de264256bf7f72bf5daa454c1fb6ac187836"
RECIPE_SHA = "93159206a4974b4b756132cf8637e258725008da4978d0ece96dcf332c21b326"
SCOPE = "Reuse three immutable VA 2V/4A API captures; execute only the two never-started WebSocket stages and corrected CPU validation. Original producer remains failed."


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def original_module():
    path = ROOT / "prepared-va-2v4a-supplement-v1/runner.py"
    require(sha(path) == ORIGINAL_WORKER_SHA, "original supplement Runner changed")
    spec = importlib.util.spec_from_file_location("original_va_supplement", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def continuation_gate(config):
    original_config = ROOT / "va-2v4a-launch-v1/va.bound.json"
    require(sha(original_config) == "902a2e45dd1fce42e2bcbca059308f0c351d92c63cdd9e6d0ac61244cf110b03", "original config changed")
    expected = json.loads(original_config.read_text())
    expected.update(output=str(OUTPUT), helper_sha256=RECIPE_SHA, scope=SCOPE,
        continuation={"source_run": str(ORIGINAL), "original_failure_sha256": "c35ad4cf3d9d2364e91703394699c176c513aeb010207e5a0b3b0db46a46c87f",
            "readback_manifest_sha256": "4fb559b2af26700d99a11a66584514c38ae39478b75321034c51aad069f9ce7d",
            "capture_validation_path": str(ROOT / "va-2v4a-cpu-validation-v2/capture_validation.json"),
            "capture_validation_sha256": "1c8caf5dca51466af5212ca8fd31a565c9e9ed038203e5332d40b2d1a7dafda8",
            "cpu_completion_path": str(ROOT / "va-2v4a-cpu-validation-v2/completion.json"),
            "cpu_completion_sha256": "d974a3158170f63d1d69217eb002a06ed4a6f9c0b27251c41b330699a0eb6854"})
    require(config == expected, "continuation must preserve the complete original execution contract")
    require(not os.path.lexists("/proc/75148") and not (ORIGINAL / "completion.json").exists(), "original producer not terminal failed")
    require(sha(ORIGINAL / "failure.json") == expected["continuation"]["original_failure_sha256"], "original failure changed")
    failed = json.loads((ORIGINAL / "failure.json").read_text())
    require(failed["passed"] is False and failed["lease_released"] is True and failed["owned_processes_terminal"] is True
            and failed["worker_pid"] == 75148 and failed["worker_start_ticks"] == "2787820", "original failed identity differs")
    require([r["name"] for r in failed["stages"]] == ["prepare_2v4a-native", "prepare_2v4a-fp8", "admit_2v4a",
        "capture_va-eager_native-2v4a", "capture_va-2v4a-native", "capture_va-2v4a-fp8", "validate_2v4a"]
        and [r["exit_code"] for r in failed["stages"]] == [0, 0, 0, 0, 0, 0, 1], "original stage outcome differs")
    require(not any((ORIGINAL / ("serve_va-" + m)).exists() for m in ("2v4a-native", "2v4a-fp8")), "original WS was already started")
    for name in ("capture_validation", "cpu_completion"):
        require(sha(expected["continuation"][name + "_path"]) == expected["continuation"][name + "_sha256"], "actual corrected CPU gate changed")
    require(sha(CONTROL / "recipe_v2.py") == RECIPE_SHA and sha(CONTROL / "review.json") == config["review_sha256"], "reviewed validator changed")
    return expected["continuation"]


def reused_evidence(config, destination=None):
    manifest_path = CONTROL / "readback_manifest.json"
    require(sha(manifest_path) == config["continuation"]["readback_manifest_sha256"], "original readback inventory changed")
    manifest = json.loads(manifest_path.read_text())
    copied = []
    for row in manifest["files"]:
        parts = Path(row["name"]).parts
        if parts[0] != ORIGINAL.name or parts[1] not in {"prepared_2v4a-native", "prepared_2v4a-fp8", "capture"}:
            continue
        source = ORIGINAL.joinpath(*parts[1:])
        require(str(source) == row["path"] and source.is_file() and not source.is_symlink(), "reused evidence path differs")
        require(source.stat().st_size == row["bytes"] and sha(source) == row["sha256"], "original API/prepared bytes changed")
        if destination is not None:
            target = destination.joinpath(*parts[1:])
            target.parent.mkdir(parents=True, exist_ok=True)
            with target.open("xb") as stream:
                stream.write(source.read_bytes())
            require(sha(target) == sha(source) == row["sha256"], "copied evidence bytes differ")
        copied.append({"source": str(source), "name": str(Path(*parts[1:])), "bytes": row["bytes"], "sha256": row["sha256"]})
    require(sum(r["name"].endswith("receipt.json") for r in copied) == 3
            and sum(r["name"].endswith("receipt.npz") for r in copied) == 3, "all three original API receipts/arrays required")
    return copied


def execute(config, config_path, shared, runner, run, parent, model):
    runner.lock(ROOT / "host-timing.lock")
    stage = shared.read_bound(model, "stage_manifest")
    bootstrap = shared.read_bound(model, "bootstrap_completion")
    shared.validate_bootstrap(bootstrap, model)
    shared.validate_primitive(shared.read_bound(model, "primitive_report"), model, stage)
    assets_path = shared.owned_path(model["public_assets"]) / "completion.json"
    require(sha(assets_path) == parent["assets_completion_sha256"], "parent asset receipt changed")
    assets = json.loads(assets_path.read_text())
    require(assets["status"] == "assets_hash_verified", "parent assets incomplete")
    environment = {key: value for key, value in os.environ.items() if not key.startswith(("IFL_", "UV_", "PIP_"))
        and key not in {"PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "CONDA_PREFIX", "DYNAMIC_CACHE_SCHEDULE", "NUM_DIT_STEPS", "LOAD_TRT_ENGINE", "ENABLE_TENSORRT"}}
    environment.update((bootstrap.get("compiler_preparation") or {}).get("environment", {}))
    environment.update((bootstrap.get("native_tool_preparation") or {}).get("environment", {}))
    environment.update(assets["environment"])
    profile_path = Path(model["source_directory"]) / "release/vendor/rtx5090/va/bootstrap.json"
    require(sha(profile_path) == stage["files"]["release/vendor/rtx5090/va/bootstrap.json"]["sha256"], "VA bootstrap profile changed")
    profile = json.loads(profile_path.read_text())
    require(profile["root_env"] == "LINGBOT_ROOT", "VA vendor environment differs")
    environment[profile["root_env"]] = bootstrap["vendor"]
    environment.update(CUDA_VISIBLE_DEVICES="", CUDA_DEVICE_ORDER="PCI_BUS_ID", PYTHONDONTWRITEBYTECODE="1",
        PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1", ENABLE_TENSORRT="false")
    environment["PATH"] = str(Path(model["python"]).parent) + os.pathsep + environment.get("PATH", "")
    for key, name in {"TRITON_CACHE_DIR": "triton-cache", "TORCHINDUCTOR_CACHE_DIR": "inductor-cache",
                     "CUDA_CACHE_PATH": "cuda-cache", "TORCH_EXTENSIONS_DIR": "extensions-cache",
                     "XDG_CACHE_HOME": "xdg-cache", "TMPDIR": "tmp"}.items():
        path = runner.output / name
        path.mkdir()
        environment[key] = str(path)
    helper = Path(__file__).with_name("recipe_v2.py")
    require(sha(helper) == config["helper_sha256"], "VA recipe helper changed")
    python = model["python"]
    refs = continuation_gate(config)
    copied = reused_evidence(config, runner.output)
    runner.write("reused_api_evidence.json", {"files": copied, "API_recaptured": False, "original_failure_sha256": refs["original_failure_sha256"]})
    shutil.copyfile(refs["capture_validation_path"], runner.output / "validation.json")
    require(sha(runner.output / "validation.json") == refs["capture_validation_sha256"], "CPU validation copy differs")
    base = [python, "-I", str(helper)]
    args = ["--config", str(config_path)]
    runner.lock(ROOT / "gpu-leases" / (config["gpu_uuid"] + ".lock"))
    smi = shutil.which("nvidia-smi")
    require(smi is not None, "nvidia-smi unavailable")
    text = subprocess.check_output([smi, "--query-gpu=uuid,name,memory.used,utilization.gpu", "--format=csv,noheader,nounits"], text=True, timeout=30)
    rows = [[v.strip() for v in row] for row in csv.reader(text.splitlines())]
    selected = [r for r in rows if r[0] == config["gpu_uuid"]]
    require(len(selected) == 1 and selected[0][1] == "NVIDIA GeForce RTX 5090"
            and int(selected[0][2]) <= 64 and int(selected[0][3]) == 0, "bound GPU not idle")
    apps = subprocess.check_output([smi, "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader,nounits"], text=True, timeout=30)
    require(not any(r and r[0].strip() == config["gpu_uuid"] for r in csv.reader(apps.splitlines())), "another GPU process is active")
    runner.state.update(GPU_before_csv=text, compute_before_csv=apps)
    for mode in ("2v4a-native", "2v4a-fp8"):
        cell_id = "va-" + mode
        command = [python, "-I", "-m", "benchmarks.regression.serve_smoke", "--prepared",
            str(runner.output / ("prepared_" + mode)), "--cell", cell_id, "--output", str(runner.output / ("serve_" + cell_id)),
            "--startup-timeout", "1200", "--request-timeout", "600"]
        if mode == "2v4a-native":
            command += ["--seed", "9173"]
        runner.stage("serve_" + cell_id, command, dict(environment, CUDA_VISIBLE_DEVICES=config["gpu_uuid"]), config["timeouts"]["serve"])
    runner.stage("validate_serve", [*base, "serve", *args, "--output", str(runner.output / "serve_validation.json")],
                 environment, config["timeouts"]["validate"])
    original_module().parent_gate(config, shared)
    continuation_gate(config)
    reused_evidence(config)
    require(sha(assets_path) == parent["assets_completion_sha256"], "original public asset receipt changed")
    runner.state.update(status="completed_missing_websockets_only", passed=True, reused_api_cells=config["cell_ids"],
        newly_captured_api_cells=[], newly_completed_serve_cells=config["cell_ids"][1:], original_producer_remains_failed=True,
        matched_baseline=config["cell_ids"][0], validation_sha256=sha(runner.output / "validation.json"),
        serve_validation_sha256=sha(runner.output / "serve_validation.json"))

def main(config_path):
    config_path = Path(config_path).resolve(strict=True)
    config = json.loads(config_path.read_text())
    refs = continuation_gate(config)
    previous = original_module()
    shared = previous.load_worker(config)
    run, parent, model = previous.parent_gate(config, shared)
    require(config["timeouts"] == {"prepare": 1200, "admit": 300, "capture": 7200, "validate": 300, "serve": 6000}, "reviewed stage bounds changed")
    execution = dict(model, output=config["output"], selected_mode="2v4a-native")
    runner = shared.Runner(execution, config_path)
    runner.state.update(schema="instinctflash.rtx5090_va_2v4a_continuation.v1", mode="2v4a",
        worker_sha256=sha(__file__), shared_runner_sha256=WORKER_SHA,
        parent_completion_sha256=config["parent"]["completion_sha256"], parent_run=str(run),
        primary_baselines_recaptured=False, supplemental_api_cells=0, reused_api_cells=config["cell_ids"], supplemental_serve_cells=2,
        continuation=refs, original_worker={"pid": 75148, "start_ticks": "2787820", "exited": True, "passed": False},
        original_worker_sha256=ORIGINAL_WORKER_SHA, corrected_recipe_sha256=RECIPE_SHA)
    runner.output.mkdir(parents=True, exist_ok=False)
    (runner.output / "config.json").write_bytes(config_path.read_bytes())
    (runner.output / "parent_config.json").write_bytes((run / "config.json").read_bytes())
    (runner.output / "parent_completion.json").write_bytes((run / "completion.json").read_bytes())
    (runner.output / "original_failure.json").write_bytes((ORIGINAL / "failure.json").read_bytes())
    def interrupted(number, _frame):
        raise InterruptedError("supplement received signal " + str(number))
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        runner.save()
        execute(config, config_path, shared, runner, run, parent, model)
    except BaseException as error:  # noqa: BLE001 - preserve all failures; no retries.
        runner.state.update(status="capacity_stopped" if isinstance(error, shared.CapacityStopped) else "failed_preserved",
            passed=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        if isinstance(error, shared.CapacityStopped):
            runner.state.update(benchmark_admission="not_measured", partial_measurements_preserved=True, observed_OOM=False)
    finally:
        try:
            runner.stop_owned()
        except BaseException as error:  # noqa: BLE001 - cleanup failure refuses success.
            runner.state.update(status="cleanup_failed", passed=False, cleanup_error=str(error))
        for lock in reversed(runner.locks):
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        runner.state.update(lease_released=True, finished_at=shared.stamp())
        samples = runner.output / "memory_samples.jsonl"
        runner.state["memory_samples_sha256"] = sha(samples) if samples.is_file() else None
        runner.save()
        runner.write("completion.json" if runner.state["passed"] else "failure.json", runner.state)
    return 0 if runner.state["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    raise SystemExit(main(parser.parse_args().config))
