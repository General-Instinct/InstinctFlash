"""Three-cell VA 2V/4A supplement using the unchanged first-model Runner."""
import argparse
import csv
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import shutil
import signal
import subprocess
import traceback
from pathlib import Path

ROOT = Path("/workspace/ifl_rtx5090_20260916")
SOURCE = "0a53125c5af6d76260be96e39077cdcc3c01126d"
WORKER_SHA = "fbd9c063cbcbb49aca1304aa256ab8a85441a39e6fa99afb78c5b94bdfbf2709"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def load_worker(config):
    require(config["schema"] == "instinctflash.rtx5090_va_2v4a_supplement_config.v1"
            and config["family"] == "va" and config["mode"] == "2v4a"
            and config["source_commit"] == SOURCE and config["serving_seed"] == 9173,
            "only the reviewed VA 2V/4A scope is prepared")
    ref = config["shared_worker"]
    require(ref["sha256"] == WORKER_SHA and sha(ref["path"]) == WORKER_SHA, "shared Runner changed")
    spec = importlib.util.spec_from_file_location("owned_primary_runner", ref["path"])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parent_gate(config, shared):
    parent = config["parent"]
    for key in ("completion_sha256", "config_sha256", "capture_run_sha256", "installed_source_sha256"):
        require(isinstance(parent[key], str) and re.fullmatch(r"[0-9a-f]{64}", parent[key]), "actual parent hashes are pending")
    require(type(parent["worker_pid"]) is int and parent["worker_pid"] > 1
            and isinstance(parent["worker_start_ticks"], str) and parent["worker_start_ticks"].isdigit(), "parent PID/start pending")
    run = shared.owned_path(parent["run"])
    require(not (run / "failure.json").exists(), "parent has conflicting failure evidence")
    require(not os.path.lexists(f"/proc/{parent['worker_pid']}"), "parent producer still exists")
    require(sha(run / "completion.json") == parent["completion_sha256"], "parent terminal changed")
    done = json.loads((run / "completion.json").read_text())
    require(done["passed"] is True and done["status"] == "complete" and done["lease_released"] is True
            and done["owned_processes_terminal"] is True and done["worker_sha256"] == WORKER_SHA
            and done["worker_pid"] == parent["worker_pid"] and done["worker_start_ticks"] == parent["worker_start_ticks"]
            and done["source_commit"] == SOURCE and done["family"] == "va"
            and done["target"] == config["target"] and done["GPU_uuid"] == config["gpu_uuid"], "parent not fully passed/bound")
    require(sha(run / "config.json") == done["config_sha256"] == parent["config_sha256"], "parent config changed")
    model = json.loads((run / "config.json").read_text())
    shared.validate_config(model)
    require(model["output"] == str(run) and model["source_commit"] == SOURCE and model["family"] == "va"
            and model["expected_api_cells"] == 3 and model["selected_mode"] == "fp8", "parent main scope differs")
    require(sha(run / "capture/run.json") == done["capture_run_sha256"] == parent["capture_run_sha256"], "parent raw capture changed")
    capture = json.loads((run / "capture/run.json").read_text())
    require(capture["status"] == "passed" and len(capture["attempts"]) == 3
            and all(r["exit_code"] == 0 and not r["timed_out"] for r in capture["attempts"]), "parent three cells not complete")
    require(set(parent["cell_receipts"]) == {"va-eager_native", "va-runtime_default", "va-runtime_selected"},
            "all parent raw cells must be bound")
    for cell, expected in parent["cell_receipts"].items():
        require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected), "parent cell hashes pending")
        path = run / "capture/cells" / cell / "receipt.json"
        require(sha(path) == expected, "parent raw cell receipt changed")
        receipt = json.loads(path.read_text())
        require(receipt["ok"] is True and sha(path.with_suffix(".npz")) == receipt["actions_sha256"], "parent raw actions changed")
        for source_path, source_sha in receipt["sources"].items():
            require(sha(source_path) == source_sha, "parent measured source changed")
    require(set(done["serve_receipts"]) == {"va-runtime_default", "va-runtime_selected"}, "parent serving arms incomplete")
    for cell, ref in done["serve_receipts"].items():
        path = run / ("serve_" + cell) / "receipt.json"
        require(ref["path"] == str(path) and sha(path) == ref["sha256"], "parent serving changed")
        record = json.loads(path.read_text())
        require(record["status"] == "passed" and record["server_exit_code"] == 0 and len(record["calls"]) == 6, "parent serving incomplete")
        require(sha(path.with_name("actions.npz")) == record["action_archive_sha256"], "parent serving actions changed")
    require(sha(run / "installed_source.json") == parent["installed_source_sha256"], "parent installed proof changed")
    installed = json.loads((run / "installed_source.json").read_text())
    require(installed["passed"] is True, "parent public source proof failed")
    for distribution in installed["distributions"].values():
        for item in distribution["files"].values():
            require(sha(item["path"]) == item["sha256"], "installed public source changed after parent")
    return run, done, model



def execute(config, config_path, shared, runner, run, parent, model):
    runner.lock(ROOT / "host-timing.lock")
    stage = shared.read_bound(model, "stage_manifest")
    bootstrap = shared.read_bound(model, "bootstrap_completion")
    shared.validate_bootstrap(bootstrap, model)
    shared.validate_primitive(shared.read_bound(model, "primitive_report"), model, stage)
    assets_path = shared.owned_path(model["public_assets"]) / "completion.json"
    require(sha(assets_path) == parent["assets_completion_sha256"], "parent asset receipt changed")
    assets = json.loads(assets_path.read_text())
    require(assets["status"] == "assets_hash_verified", "parent assets incomplete")
    environment = {key: value for key, value in os.environ.items() if not key.startswith(("IFL_", "UV_", "PIP_"))
        and key not in {"PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "CONDA_PREFIX", "DYNAMIC_CACHE_SCHEDULE", "NUM_DIT_STEPS", "LOAD_TRT_ENGINE", "ENABLE_TENSORRT"}}
    environment.update((bootstrap.get("compiler_preparation") or {}).get("environment", {}))
    environment.update((bootstrap.get("native_tool_preparation") or {}).get("environment", {}))
    environment.update(assets["environment"])
    profile_path = Path(model["source_directory"]) / "release/vendor/rtx5090/va/bootstrap.json"
    require(sha(profile_path) == stage["files"]["release/vendor/rtx5090/va/bootstrap.json"]["sha256"], "VA bootstrap profile changed")
    profile = json.loads(profile_path.read_text())
    require(profile["root_env"] == "LINGBOT_ROOT", "VA vendor environment differs")
    environment[profile["root_env"]] = bootstrap["vendor"]
    environment.update(CUDA_VISIBLE_DEVICES="", CUDA_DEVICE_ORDER="PCI_BUS_ID", PYTHONDONTWRITEBYTECODE="1",
        PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1", ENABLE_TENSORRT="false")
    environment["PATH"] = str(Path(model["python"]).parent) + os.pathsep + environment.get("PATH", "")
    for key, name in {"TRITON_CACHE_DIR": "triton-cache", "TORCHINDUCTOR_CACHE_DIR": "inductor-cache",
                     "CUDA_CACHE_PATH": "cuda-cache", "TORCH_EXTENSIONS_DIR": "extensions-cache",
                     "XDG_CACHE_HOME": "xdg-cache", "TMPDIR": "tmp"}.items():
        path = runner.output / name
        path.mkdir()
        environment[key] = str(path)
    helper = Path(__file__).with_name("recipe.py")
    require(sha(helper) == config["helper_sha256"], "VA recipe helper changed")
    python = model["python"]
    for mode in ("2v4a-native", "2v4a-fp8"):
        runner.stage("prepare_" + mode, [python, "-I", "-m", "benchmarks.regression.reproduce", "prepare",
            "--model", "va", "--mode", mode, "--target", "rtx5090", "--cache-dir", str(assets_path.parent / "hf/hub"),
            "--local-files-only", "--output", str(runner.output / ("prepared_" + mode))], environment, config["timeouts"]["prepare"])
    base = [python, "-I", str(helper)]
    args = ["--config", str(config_path)]
    admission = runner.output / "admission.json"
    runner.stage("admit_2v4a", [*base, "admit", *args, "--output", str(admission)], environment, config["timeouts"]["admit"])
    prepared = runner.output / "prepared_2v4a-native"
    capture = runner.output / "capture"
    destination = capture / "inputs/recorded_inputs_v1.npz"
    destination.parent.mkdir()
    destination.write_bytes((prepared / "inputs/recorded_inputs_v1.npz").read_bytes())
    matrix = json.loads((capture / "matrix.json").read_text())
    require([cell["id"] for cell in matrix["cells"]] == config["cell_ids"], "three-cell sequence differs")
    deltas = json.loads(admission.read_text())["environment_deltas"]
    runner.lock(ROOT / "gpu-leases" / (config["gpu_uuid"] + ".lock"))
    smi = shutil.which("nvidia-smi")
    require(smi is not None, "nvidia-smi unavailable")
    text = subprocess.check_output([smi, "--query-gpu=uuid,name,memory.used,utilization.gpu", "--format=csv,noheader,nounits"], text=True, timeout=30)
    rows = [[v.strip() for v in row] for row in csv.reader(text.splitlines())]
    selected = [r for r in rows if r[0] == config["gpu_uuid"]]
    require(len(selected) == 1 and selected[0][1] == "NVIDIA GeForce RTX 5090"
            and int(selected[0][2]) <= 64 and int(selected[0][3]) == 0, "bound GPU not idle")
    apps = subprocess.check_output([smi, "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader,nounits"], text=True, timeout=30)
    require(not any(r and r[0].strip() == config["gpu_uuid"] for r in csv.reader(apps.splitlines())), "another GPU process is active")
    runner.state.update(GPU_before_csv=text, compute_before_csv=apps)
    for cell in matrix["cells"]:
        cell_environment = dict(environment)
        for key in deltas[cell["id"]]["remove"]:
            cell_environment.pop(key, None)
        cell_environment.update(deltas[cell["id"]]["set"])
        cell_environment["CUDA_VISIBLE_DEVICES"] = config["gpu_uuid"]
        runner.stage("capture_" + cell["id"], [python, "-I", "-m", "benchmarks.regression.user_e2e",
            "--matrix", str(capture / "matrix.json"), "--cell", cell["id"], "--output-root", str(capture),
            "--fixture", str(destination)], cell_environment, config["timeouts"]["capture"])
    runner.stage("validate_2v4a", [*base, "capture", *args, "--output", str(runner.output / "validation.json")],
                 environment, config["timeouts"]["validate"])
    for mode in ("2v4a-native", "2v4a-fp8"):
        cell_id = "va-" + mode
        command = [python, "-I", "-m", "benchmarks.regression.serve_smoke", "--prepared",
            str(runner.output / ("prepared_" + mode)), "--cell", cell_id, "--output", str(runner.output / ("serve_" + cell_id)),
            "--startup-timeout", "1200", "--request-timeout", "600"]
        if mode == "2v4a-native":
            command += ["--seed", "9173"]
        runner.stage("serve_" + cell_id, command, dict(environment, CUDA_VISIBLE_DEVICES=config["gpu_uuid"]), config["timeouts"]["serve"])
    runner.stage("validate_serve", [*base, "serve", *args, "--output", str(runner.output / "serve_validation.json")],
                 environment, config["timeouts"]["validate"])
    parent_gate(config, shared)
    require(sha(assets_path) == parent["assets_completion_sha256"], "original public asset receipt changed")
    runner.state.update(status="completed_supplement_only", passed=True, captured_cells=config["cell_ids"],
        matched_baseline=config["cell_ids"][0], validation_sha256=sha(runner.output / "validation.json"),
        serve_validation_sha256=sha(runner.output / "serve_validation.json"))

def main(config_path):
    config_path = Path(config_path).resolve(strict=True)
    config = json.loads(config_path.read_text())
    shared = load_worker(config)
    run, parent, model = parent_gate(config, shared)
    require(config["timeouts"] == {"prepare": 1200, "admit": 300, "capture": 7200, "validate": 300, "serve": 6000}, "reviewed stage bounds changed")
    execution = dict(model, output=config["output"], selected_mode="2v4a-native")
    runner = shared.Runner(execution, config_path)
    runner.state.update(schema="instinctflash.rtx5090_va_2v4a_supplement.v1", mode="2v4a",
        worker_sha256=sha(__file__), shared_runner_sha256=WORKER_SHA,
        parent_completion_sha256=config["parent"]["completion_sha256"], parent_run=str(run),
        primary_baselines_recaptured=False, supplemental_api_cells=3, supplemental_serve_cells=2)
    runner.output.mkdir(parents=True, exist_ok=False)
    (runner.output / "config.json").write_bytes(config_path.read_bytes())
    (runner.output / "parent_config.json").write_bytes((run / "config.json").read_bytes())
    (runner.output / "parent_completion.json").write_bytes((run / "completion.json").read_bytes())
    def interrupted(number, _frame):
        raise InterruptedError("supplement received signal " + str(number))
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        runner.save()
        execute(config, config_path, shared, runner, run, parent, model)
    except BaseException as error:  # noqa: BLE001 - preserve all failures; no retries.
        runner.state.update(status="capacity_stopped" if isinstance(error, shared.CapacityStopped) else "failed_preserved",
            passed=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        if isinstance(error, shared.CapacityStopped):
            runner.state.update(benchmark_admission="not_measured", partial_measurements_preserved=True, observed_OOM=False)
    finally:
        try:
            runner.stop_owned()
        except BaseException as error:  # noqa: BLE001 - cleanup failure refuses success.
            runner.state.update(status="cleanup_failed", passed=False, cleanup_error=str(error))
        for lock in reversed(runner.locks):
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        runner.state.update(lease_released=True, finished_at=shared.stamp())
        samples = runner.output / "memory_samples.jsonl"
        runner.state["memory_samples_sha256"] = sha(samples) if samples.is_file() else None
        runner.save()
        runner.write("completion.json" if runner.state["passed"] else "failure.json", runner.state)
    return 0 if runner.state["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    raise SystemExit(main(parser.parse_args().config))
