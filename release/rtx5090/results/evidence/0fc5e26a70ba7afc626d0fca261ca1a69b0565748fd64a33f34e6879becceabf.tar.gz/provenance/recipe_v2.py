"""Three fresh, matched-schedule VA cells from the two public operating points."""
import argparse
import hashlib
import json
import os
from copy import deepcopy
from pathlib import Path
from uuid import UUID

TARGET = {"name": "rtx5090", "capability": [12, 0]}
NFE = {"video": 2, "action": 4}
DEFAULT = {"video": 25, "action": 50}
IDS = ("va-eager_native-2v4a", "va-2v4a-native", "va-2v4a-fp8")


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical_gpu_uuid(value):
    require(isinstance(value, str), "GPU UUID must be a string")
    return UUID(value.removeprefix("GPU-"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    with Path(path).open("x") as stream:
        json.dump(value, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write("\n")


def matrix_from_plans(native_plan, fp8_plan):
    require(native_plan["model"] == fp8_plan["model"] == "va"
            and native_plan["target"] == fp8_plan["target"] == TARGET, "wrong public target/family")
    require(native_plan["execution_mode"] == "2v4a-native"
            and fp8_plan["execution_mode"] == "2v4a-fp8", "wrong operating point")
    for key in ("checkpoint", "fixture_sha256", "profiles_sha256"):
        require(native_plan[key] == fp8_plan[key], "two prepared public inputs differ")
    require(native_plan["matrix"]["cells"][:3] == fp8_plan["matrix"]["cells"][:3], "public full baseline differs")
    native = deepcopy(native_plan["matrix"]["cells"][0])
    runtimes = [deepcopy(plan["matrix"]["cells"][-1]) for plan in (native_plan, fp8_plan)]
    require(native["arm"] == "eager_native" and native["effective_schedule"]["nfe"] == DEFAULT,
            "original upstream declaration differs")
    for cell, identifier, precision in zip(runtimes, IDS[1:], ("native", "fp8")):
        require(cell["id"] == identifier and cell["effective_schedule"]["nfe"] == NFE
                and cell["expected_runtime_kwargs"]["precision"] == precision, "wrong public operating point")
    native.update(id=IDS[0], receipt=f"cells/{IDS[0]}/receipt.json", native_nfe=dict(NFE),
                  effective_schedule=deepcopy(runtimes[0]["effective_schedule"]), experimental=True)
    cells = [native, *runtimes]
    for cell in cells:
        # These are only comparison/declaration fields; all Runtime options stay public.
        cell.update(default_schedule=dict(DEFAULT), comparison_group="va-2v4a-matched")
        cell.pop("comparison_baseline", None)
        cell.pop("cross_policy_baseline", None)
    matrix = deepcopy(native_plan["matrix"])
    matrix.update(cells=cells, expected_main_cells=1, expected_operating_point_cells=2,
                  supplementary_only=True, publication_ready=False, quality_certified=False,
                  matched_baseline=IDS[0], parent_full_schedule_recaptured=False)
    return matrix


def run(args):
    from benchmarks.regression.reproduce import child_environment, validate_bundle

    config = json.loads(args.config.read_text())
    root = Path(config["output"])
    parent = Path(config["parent"]["run"])
    review_path = Path(__file__).with_name("review.json")
    require(sha(review_path) == config["review_sha256"], "reviewed recipe changed")
    review = json.loads(review_path.read_text())
    plans, preparations = {}, {}
    for mode in ("2v4a-native", "2v4a-fp8"):
        plans[mode], preparations[mode] = validate_bundle(root / ("prepared_" + mode))
        require(plans[mode] == review["public_plans"][mode], "installed public plan differs from reviewed source")
    matrix = matrix_from_plans(plans["2v4a-native"], plans["2v4a-fp8"])
    require(matrix == review["matrix"], "supplemental matrix differs")
    original, original_preparation = validate_bundle(parent / "prepared")
    require(original == review["parent_public_plan"], "full-schedule parent plan differs")
    for mode, plan in plans.items():
        require(plan["fixture_sha256"] == original["fixture_sha256"]
                and plan["checkpoint"] == original["checkpoint"]
                and plan["matrix"]["protocol"] == original["matrix"]["protocol"]
                and preparations[mode]["checkpoint_snapshot"] == original_preparation["checkpoint_snapshot"],
                "parent/reduced input or history protocol differs")
    if args.phase == "admit":
        output = root / "capture"
        output.mkdir()
        write(output / "matrix.json", matrix)
        environments = {}
        for cell in matrix["cells"]:
            mode = "2v4a-fp8" if cell["id"] == IDS[2] else "2v4a-native"
            environment = child_environment(plans[mode], cell, preparations[mode])
            environments[cell["id"]] = {"remove": sorted(set(os.environ) - set(environment)),
                "set": {key: value for key, value in environment.items() if os.environ.get(key) != value}}
        result = {"status": "passed", "matrix_sha256": sha(output / "matrix.json"),
                  "review_sha256": sha(review_path), "environment_deltas": environments,
                  "parent_plan_sha256": sha(parent / "prepared/plan.json"),
                  "public_plan_sha256": {m: sha(root / ("prepared_" + m) / "plan.json") for m in plans}}
        write(root / "capture/recipe_binding.json", {k: v for k, v in result.items() if k != "environment_deltas"})
    else:
        result = validate(root, parent, matrix, review, config, plans, args.phase)
    write(args.output, result)


def validate(root, parent, matrix, review, config, plans, phase):
    import numpy as np
    from benchmarks.regression.hardware import validate_device_receipt

    from benchmarks.regression.serve_smoke import validate_metadata
    from benchmarks.regression.user_report import _action_difference, _validate_cell

    capture = root / "capture"
    require(json.loads((capture / "matrix.json").read_text()) == matrix, "actual capture matrix changed")
    parent_native = json.loads((parent / "capture/cells/va-eager_native/receipt.json").read_text())
    rows, evidence, raw = [], [], []
    for cell in matrix["cells"]:
        path = capture / cell["receipt"]
        receipt = json.loads(path.read_text())
        row, detail = _validate_cell(cell, capture, require_observed_schedule=True)
        require(receipt["matrix_sha256"] == sha(capture / "matrix.json")
                and receipt["input_archive_sha256"] == review["fixture_sha256"], "raw input binding differs")
        require(receipt["cases"] == review["request_cases"] == parent_native["cases"], "paired request/RNG/history differs")
        require(receipt["observed_nfe_before"] == receipt["observed_nfe_after"] == NFE
                and receipt["default_schedule"] == DEFAULT, "actual reduced schedule differs")
        require(receipt["guidance"] == parent_native["guidance"]
                and receipt["torch"] == parent_native["torch"], "parent CFG/runtime stack differs")
        validate_device_receipt(receipt["hardware"], TARGET)
        require(canonical_gpu_uuid(receipt["hardware"]["uuid"]) == canonical_gpu_uuid(config["gpu_uuid"]) and receipt["target"] == TARGET,
                "different bound GPU/target")
        for path_string, digest in receipt["sources"].items():
            require(sha(path_string) == digest, "loaded source changed")
        if cell["arm"] == "eager_native":
            require(receipt["native_nfe_override"] == NFE and receipt["execution_policy"]["native_nfe_override"] == NFE,
                    "upstream native schedule override missing")
            require(not receipt.get("e4m3_tensors") and not receipt["applied_passes"], "native baseline contains optimizer state")
        else:
            require(receipt["precision"] == cell["expected_runtime_kwargs"]["precision"], "precision differs")
            require(bool(receipt.get("e4m3_tensors")) == (receipt["precision"] == "fp8"), "actual FP8 tensor declaration differs")
        require(detail["primary_indices"] == [i for i in range(3, 21) if i % 3], "continuation timing scope differs")
        rows.append(row)
        evidence.append(detail)
        raw.append(receipt)
    comparisons = {}
    for index in (1, 2):
        comparisons[IDS[index]] = {"baseline": IDS[0],
            "ratio_of_p50": rows[0]["primary"]["p50_ms"] / rows[index]["primary"]["p50_ms"],
            "actions": _action_difference(evidence[0]["actions"], evidence[index]["actions"])}
    result = {"status": "passed_recorded_input_protocol_and_latency", "quality_certified": False,
        "matrix_sha256": sha(capture / "matrix.json"), "matched_baseline": IDS[0],
        "default_checkpoint_nfe": DEFAULT, "matched_effective_nfe": NFE, "cells": rows,
        "matched_schedule_comparisons": comparisons,
        "actual_numeric_environment": {cell: record["numeric_environment"] for cell, record in zip(IDS, raw)},
        "parent_full_schedule_recaptured": False, "primary_samples_per_cell": 12, "total_calls_per_cell": 21}
    if phase == "serve":
        serving = {}
        for cell in matrix["cells"][1:]:
            mode = "2v4a-native" if cell["id"] == IDS[1] else "2v4a-fp8"
            directory = root / ("serve_" + cell["id"])
            record = json.loads((directory / "receipt.json").read_text())
            require(record["status"] == "passed" and record["server_exit_code"] == 0
                    and record["cell_id"] == cell["id"] and record["target"] == TARGET
                    and record["fixture_sha256"] == review["fixture_sha256"]
                    and record["plan_sha256"] == sha(root / ("prepared_" + mode) / "plan.json"), "WebSocket binding differs")
            require(record["seed"] == (9173 if mode == "2v4a-native" else None), "public serving seed contract differs")
            require([{k: c[k] for k in ("episode", "cycle", "request_sha256")} for c in record["calls"]]
                    == review["serve_request_cases"], "WebSocket history/reset/input differs")
            validate_device_receipt(record["hardware"], TARGET)
            require(canonical_gpu_uuid(record["hardware"]["uuid"]) == canonical_gpu_uuid(config["gpu_uuid"]), "WebSocket GPU differs")
            public_cell = plans[mode]["matrix"]["cells"][-1]
            validate_metadata(record["metadata"], public_cell)
            require(sha(directory / "actions.npz") == record["action_archive_sha256"], "WebSocket actions changed")
            with np.load(directory / "actions.npz", allow_pickle=False) as values:
                require(values["actions"].shape == (6, 16, 2, 16) and np.isfinite(values["actions"]).all(), "WebSocket arrays incomplete")
            serving[cell["id"]] = {"path": str(directory / "receipt.json"), "sha256": sha(directory / "receipt.json"),
                                  "calls": 6, "rng_scope": record["rng_scope"]}
        result["serve_receipts"] = serving
    return result


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("admit", "capture", "serve"))
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args())
