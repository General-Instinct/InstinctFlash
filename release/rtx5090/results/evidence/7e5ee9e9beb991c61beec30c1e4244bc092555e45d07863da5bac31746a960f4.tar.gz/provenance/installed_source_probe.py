"""Read installed distribution bytes with stdlib only; never import model code."""
import hashlib
import json
import pathlib
import sys
import zipfile
from importlib import metadata


def sha(path):
    h = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def main(config_path, output):
    config = json.loads(pathlib.Path(config_path).read_text())
    manifest = json.loads(pathlib.Path(config["stage_manifest"]["path"]).read_text())
    versions = {name: metadata.version(name) for name in config["expected_distributions"]}
    if versions != config["expected_distributions"]:
        raise ValueError("installed dependency distribution versions differ")
    result = {"passed": False, "python": sys.executable, "python_version": sys.version,
              "prefix": sys.prefix, "dependency_distributions": versions,
              "distributions": {}, "GPU_used": False, "model_imported": False}
    prefix = pathlib.Path(sys.prefix).resolve()
    for name in config["public_distributions"]:
        candidates = [row for row in manifest["wheels"]
                      if row["inspection"]["distribution"].replace("_", "-").lower() == name]
        if len(candidates) != 1:
            raise ValueError("public distribution wheel is not uniquely bound")
        row = candidates[0]
        wheel = pathlib.Path(config["wheel_directory"]) / pathlib.Path(row["path"]).name
        if sha(wheel) != row["sha256"] or wheel.stat().st_size != row["bytes"]:
            raise ValueError("public wheel changed")
        installed = metadata.distribution(name)
        if installed.version != row["inspection"]["version"]:
            raise ValueError("installed public distribution version differs")
        checked = {}
        with zipfile.ZipFile(wheel) as archive:
            for member in archive.namelist():
                relative = pathlib.PurePosixPath(member)
                if relative.is_absolute() or ".." in relative.parts:
                    raise ValueError("unsafe public wheel member")
                if ".dist-info/" in member:
                    continue  # Installer RECORD/direct_url additions are not inference bytes.
                path = pathlib.Path(installed.locate_file(member)).resolve()
                if not path.is_relative_to(prefix) or not path.is_file():
                    raise ValueError("installed public code is outside the bound environment")
                expected = hashlib.sha256(archive.read(member)).hexdigest()
                staged_relative = str(pathlib.PurePosixPath(manifest["packages"][name][0]) / relative)
                staged = pathlib.Path(config["source_directory"]) / staged_relative
                if (manifest["files"][staged_relative]["sha256"] != expected
                        or sha(staged) != expected):
                    raise ValueError("final staged source differs from wheel payload: " + member)
                if sha(path) != expected:
                    raise ValueError("installed public source differs from the built wheel: " + member)
                checked[member] = {"sha256": expected, "path": str(path), "staged_relative": staged_relative}
        if not checked:
            raise ValueError("empty installed public source inventory")
        result["distributions"][name] = {"version": installed.version,
            "wheel_sha256": row["sha256"], "files": checked}
    result["passed"] = True
    with pathlib.Path(output).open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    main(*sys.argv[1:])
