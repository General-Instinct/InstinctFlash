"""Single EDGE NUMERIC supplement using the unchanged first-model Runner."""
import argparse
import csv
import fcntl
import hashlib
import importlib.util
import json
import os
import re
import shutil
import signal
import subprocess
import traceback
from pathlib import Path

ROOT = Path("/workspace/ifl_rtx5090_20260916")
SOURCE = "0a53125c5af6d76260be96e39077cdcc3c01126d"
WORKER_SHA = "fbd9c063cbcbb49aca1304aa256ab8a85441a39e6fa99afb78c5b94bdfbf2709"


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def load_worker(config):
    require(config["schema"] == "instinctflash.rtx5090_numeric_supplement_config.v1"
            and config["family"] == "edge" and config["mode"] == "numeric"
            and config["source_commit"] == SOURCE and config["serving_seed"] == 9173,
            "only the reviewed EDGE numeric scope is prepared")
    ref = config["shared_worker"]
    require(ref["sha256"] == WORKER_SHA and sha(ref["path"]) == WORKER_SHA, "shared Runner changed")
    spec = importlib.util.spec_from_file_location("owned_primary_runner", ref["path"])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def parent_gate(config, shared):
    parent = config["parent"]
    for key in ("completion_sha256", "config_sha256", "capture_run_sha256", "installed_source_sha256"):
        require(isinstance(parent[key], str) and re.fullmatch(r"[0-9a-f]{64}", parent[key]), "actual parent hashes are pending")
    require(type(parent["worker_pid"]) is int and parent["worker_pid"] > 1
            and isinstance(parent["worker_start_ticks"], str) and parent["worker_start_ticks"].isdigit(), "parent PID/start pending")
    run = shared.owned_path(parent["run"])
    require(not (run / "failure.json").exists(), "parent has conflicting failure evidence")
    require(not os.path.lexists(f"/proc/{parent['worker_pid']}"), "parent producer still exists")
    require(sha(run / "completion.json") == parent["completion_sha256"], "parent terminal changed")
    done = json.loads((run / "completion.json").read_text())
    require(done["passed"] is True and done["status"] == "complete" and done["lease_released"] is True
            and done["owned_processes_terminal"] is True and done["worker_sha256"] == WORKER_SHA
            and done["worker_pid"] == parent["worker_pid"] and done["worker_start_ticks"] == parent["worker_start_ticks"]
            and done["source_commit"] == SOURCE and done["family"] == "edge"
            and done["target"] == config["target"] and done["GPU_uuid"] == config["gpu_uuid"], "parent not fully passed/bound")
    require(sha(run / "config.json") == done["config_sha256"] == parent["config_sha256"], "parent config changed")
    model = json.loads((run / "config.json").read_text())
    shared.validate_config(model)
    require(model["output"] == str(run) and model["source_commit"] == SOURCE and model["family"] == "edge"
            and model["expected_api_cells"] == 3 and model["selected_mode"] == "fp8", "parent main scope differs")
    require(sha(run / "capture/run.json") == done["capture_run_sha256"] == parent["capture_run_sha256"], "parent raw capture changed")
    capture = json.loads((run / "capture/run.json").read_text())
    require(capture["status"] == "passed" and len(capture["attempts"]) == 3
            and all(r["exit_code"] == 0 and not r["timed_out"] for r in capture["attempts"]), "parent three cells not complete")
    require(set(parent["cell_receipts"]) == {"edge-eager_native", "edge-runtime_default", "edge-runtime_selected"},
            "all parent raw cells must be bound")
    for cell, expected in parent["cell_receipts"].items():
        require(isinstance(expected, str) and re.fullmatch(r"[0-9a-f]{64}", expected), "parent cell hashes pending")
        path = run / "capture/cells" / cell / "receipt.json"
        require(sha(path) == expected, "parent raw cell receipt changed")
        receipt = json.loads(path.read_text())
        require(receipt["ok"] is True and sha(path.with_suffix(".npz")) == receipt["actions_sha256"], "parent raw actions changed")
        for source_path, source_sha in receipt["sources"].items():
            require(sha(source_path) == source_sha, "parent measured source changed")
    require(set(done["serve_receipts"]) == {"edge-runtime_default", "edge-runtime_selected"}, "parent serving arms incomplete")
    for cell, ref in done["serve_receipts"].items():
        path = run / ("serve_" + cell) / "receipt.json"
        require(ref["path"] == str(path) and sha(path) == ref["sha256"], "parent serving changed")
        record = json.loads(path.read_text())
        require(record["status"] == "passed" and record["server_exit_code"] == 0 and len(record["calls"]) == 6, "parent serving incomplete")
        require(sha(path.with_name("actions.npz")) == record["action_archive_sha256"], "parent serving actions changed")
    require(sha(run / "installed_source.json") == parent["installed_source_sha256"], "parent installed proof changed")
    installed = json.loads((run / "installed_source.json").read_text())
    require(installed["passed"] is True, "parent public source proof failed")
    for distribution in installed["distributions"].values():
        for item in distribution["files"].values():
            require(sha(item["path"]) == item["sha256"], "installed public source changed after parent")
    return run, done, model


def execute(config, config_path, shared, runner, run, parent, model):
    runner.lock(ROOT / "host-timing.lock")
    stage = shared.read_bound(model, "stage_manifest")
    bootstrap = shared.read_bound(model, "bootstrap_completion")
    shared.validate_bootstrap(bootstrap, model)
    shared.validate_primitive(shared.read_bound(model, "primitive_report"), model, stage)
    asset_path = shared.owned_path(model["public_assets"]) / "completion.json"
    require(sha(asset_path) == parent["assets_completion_sha256"], "parent asset receipt changed")
    assets = json.loads(asset_path.read_text())
    require(assets["status"] == "assets_hash_verified", "parent assets incomplete")
    environment = {key: value for key, value in os.environ.items() if not key.startswith(("IFL_", "UV_", "PIP_"))
        and key not in {"PYTHONPATH", "PYTHONHOME", "VIRTUAL_ENV", "CONDA_PREFIX", "DYNAMIC_CACHE_SCHEDULE", "NUM_DIT_STEPS", "LOAD_TRT_ENGINE", "ENABLE_TENSORRT"}}
    environment.update((bootstrap.get("compiler_preparation") or {}).get("environment", {}))
    environment.update((bootstrap.get("native_tool_preparation") or {}).get("environment", {}))
    environment.update(assets["environment"])
    profile_relative = "release/vendor/rtx5090/edge/bootstrap.json"
    profile_path = Path(model["source_directory"]) / profile_relative
    require(sha(profile_path) == stage["files"][profile_relative]["sha256"], "family profile changed")
    profile = json.loads(profile_path.read_text())
    require(profile["root_env"] is None and profile["target"]["python_minor"] == "3.13",
            "Cosmos vendor root/interpreter contract differs")
    native_tool = bootstrap.get("native_tool_preparation")
    require(isinstance(native_tool, dict) and native_tool["status"] == "tool_packages_checked_offline_reuse_passed"
            and native_tool["environment"]["UV_OFFLINE"] == "1", "parent Cosmos native HF tool was not prepared")
    require(model["expected_torch_runtime"] == "2.10.0+cu130"
            and model["expected_distributions"]["torch"] == "2.10.0+cu130", "wrong Cosmos Torch family environment")
    environment.update(CUDA_VISIBLE_DEVICES="", CUDA_DEVICE_ORDER="PCI_BUS_ID", PYTHONDONTWRITEBYTECODE="1",
        PYTHONNOUSERSITE="1", HF_HUB_OFFLINE="1", TRANSFORMERS_OFFLINE="1", HF_DATASETS_OFFLINE="1", ENABLE_TENSORRT="false")
    environment["PATH"] = str(Path(model["python"]).parent) + os.pathsep + environment.get("PATH", "")
    for key, name in {"TRITON_CACHE_DIR": "triton-cache", "TORCHINDUCTOR_CACHE_DIR": "inductor-cache",
                     "CUDA_CACHE_PATH": "cuda-cache", "TORCH_EXTENSIONS_DIR": "extensions-cache",
                     "XDG_CACHE_HOME": "xdg-cache", "TMPDIR": "tmp"}.items():
        path = runner.output / name
        path.mkdir()
        environment[key] = str(path)
    prepared = runner.output / "prepared"
    helper = Path(__file__).with_name("selected.py")
    require(sha(helper) == config["helper_sha256"], "supplement admission helper changed")
    python = model["python"]
    runner.stage("prepare_numeric", [python, "-I", "-m", "benchmarks.regression.reproduce", "prepare",
        "--model", "edge", "--mode", "numeric", "--target", "rtx5090", "--cache-dir", str(asset_path.parent / "hf/hub"),
        "--local-files-only", "--output", str(prepared)], environment, config["timeouts"]["prepare"])
    base = [python, "-I", str(helper)]
    args = ["--config", str(config_path), "--prepared", str(prepared)]
    admission = runner.output / "admission.json"
    runner.stage("admit_numeric", [*base, "admit", *args, "--output", str(admission)], environment, config["timeouts"]["admit"])
    delta = json.loads(admission.read_text())["environment_delta"]
    for key in delta["remove"]:
        environment.pop(key, None)
    environment.update(delta["set"])
    capture = runner.output / "capture"
    capture.mkdir()
    for relative in ("plan.json", "matrix.json", "profiles.json", "preparation.json", "inputs/recorded_inputs_v1.npz"):
        destination = capture / relative
        destination.parent.mkdir(parents=True, exist_ok=True)
        destination.write_bytes((prepared / relative).read_bytes())
    runner.lock(ROOT / "gpu-leases" / (config["gpu_uuid"] + ".lock"))
    smi = shutil.which("nvidia-smi")
    require(smi is not None, "nvidia-smi unavailable")
    text = subprocess.check_output([smi, "--query-gpu=uuid,name,memory.used,utilization.gpu", "--format=csv,noheader,nounits"], text=True, timeout=30)
    rows = [[v.strip() for v in row] for row in csv.reader(text.splitlines())]
    selected = [r for r in rows if r[0] == config["gpu_uuid"]]
    require(len(selected) == 1 and selected[0][1] == "NVIDIA GeForce RTX 5090"
            and int(selected[0][2]) <= 64 and int(selected[0][3]) == 0, "bound GPU not idle")
    apps = subprocess.check_output([smi, "--query-compute-apps=gpu_uuid,pid", "--format=csv,noheader,nounits"], text=True, timeout=30)
    require(not any(r and r[0].strip() == config["gpu_uuid"] for r in csv.reader(apps.splitlines())), "another GPU process is active")
    runner.state.update(GPU_before_csv=text, compute_before_csv=apps)
    environment["CUDA_VISIBLE_DEVICES"] = config["gpu_uuid"]
    runner.stage("capture_numeric", [python, "-I", "-m", "benchmarks.regression.user_e2e", "--matrix", str(capture / "matrix.json"),
        "--cell", config["cell_id"], "--output-root", str(capture), "--fixture", str(prepared / "inputs/recorded_inputs_v1.npz")],
        environment, config["timeouts"]["capture"])
    cpu = dict(environment, CUDA_VISIBLE_DEVICES="")
    runner.stage("validate_numeric", [*base, "capture", *args, "--output", str(runner.output / "validation.json")], cpu, config["timeouts"]["validate"])
    runner.stage("serve_numeric", [python, "-I", "-m", "benchmarks.regression.serve_smoke", "--prepared", str(prepared),
        "--cell", config["cell_id"], "--output", str(runner.output / "serve"), "--seed", "9173",
        "--startup-timeout", "1200", "--request-timeout", "600"], environment, config["timeouts"]["serve"])
    runner.stage("validate_serve", [*base, "serve", *args, "--output", str(runner.output / "serve_validation.json")], cpu, config["timeouts"]["validate"])
    require(sha(run / "completion.json") == config["parent"]["completion_sha256"], "parent terminal changed during supplement")
    require(sha(asset_path) == parent["assets_completion_sha256"], "asset receipt changed during supplement")
    parent_gate(config, shared)  # Recheck original raw hashes after the separate numeric stages.
    runner.state.update(status="completed_supplement_only", passed=True, captured_cells=[config["cell_id"]],
        validation_sha256=sha(runner.output / "validation.json"), serve_validation_sha256=sha(runner.output / "serve_validation.json"))


def main(config_path):
    config_path = Path(config_path).resolve(strict=True)
    config = json.loads(config_path.read_text())
    shared = load_worker(config)
    run, parent, model = parent_gate(config, shared)
    require(config["timeouts"] == {"prepare": 1200, "admit": 300, "capture": 7200, "validate": 300, "serve": 6000}, "reviewed stage bounds changed")
    execution = dict(model, output=config["output"], selected_mode="numeric")
    runner = shared.Runner(execution, config_path)
    runner.state.update(schema="instinctflash.rtx5090_numeric_supplement.v1", mode="numeric",
        worker_sha256=sha(__file__), shared_runner_sha256=WORKER_SHA,
        parent_completion_sha256=config["parent"]["completion_sha256"], parent_run=str(run),
        primary_baselines_recaptured=False, full_public_run_completed=False,
        supplemental_api_cells=1, supplemental_serve_cells=1)
    runner.output.mkdir(parents=True, exist_ok=False)
    (runner.output / "config.json").write_bytes(config_path.read_bytes())
    (runner.output / "parent_config.json").write_bytes((run / "config.json").read_bytes())
    (runner.output / "parent_completion.json").write_bytes((run / "completion.json").read_bytes())
    def interrupted(number, _frame):
        raise InterruptedError("supplement received signal " + str(number))
    signal.signal(signal.SIGTERM, interrupted)
    signal.signal(signal.SIGINT, interrupted)
    try:
        runner.save()
        execute(config, config_path, shared, runner, run, parent, model)
    except BaseException as error:  # noqa: BLE001 - preserve all failures; no retries.
        runner.state.update(status="capacity_stopped" if isinstance(error, shared.CapacityStopped) else "failed_preserved",
            passed=False, error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
        if isinstance(error, shared.CapacityStopped):
            runner.state.update(benchmark_admission="not_measured", partial_measurements_preserved=True, observed_OOM=False)
    finally:
        try:
            runner.stop_owned()
        except BaseException as error:  # noqa: BLE001 - cleanup failure refuses success.
            runner.state.update(status="cleanup_failed", passed=False, cleanup_error=str(error))
        for lock in reversed(runner.locks):
            fcntl.flock(lock, fcntl.LOCK_UN)
            lock.close()
        runner.state.update(lease_released=True, finished_at=shared.stamp())
        samples = runner.output / "memory_samples.jsonl"
        runner.state["memory_samples_sha256"] = sha(samples) if samples.is_file() else None
        runner.save()
        runner.write("completion.json" if runner.state["passed"] else "failure.json", runner.state)
    return 0 if runner.state["passed"] else 1


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--config", required=True)
    raise SystemExit(main(parser.parse_args().config))
