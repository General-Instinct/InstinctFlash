"""CPU admission/validation for one original public numeric capture."""
import argparse
import ast
import hashlib
import json
import os
import uuid
from pathlib import Path


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def canonical_uuid(value):
    return uuid.UUID(value.removeprefix("GPU-"))


def run(args):
    from benchmarks.regression.reproduce import child_environment, validate_bundle

    config = json.loads(args.config.read_text())
    parent = Path(config["parent"]["run"])
    plan, preparation = validate_bundle(args.prepared)
    expected_path = Path(__file__).with_name("edge.expected_plan.json")
    require(sha(expected_path) == config["expected_plan_sha256"], "reviewed numeric plan changed")
    require(plan == json.loads(expected_path.read_text()), "actual installed numeric plan differs")
    original_plan, original_preparation = validate_bundle(parent / "prepared")
    require(original_plan["target"] == plan["target"] == config["target"]
            and original_plan["checkpoint"] == plan["checkpoint"]
            and original_plan["fixture_sha256"] == plan["fixture_sha256"]
            and original_plan["matrix"]["protocol"] == plan["matrix"]["protocol"], "parent inputs/checkpoint/protocol differ")
    require(original_plan["matrix"]["cells"][:2] == plan["matrix"]["cells"][:2], "parent baseline computation differs")
    require(original_preparation["checkpoint_snapshot"] == preparation["checkpoint_snapshot"], "different checkpoint bytes path")
    require(len(plan["matrix"]["cells"]) == 3, "numeric preparation must retain original three-cell plan")
    cell = next(c for c in plan["matrix"]["cells"] if c["id"] == config["cell_id"])
    require(cell["arm"] == "runtime_selected" and cell["expected_runtime_kwargs"]["precision"] == "native"
            and cell["expected_runtime_kwargs"]["tier_ceiling"] == "numeric", "wrong numerical execution selection")
    result = {"status": "passed", "scope": "single supplemental cell only", "mode": "numeric",
              "cell_id": cell["id"], "plan_sha256": sha(args.prepared / "plan.json"),
              "parent_plan_sha256": sha(parent / "prepared/plan.json"), "task_quality_validated": False}
    if args.phase == "admit":
        environment = child_environment(plan, cell, preparation)
        result["environment_delta"] = {
            "remove": sorted(set(os.environ) - set(environment)),
            "set": {key: value for key, value in environment.items() if os.environ.get(key) != value}}
    else:
        import numpy as np

        root = args.prepared.parent
        path = root / "capture" / cell["receipt"]
        receipt = json.loads(path.read_text())
        require(receipt["ok"] is True and receipt["target"] == plan["target"]
                and receipt["runtime_kwargs"] == cell["expected_runtime_kwargs"]
                and receipt["optimizer_environment"] == cell["expected_optimizer_environment"]
                and receipt["effective_schedule"] == cell["effective_schedule"]
                and receipt["precision"] == "native", "actual numeric receipt differs")
        require(receipt["matrix_sha256"] == sha(root / "capture/matrix.json")
                and receipt["input_archive_sha256"] == plan["fixture_sha256"], "numeric input binding differs")
        archive = path.with_suffix(".npz")
        require(sha(archive) == receipt["actions_sha256"], "numeric action archive changed")
        with np.load(archive, allow_pickle=False) as values:
            actions = values["actions"]
            require(list(actions.shape) == [25, *cell["action_shape"]] and actions.dtype.kind == "f"
                    and np.isfinite(actions).all(), "numeric action array incomplete or nonfinite")
        require(len(receipt["calls"]) == len(receipt["cases"]) == 25
                and all(np.isfinite(row["ms"]) and row["ms"] > 0 for row in receipt["calls"]), "numeric calls incomplete")
        require(receipt["observed_nfe_before"] == receipt["observed_nfe_after"] == {"prefix": 1, "action": 4}
                and all(type(value) is int for value in receipt["observed_nfe_before"].values())
                and receipt["default_schedule"] == {"prefix": 1, "action": 4}
                and ast.literal_eval(receipt["guidance"]) == {"action": "cfg"}, "loaded Cosmos schedule/guidance differs")
        require(receipt["torch"] == "2.10.0+cu130" and not receipt.get("e4m3_tensors"),
                "NUMERIC must retain the original Torch/native precision contract")
        policy = receipt["execution_policy"]
        require(policy["precision"] == "native" and policy["tier_ceiling"] == "numeric"
                and policy["nfe"] == {"prefix": 1, "action": 4} and not policy["changed_schedule"]
                and not policy["schedule_options"] and policy.get("step_cache") is None
                and policy["category"] in ("BITEXACT", "NUMERIC")
                and policy["transform_tier"] in ("BITEXACT", "NUMERIC"), "Cosmos NUMERIC permission/schedule changed")
        from benchmarks.regression.hardware import validate_device_receipt
        validate_device_receipt(receipt["hardware"], config["target"])
        require(canonical_uuid(receipt["hardware"]["uuid"]) == canonical_uuid(config["gpu_uuid"]), "different bound Cosmos device")
        for source_path, source_sha in receipt["sources"].items():
            require(sha(source_path) == source_sha, "loaded source changed")
        parent_receipts = {}
        parent_flags = []
        for parent_cell in original_plan["matrix"]["cells"]:
            source_path = parent / "capture" / parent_cell["receipt"]
            original = json.loads(source_path.read_text())
            require(original["ok"] is True and receipt["cases"] == original["cases"], "paired original requests/RNG differ")
            require(original["guidance"] == receipt["guidance"] and original["torch"] == receipt["torch"]
                    and original["effective_schedule"] == receipt["effective_schedule"], "parent same-grid bindings differ")
            flags = original["numeric_environment"]
            require(set(flags) == {"matmul_tf32", "cudnn_tf32", "cudnn_benchmark"}
                    and all(type(value) is bool for value in flags.values()), "parent numeric flags incomplete")
            parent_flags.append(flags)
            parent_receipts[parent_cell["id"]] = sha(source_path)
        require(all(flags == parent_flags[0] for flags in parent_flags)
                and receipt["numeric_environment"] == parent_flags[0], "actual parent/candidate numeric flags differ")
        result.update(receipt_sha256=sha(path), actions_sha256=sha(archive), all_25_finite=True,
                      parent_receipts=parent_receipts, actual_numeric_environment=receipt["numeric_environment"])
        if args.phase == "serve":
            directory = root / "serve"
            serving = json.loads((directory / "receipt.json").read_text())
            require(serving["status"] == "passed" and serving["server_exit_code"] == 0
                    and serving["cell_id"] == cell["id"] and len(serving["calls"]) == 6
                    and serving["plan_sha256"] == sha(args.prepared / "plan.json")
                    and serving["target"] == plan["target"], "supplemental serving incomplete")
            from benchmarks.regression.serve_smoke import validate_metadata
            validate_metadata(serving["metadata"], cell)
            validate_device_receipt(serving["hardware"], config["target"])
            require(canonical_uuid(serving["hardware"]["uuid"]) == canonical_uuid(config["gpu_uuid"]) and serving["seed"] == 9173,
                    "NUMERIC WebSocket device/constructor seed differs")
            require(sha(directory / "actions.npz") == serving["action_archive_sha256"], "serving actions changed")
            with np.load(directory / "actions.npz", allow_pickle=False) as values:
                require(list(values["actions"].shape) == [6, *cell["action_shape"]]
                        and np.isfinite(values["actions"]).all(), "serving actions incomplete/nonfinite")
            result.update(serve_receipt_sha256=sha(directory / "receipt.json"), serve_calls=6,
                          serving_rng_scope=serving["rng_scope"])
    with args.output.open("x") as stream:
        json.dump(result, stream, indent=2, sort_keys=True)
        stream.write("\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("phase", choices=("admit", "capture", "serve"))
    parser.add_argument("--config", type=Path, required=True)
    parser.add_argument("--prepared", type=Path, required=True)
    parser.add_argument("--output", type=Path, required=True)
    run(parser.parse_args())
