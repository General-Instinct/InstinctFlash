"""Bounded installed-package, original-checkpoint RTX 4090 qualification worker."""
import csv
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ROOT = Path('/workspace/ifl_rtx4090_20260916')
GPU = 'GPU-34f3da96-a7b2-ed04-c766-05e7862d940c'


def utc():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def sha(path):
    digest = hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda: handle.read(4 << 20), b''):
            digest.update(chunk)
    return digest.hexdigest()


def require(value, message):
    if not value:
        raise ValueError(message)


def validate_inputs(config, inputs):
    require(inputs['status'] == 'complete', 'Original input assembly not complete')
    require(inputs['file_count'] == config['input_files'], 'Original file inventory differs')
    require(inputs['total_asset_bytes'] == config['input_bytes'], 'Original asset size differs')
    require(inputs['cache_dir'] == str(Path(config['inputs']) / 'hf/hub'), 'Unexpected original cache path')
    require(inputs['whole_file_copies'] == 0, 'Expected verified original hardlink assembly')


def validate_hardware(gpu_csv, processes):
    selected = [row for row in csv.reader(gpu_csv.splitlines()) if row[1].strip() == GPU]
    require(len(selected) == 1, 'Expected one explicitly selected GPU')
    require(selected[0][2].strip() == 'NVIDIA GeForce RTX 4090', 'Expected actual RTX 4090')
    require(int(selected[0][3]) <= 64 and int(selected[0][4]) == 0, 'Selected GPU is busy')
    require(GPU not in processes, 'Selected GPU has a compute process')


def run(config):
    out = Path(config['output'])
    source = Path(config['source'])
    family_root = Path(config['family_root'])
    inputs_root = Path(config['inputs'])
    assets_root = Path(config['assets'])
    python = str(family_root / 'env/bin/python')
    state = {'schema': 'instinctflash.rtx4090_family_pipeline.v1', 'family': config['family'],
             'worker_pid': os.getpid(), 'started_at': utc(), 'config_sha256': sha(out / 'config.json'),
             'source_commit': config['source_commit'], 'status': 'waiting_install_and_original_inputs',
             'automatic_retries': 0, 'task_quality_validated': False, 'GPU_uuid': GPU, 'stages': []}
    locks = []
    child = None

    def save():
        temporary = out / 'status.tmp'
        temporary.write_text(json.dumps(state, indent=2) + '\n')
        temporary.replace(out / 'status.json')

    def query(args):
        return subprocess.check_output(args, text=True, timeout=30).strip()

    def wait_file(path, failure, timeout):
        deadline = time.monotonic() + timeout
        while not path.is_file():
            require(not failure.is_file(), 'A prerequisite failed: ' + str(failure))
            if time.monotonic() > deadline:
                raise TimeoutError('Bounded prerequisite wait expired: ' + str(path))
            state['updated_at'] = utc()
            save()
            time.sleep(5)
        return json.loads(path.read_text())

    def acquire(path):
        path.parent.mkdir(parents=True, exist_ok=True)
        handle = path.open('a')
        deadline = time.monotonic() + 14400
        try:
            while True:
                try:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    locks.append(handle)
                    return
                except BlockingIOError:
                    if time.monotonic() > deadline:
                        raise TimeoutError('Owned lease wait expired: ' + str(path))
                    state['status'] = 'waiting_lease'
                    state['waiting_lease'] = str(path)
                    state['updated_at'] = utc()
                    save()
                    time.sleep(5)
        except BaseException:
            handle.close()
            raise

    def stage(name, args, env, timeout):
        nonlocal child
        row = {'name': name, 'command': args, 'started_at': utc(), 'timeout_seconds': timeout}
        state['stages'].append(row)
        state['status'] = name
        save()
        started = time.monotonic()
        log_path = out / (name + '.log')
        with log_path.open('xb') as log:
            child = subprocess.Popen(args, cwd=out, env=env, stdin=subprocess.DEVNULL,
                                     stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
            row['pid'] = child.pid
            save()
            code = child.wait(timeout=timeout)
        row.update(exit_code=code, elapsed_seconds=time.monotonic()-started,
                   log_sha256=sha(log_path), finished_at=utc())
        save()
        require(code == 0, name + ' failed; preserved log: ' + str(log_path))

    try:
        save()
        require(query(['git', '-C', str(source), 'rev-parse', 'HEAD']) == config['source_commit'], 'Source commit changed')
        installed = wait_file(family_root / 'completion.json', family_root / 'failure.json', 14400)
        require(installed['CPU_doctor_passed'] is True, 'Family CPU doctor did not pass')
        require(installed['deployment_target'] == 'rtx4090', 'Wrong installed deployment target')
        require(installed['family'] == config['family'], 'Wrong installed model family')
        state['bootstrap_completion_sha256'] = sha(family_root / 'completion.json')
        inputs = wait_file(inputs_root / 'completion.json', inputs_root / 'failure.json', 14400)
        validate_inputs(config, inputs)
        state['native_inputs_completion_sha256'] = sha(inputs_root / 'completion.json')
        env = {k: v for k, v in os.environ.items() if k not in ('PYTHONPATH', 'PYTHONHOME')
               and not k.startswith(('IFL_', 'UV_', 'PIP_'))}
        compiler = installed.get('compiler_preparation')
        if compiler:
            env.update(compiler['environment'])
        profile = json.loads((source / 'release/vendor/rtx4090' / config['family'] / 'bootstrap.json').read_text())
        if profile['root_env']:
            env[profile['root_env']] = installed['vendor']
        if config['family'] == 'dreamzero':
            env['NO_ALBUMENTATIONS_UPDATE'] = '1'
        env.update(CUDA_VISIBLE_DEVICES='', CUDA_DEVICE_ORDER='PCI_BUS_ID', PYTHONDONTWRITEBYTECODE='1',
                   PYTHONNOUSERSITE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1')
        for key, name in {'TRITON_CACHE_DIR': 'triton-cache', 'TORCHINDUCTOR_CACHE_DIR': 'inductor-cache',
                          'CUDA_CACHE_PATH': 'cuda-cache', 'TORCH_EXTENSIONS_DIR': 'extensions-cache',
                          'XDG_CACHE_HOME': 'xdg-cache', 'TMPDIR': 'tmp'}.items():
            folder = out / name
            folder.mkdir()
            env[key] = str(folder)
        stage('prepare_public_assets', [python, '-I', str(source / 'scripts/prepare_auxiliary_assets.py'),
              'prepare', config['family'], '--include-primary', '--local-files-only', '--materialization',
              'hardlink', '--cache-dir', inputs['cache_dir'], '--root', str(assets_root)], env, 1200)
        assets = json.loads((assets_root / 'completion.json').read_text())
        require(assets['status'] == 'assets_hash_verified', 'Public asset helper did not verify exact files')
        env.update(assets['environment'])
        state['assets_completion_sha256'] = sha(assets_root / 'completion.json')
        args = [python, '-I', '-m', 'benchmarks.regression.reproduce', 'prepare', '--model', config['family'],
                '--mode', config['mode'], '--target', 'rtx4090', '--cache-dir', str(assets_root / 'hf/hub'),
                '--local-files-only', '--output', str(out / 'prepared')]
        for extra in config['extra_modes']:
            args += ['--extra-mode', extra]
        stage('prepare_public_reproduction', args, env, 1200)
        plan = json.loads((out / 'prepared/plan.json').read_text())
        require(plan['checkpoint'] == config['checkpoint'], 'Prepared checkpoint differs from frozen original')
        state['plan_sha256'] = sha(out / 'prepared/plan.json')
        # New installers use this same host lease. It excludes installation I/O from timed cells.
        acquire(ROOT / 'host-timing.lock')
        acquire(Path('/tmp/ifl-robolab-renderer-gpu0.lock'))
        acquire(ROOT / 'gpu-leases' / (GPU + '.lock'))
        gpu_csv = query(['nvidia-smi', '--query-gpu=index,uuid,name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'])
        processes = query(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory', '--format=csv,noheader,nounits'])
        validate_hardware(gpu_csv, processes)
        state.update(GPU_before_csv=gpu_csv, compute_before_csv=processes)
        env['CUDA_VISIBLE_DEVICES'] = GPU
        stage('paired_public_api', [python, '-I', '-m', 'benchmarks.regression.reproduce', 'run',
              '--prepared', str(out / 'prepared'), '--output', str(out / 'capture'), '--cell-timeout', '7200'],
              env, 7200 * len(plan['matrix']['cells']) + 900)
        captured = json.loads((out / 'capture/run.json').read_text())
        require(captured['status'] == 'passed', 'Paired public API capture did not pass')
        state['capture_run_sha256'] = sha(out / 'capture/run.json')
        for cell in config['serving_cells']:
            stage('serve_' + cell, [python, '-I', '-m', 'benchmarks.regression.serve_smoke', '--prepared',
                  str(out / 'prepared'), '--output', str(out / ('serve_' + cell)), '--cell', cell,
                  '--startup-timeout', '1800', '--request-timeout', '1200'], env, 10000)
            receipt = out / ('serve_' + cell) / 'receipt.json'
            require(json.loads(receipt.read_text())['status'] == 'passed', 'WebSocket smoke failed')
            state.setdefault('serving_receipts', {})[cell] = sha(receipt)
        state.update(status='complete', passed=True)
    except BaseException as error:
        state.update(status='failed_preserved', passed=False, error_type=type(error).__name__,
                     error=str(error), traceback=traceback.format_exc())
    finally:
        if child is not None and child.poll() is None:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=15)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait()
        for handle in reversed(locks):
            fcntl.flock(handle, fcntl.LOCK_UN)
            handle.close()
        state.update(lease_released=True, finished_at=utc())
        save()
        final_path = out / ('completion.json' if state['passed'] else 'failure.json')
        with final_path.open('x') as handle:
            handle.write(json.dumps(state, indent=2) + '\n')
        print(json.dumps(state), flush=True)
    return 0 if state['passed'] else 1


if __name__ == '__main__':
    sys.exit(run(json.loads(Path(sys.argv[1]).read_text())))
