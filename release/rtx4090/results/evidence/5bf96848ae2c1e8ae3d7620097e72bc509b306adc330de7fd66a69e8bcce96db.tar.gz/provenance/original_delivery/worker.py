"""Bounded original Edge/Nano asset delivery on the replacement 4090 host; CPU only."""
import concurrent.futures as cf
import datetime
import errno
import hashlib
import json
import os
import re
from pathlib import Path
import socket
import sys
import threading
import time
import urllib.error
import urllib.request
import urllib.parse

CONTROL = Path(__file__).resolve().parent
PLAN = json.loads((CONTROL / "plan.json").read_bytes())
ROOT = Path(PLAN["checkpoint_root"])
assert ROOT == Path("/tmp/ifl_rtx4090_580_20260916/checkpoints")
assert CONTROL == Path("/workspace/ifl_rtx4090_580_20260916/original_delivery_v1")
OBJECTS = ROOT / ".original-objects-v1"
START = time.monotonic()
DEADLINE = START + PLAN["overall_timeout_seconds"]
LOCK = threading.Lock()
STOP = threading.Event()
PROGRESS = {}
VERIFIED = {}
FAMILIES = {}
ERRORS = []


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def digest(path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        while data := f.read(1024 * 1024):
            h.update(data)
    return h.hexdigest()


def save(path, value):
    tmp = path.with_name(path.name + ".tmp")
    with tmp.open("w") as f:
        json.dump(value, f, sort_keys=True, indent=2)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def update(key, **values):
    with LOCK:
        PROGRESS.setdefault(key, {}).update(values)


def retryable(error, phase):
    if phase not in ("request", "read"):
        return False
    if isinstance(error, urllib.error.HTTPError):
        return error.code == 429 or 500 <= error.code <= 599
    if isinstance(error, urllib.error.URLError):
        error = error.reason
    return isinstance(error, (TimeoutError, socket.timeout, ConnectionError)) or (
        isinstance(error, OSError) and error.errno in (errno.ETIMEDOUT, errno.ECONNRESET, errno.ECONNABORTED)
    )


def transfer(row):
    key, size = row["sha256"], row["bytes"]
    partial = OBJECTS / (key + ".partial")
    final = OBJECTS / key
    assert not final.exists() and not partial.exists()
    written = 0
    h = hashlib.sha256()
    attempts = []
    started = time.monotonic()
    update(key, status="starting", bytes=0, expected_bytes=size, attempts=0)
    try:
        with partial.open("xb") as f:
            for attempt in range(1, PLAN["max_attempts_per_file"] + 1):
                if STOP.is_set() or time.monotonic() >= DEADLINE:
                    raise TimeoutError("overall_deadline")
                phase = "request"
                mark = time.monotonic()
                item = {"attempt": attempt, "range_start": written, "started_utc": now()}
                update(key, status="downloading", attempts=attempt)
                try:
                    req = urllib.request.Request(row["url"], headers={
                        "Range": f"bytes={written}-{size - 1}",
                        "Accept-Encoding": "identity", "User-Agent": "InstinctFlash-original-assets/1",
                    })
                    with urllib.request.urlopen(req, timeout=PLAN["socket_timeout_seconds"]) as response:
                        item["http_status"] = response.status
                        if response.status == 206:
                            assert response.headers.get("Content-Range") == f"bytes {written}-{size - 1}/{size}", "range_mismatch"
                        else:
                            assert response.status == 200 and written == 0, "unexpected_http_status_or_resume"
                        assert response.headers.get("Content-Encoding", "identity") == "identity", "content_encoding"
                        length = response.headers.get("Content-Length")
                        assert length is None or int(length) == size - written, "content_length"
                        while written < size:
                            if STOP.is_set() or time.monotonic() >= DEADLINE:
                                raise TimeoutError("overall_deadline")
                            if time.monotonic() - mark >= PLAN["request_timeout_seconds"]:
                                raise TimeoutError("request_deadline")
                            phase = "read"
                            data = response.read(min(256 * 1024, size - written))
                            if not data:
                                raise ConnectionError("early_eof")
                            phase = "write"
                            f.write(data)
                            h.update(data)
                            written += len(data)
                            update(key, bytes=written)
                        phase = "read"
                        assert response.read(1) == b"", "extra_bytes"
                    item.update(status="received", bytes_after=written, elapsed_seconds=time.monotonic() - mark)
                    attempts.append(item)
                    break
                except Exception as error:
                    can_retry = retryable(error, phase) and written < size and attempt < PLAN["max_attempts_per_file"] and not STOP.is_set()
                    item.update(status="failed", error_type=type(error).__name__, phase=phase,
                                bytes_after=written, retryable=can_retry, elapsed_seconds=time.monotonic() - mark)
                    if isinstance(error, urllib.error.HTTPError):
                        item["http_status"] = error.code
                    if isinstance(error, AssertionError):
                        item["assertion_category"] = str(error)
                    attempts.append(item)
                    update(key, last_error=item)
                    if not can_retry:
                        raise
                    time.sleep(min(attempt, 2))
            assert written == size and h.hexdigest() == key, "stream_size_or_sha256"
            f.flush()
            os.fsync(f.fileno())
        update(key, status="verifying_persisted_file")
        assert partial.stat().st_size == size and digest(partial) == key, "persisted_size_or_sha256"
        os.link(partial, final)
        partial.unlink()
        st = final.stat()
        receipt = {"status": "verified", "sha256": key, "bytes": size, "object_path": str(final),
                   "original_public_url": row["url"], "attempts": attempts,
                   "stream_sha256": h.hexdigest(), "persisted_sha256": key,
                   "device": st.st_dev, "inode": st.st_ino, "st_blocks": st.st_blocks,
                   "elapsed_seconds": time.monotonic() - started}
        save(CONTROL / "file_receipts" / (key + ".json"), receipt)
        update(key, status="verified", bytes=written)
        return receipt
    except Exception as error:
        failure = {"status": "failed", "sha256": key, "expected_bytes": size, "partial_bytes": written,
                   "error_type": type(error).__name__, "attempts": attempts,
                   "elapsed_seconds": time.monotonic() - started}
        if isinstance(error, AssertionError):
            failure["assertion_category"] = str(error)
        save(CONTROL / "file_receipts" / (key + ".failure.json"), failure)
        update(key, status="failed", bytes=written)
        raise RuntimeError("original_file_transfer_failed:" + key) from None


def publish_family(family, config):
    if family in FAMILIES or not all(r["sha256"] in VERIFIED for r in config["files"]):
        return
    final = ROOT / (family + "-native-inputs-v1")
    staging = ROOT / ("." + family + "-native-inputs-v1.partial")
    assert not final.exists() and not staging.exists()
    staging.mkdir(mode=0o700)
    rows = []
    repositories = {}
    for row in config["files"]:
        target = staging / row["target_relative_path"]
        target.parent.mkdir(parents=True, exist_ok=True)
        source = Path(VERIFIED[row["sha256"]]["object_path"])
        os.link(source, target)
        a, b = source.stat(), target.stat()
        assert a.st_size == b.st_size == row["bytes"] and (a.st_dev, a.st_ino) == (b.st_dev, b.st_ino)
        rows.append({"filename": row["filename"], "repository": row["repository"], "revision": row["revision"],
                     "target_relative_path": row["target_relative_path"], "path": str(final / row["target_relative_path"]),
                     "bytes": b.st_size, "sha256": row["sha256"], "verification": "persisted_object_full_sha256_and_same_inode_hardlink"})
        previous = repositories.setdefault(row["repository"], row["revision"])
        assert previous == row["revision"]
    refs = []
    for repository, revision in sorted(repositories.items()):
        relative = "hf/hub/models--" + repository.replace("/", "--") + "/refs/main"
        p = staging / relative
        p.parent.mkdir(parents=True, exist_ok=True)
        b = (revision + "\n").encode()
        p.write_bytes(b)
        refs.append({"repository": repository, "revision": revision, "path": str(final / relative),
                     "bytes": len(b), "sha256": hashlib.sha256(b).hexdigest()})
    assert len(rows) == config["file_count"] and sum(r["bytes"] for r in rows) == config["total_asset_bytes"]
    assert not final.exists()
    os.rename(staging, final)
    result = {"schema": "instinctflash.replacement_original_native_inputs_completion.v1", "status": "complete",
              "family": family, "file_count": len(rows), "total_asset_bytes": sum(r["bytes"] for r in rows),
              "root": str(final), "cache_dir": str(final / "hf/hub"), "files": rows, "refs": refs,
              "original_inventory_sha256": config["original_inventory_sha256"],
              "plan_sha256": digest(CONTROL / "plan.json"), "source_worker_sha256": digest(Path(__file__)),
              "full_inventory_sha256_verified": True, "materialization": "HTTP_stream_to_durable_objects_then_verified_hardlinks",
              "finished_utc": now(), "GPU_used": False, "Runtime_constructed": False,
              "old_host_receipts_reused": False}
    save(final / "completion.json", result)
    save(CONTROL / (family + ".completion.json"), result)
    FAMILIES[family] = {"root": str(final), "completion_sha256": digest(final / "completion.json"),
                        "file_count": len(rows), "total_asset_bytes": result["total_asset_bytes"]}


def status(phase):
    with LOCK:
        snapshot = {k: dict(v) for k, v in PROGRESS.items()}
    value = {"schema": "instinctflash.replacement_original_delivery_live.v1", "status": phase,
             "pid": os.getpid(), "process_start_ticks": Path("/proc/self/stat").read_text().split()[21],
             "updated_utc": now(), "elapsed_seconds": time.monotonic() - START,
             "bytes_written_to_owned_objects_and_partials": sum(r.get("bytes", 0) for r in snapshot.values()),
             "persisted_sha_verified_unique_bytes": sum(r["bytes"] for r in VERIFIED.values()),
             "planned_unique_object_bytes": PLAN["unique_object_bytes"], "planned_family_view_bytes": PLAN["family_view_bytes"],
             "quota_known": False, "df_not_used_as_user_quota": True,
             "worker_http_concurrency_limit": PLAN["workers"], "files": snapshot, "families": FAMILIES,
             "errors": ERRORS, "GPU_used": False}
    save(CONTROL / "live_status.json", value)
    print(json.dumps({k: v for k, v in value.items() if k != "files"}), flush=True)
    return value


def main():
    assert digest(CONTROL / "plan.json") == sys.argv[1]
    assert 1 <= PLAN["workers"] <= 8 and set(PLAN["families"]) == {"edge"}
    assert len(PLAN["objects"]) == len({r["sha256"] for r in PLAN["objects"]})
    objects = {r["sha256"]: r for r in PLAN["objects"]}
    for row in PLAN["objects"]:
        assert re.fullmatch(r"[0-9a-f]{64}", row["sha256"]) and row["bytes"] > 0
        u = urllib.parse.urlsplit(row["url"])
        assert u.scheme == "https" and u.netloc == "huggingface.co" and not u.query and not u.fragment
    for config in PLAN["families"].values():
        assert len(config["files"]) == config["file_count"]
        assert sum(r["bytes"] for r in config["files"]) == config["total_asset_bytes"]
        for row in config["files"]:
            assert re.fullmatch(r"[0-9a-f]{40}", row["revision"])
            assert not Path(row["filename"]).is_absolute() and ".." not in Path(row["filename"]).parts
            expected = "hf/hub/models--" + row["repository"].replace("/", "--") + "/snapshots/" + row["revision"] + "/" + row["filename"]
            assert row["target_relative_path"] == expected
            assert objects[row["sha256"]]["bytes"] == row["bytes"]
    assert sum(r["bytes"] for r in PLAN["objects"]) == PLAN["unique_object_bytes"]
    for family in PLAN["families"]:
        assert not (ROOT / (family + "-native-inputs-v1")).exists()
    OBJECTS.mkdir(mode=0o700)
    (CONTROL / "file_receipts").mkdir(mode=0o700)
    fd = os.open(CONTROL / "owner.json", os.O_WRONLY | os.O_CREAT | os.O_EXCL, 0o600)
    with os.fdopen(fd, "w") as f:
        json.dump({"pid": os.getpid(), "start_ticks": Path("/proc/self/stat").read_text().split()[21],
                   "started_utc": now(), "worker_sha256": digest(Path(__file__)), "plan_sha256": sys.argv[1]}, f)
    futures = {}
    with cf.ThreadPoolExecutor(max_workers=PLAN["workers"]) as pool:
        futures = {pool.submit(transfer, row): row for row in PLAN["objects"]}
        pending = set(futures)
        while pending:
            if time.monotonic() >= DEADLINE:
                STOP.set()
            done, pending = cf.wait(pending, timeout=5, return_when=cf.FIRST_COMPLETED)
            for future in done:
                if future.cancelled():
                    continue
                row = futures[future]
                try:
                    VERIFIED[row["sha256"]] = future.result()
                except Exception as error:
                    ERRORS.append({"sha256": row["sha256"], "error_type": type(error).__name__})
                    for other in pending:
                        other.cancel()
            for family, config in PLAN["families"].items():
                publish_family(family, config)
            status("draining_after_failure" if ERRORS else "downloading_and_verifying")
    assert not ERRORS and len(VERIFIED) == len(PLAN["objects"]) and set(FAMILIES) == set(PLAN["families"]), "incomplete_original_inventory"
    value = status("complete")
    value.update(finished_utc=now(), plan_sha256=digest(CONTROL / "plan.json"), worker_sha256=digest(Path(__file__)),
                 unique_persisted_object_count=len(VERIFIED), actual_st_blocks_bytes=sum(r["st_blocks"] * 512 for r in VERIFIED.values()))
    save(CONTROL / "completion.json", value)


if __name__ == "__main__":
    try:
        main()
    except BaseException as error:
        state = {"status": "failed_preserved", "error_type": type(error).__name__, "finished_utc": now(),
                 "families": FAMILIES, "errors": ERRORS, "GPU_used": False, "automatic_worker_relaunch": False}
        if isinstance(error, AssertionError):
            state["assertion_category"] = str(error)
        save(CONTROL / "failure.json", state)
        status("failed_preserved")
        raise SystemExit(1) from None
