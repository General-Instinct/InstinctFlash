#!/usr/bin/env python3
"""One bounded installed-wheel GPU0 primitive qualification in the pinned Cosmos Edge environment."""
from pathlib import Path
import csv
import datetime
import fcntl
import hashlib
import json
import os
import signal
import subprocess
import time
import traceback
import sys
from qualify_report_guards_v1 import admit

ROOT = Path('/workspace/ifl_rtx4090_580_20260916')
OUT = ROOT / 'primitive_v1'
SOURCE = ROOT / 'source-c5'
GPU = 'GPU-cc9b08f5-0925-2946-48f6-a576bc6b28bc'
PYTHON = '/workspace/ifl_rtx4090_580_20260916/families/edge-v1/env/bin/python'
SCRIPT = SOURCE / 'scripts/qualify_sm89_fp8.py'
TIMEOUT = 900
started = time.monotonic()
locks = []
child = None
state = {'scope': 'installed-wheel synthetic primitives in pinned Cosmos Torch2.10 environment; no full-model qualification',
         'release_qualification': False, 'model_quality_evidence': False,
         'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
         'worker_pid': os.getpid(),
         'worker_start_ticks': Path('/proc/self/stat').read_text().split()[21],
         'gpu_uuid': GPU, 'timeout_seconds': TIMEOUT, 'automatic_retry': False,
         'python': PYTHON, 'source': str(SOURCE), 'status': 'starting', 'passed': False}

def save():
    temp = OUT / 'status.json.tmp'
    temp.write_text(json.dumps(state, indent=2) + '\n')
    temp.replace(OUT / 'status.json')

def run(argv):
    return subprocess.check_output(argv, text=True, timeout=20).strip()

try:
    save()
    assert SCRIPT.is_file() and Path(PYTHON).is_file()
    assert hashlib.sha256((OUT / 'qualify_report_guards_v1.py').read_bytes()).hexdigest() == '396ac8418a115dbd504f3c73b9a4cfa0a7553f284556324477099b0b5e23efd3'
    script_sha = hashlib.sha256(SCRIPT.read_bytes()).hexdigest()
    state['script_sha256'] = script_sha
    assert script_sha == '7dd70fc40c3e9998fad2f693645b9c2742d094888d5c420749c7d1b368f83f7b', script_sha
    cold_path = ROOT / 'bootstrap_execution_v1/completion.json'
    cold = json.loads(cold_path.read_bytes())
    assert cold['status'] == 'complete'
    bootstrap_path = ROOT / 'families/edge-v1/completion.json'
    bootstrap = json.loads(bootstrap_path.read_bytes())
    assert bootstrap['CPU_doctor_passed'] is True and bootstrap['family'] == 'edge'
    assert bootstrap['deployment_target'] == 'rtx4090'
    assert run(['git', '-C', str(SOURCE), 'rev-parse', 'HEAD']) == 'c5c1cbbdbc1579258be41cf1c621829dfeeb80f3'
    assert run(['git', '-C', str(SOURCE), 'status', '--porcelain']) == ''
    state['cold_completion_sha256'] = hashlib.sha256(cold_path.read_bytes()).hexdigest()
    state['bootstrap_completion_sha256'] = hashlib.sha256(bootstrap_path.read_bytes()).hexdigest()
    expected_runtime_files = {'fp8_pack.py': '9b967b83b133f0d6dbb1613da56eca1ad99d9e8e8b532b456cf08befc6de3655', 'module_residency.py': '4f83face9a4d7718616538d0ba571ac1cc1ee3e81c573873f7b8d3d4db8f97fa', 'sm89_fp8.py': '49e4a4f4cabb3be35815aea69e4e8368fe774965ac4fa56eff35604bef1169be', 'torch_fp8_linear.py': '22288120d9362785ed01cb5c2e6d4c1193c3e4d6a1a0c137d9c117300e0820f5'}
    for name, expected in expected_runtime_files.items():
        installed_path = Path(PYTHON).parent.parent / 'lib/python3.13/site-packages/instinctflash/runtime' / name
        assert hashlib.sha256(installed_path.read_bytes()).hexdigest() == expected
    state['admitted_runtime_files'] = expected_runtime_files
    state['pack_sha256'] = hashlib.sha256((SOURCE / 'instinctflash/runtime/fp8_pack.py').read_bytes()).hexdigest()
    assert state['pack_sha256'] == '9b967b83b133f0d6dbb1613da56eca1ad99d9e8e8b532b456cf08befc6de3655'
    lock_paths = [ROOT / 'host-timing.lock', Path('/tmp/ifl-robolab-renderer-gpu0.lock'),
                  ROOT / 'gpu-leases' / (GPU + '.lock')]
    lock_paths[2].parent.mkdir(mode=0o700, exist_ok=True)
    for path in lock_paths:
        handle = path.open('a')
        fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
        locks.append(handle)
    state['lock_paths'] = [str(p) for p in lock_paths]
    state['gpu_before_csv'] = run(['nvidia-smi', '--query-gpu=index,uuid,name,memory.used,utilization.gpu', '--format=csv,noheader,nounits'])
    state['compute_processes_before_csv'] = run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory', '--format=csv,noheader,nounits'])
    rows = [[v.strip() for v in row] for row in csv.reader(state['gpu_before_csv'].splitlines())]
    selected = [row for row in rows if row[1] == GPU]
    assert len(selected) == 1 and selected[0][0] == '0', selected
    assert int(selected[0][3]) <= 64 and int(selected[0][4]) == 0, selected
    assert GPU not in state['compute_processes_before_csv'], state['compute_processes_before_csv']
    env = {k: v for k, v in os.environ.items() if k not in ("PYTHONPATH", "PYTHONHOME")}
    env.update(json.loads((ROOT / "families/edge-v1/completion.json").read_text())["compiler_preparation"]["environment"])
    env.update(CUDA_VISIBLE_DEVICES=GPU, CUDA_DEVICE_ORDER='PCI_BUS_ID',
               PYTHONDONTWRITEBYTECODE='1', PYTHONNOUSERSITE='1',
               HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1')
    cache_vars = {'TRITON_CACHE_DIR': 'triton-cache', 'TORCHINDUCTOR_CACHE_DIR': 'inductor-cache',
                  'CUDA_CACHE_PATH': 'cuda-cache', 'TORCH_EXTENSIONS_DIR': 'extensions-cache',
                  'XDG_CACHE_HOME': 'xdg-cache', 'TMPDIR': 'tmp'}
    for name, child_name in cache_vars.items():
        path = OUT / child_name
        path.mkdir(mode=0o700)
        env[name] = str(path)
    state['subprocess_environment_overrides'] = {k: env[k] for k in [
        'CUDA_VISIBLE_DEVICES', 'CUDA_DEVICE_ORDER', 'PYTHONDONTWRITEBYTECODE',
        'PYTHONNOUSERSITE', 'HF_HUB_OFFLINE', 'TRANSFORMERS_OFFLINE', *cache_vars]}
    argv = [PYTHON, "-I", str(SCRIPT), '--output', str(OUT / 'report.json')]
    state['argv'] = argv
    with (OUT / 'qualifier.log').open('xb') as log:
        child = subprocess.Popen(argv, env=env, cwd=OUT, stdin=subprocess.DEVNULL,
                                 stdout=log, stderr=subprocess.STDOUT, start_new_session=True)
        state.update(status='running', child_pid=child.pid,
                     child_start_ticks=Path(f'/proc/{child.pid}/stat').read_text().split()[21])
        save()
        try:
            code = child.wait(timeout=TIMEOUT)
            state.update(status='finished', returncode=code)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGTERM)
            try:
                child.wait(timeout=10)
            except subprocess.TimeoutExpired:
                os.killpg(child.pid, signal.SIGKILL)
                child.wait(timeout=10)
            state.update(status='timed_out', returncode=child.returncode)
    report = OUT / 'report.json'
    assert state['returncode'] == 0 and report.is_file(), 'Qualifier failed or omitted its report'
    state['report_sha256'] = hashlib.sha256(report.read_bytes()).hexdigest()
    result = json.loads(report.read_text())
    admit(result, returncode=state['returncode'], python=PYTHON, sources=expected_runtime_files,
          script_sha256=script_sha)
    state.update(passed=True, status='complete')
except Exception as error:
    state.update(passed=False, status='failed', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
finally:
    if child is not None and child.poll() is None:
        os.killpg(child.pid, signal.SIGTERM)
        try:
            child.wait(timeout=10)
        except subprocess.TimeoutExpired:
            os.killpg(child.pid, signal.SIGKILL)
            child.wait(timeout=10)
    state['finished_utc'] = datetime.datetime.now(datetime.timezone.utc).isoformat()
    state['elapsed_seconds'] = time.monotonic() - started
    try:
        state['gpu_after_csv'] = run(['nvidia-smi', '--query-gpu=index,uuid,memory.used,utilization.gpu', '--format=csv,noheader,nounits'])
        state['compute_processes_after_csv'] = run(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory', '--format=csv,noheader,nounits'])
    except Exception as error:
        state['gpu_after_error'] = str(error)
    for handle in reversed(locks):
        fcntl.flock(handle, fcntl.LOCK_UN)
        handle.close()
    state['gpu_lease_released'] = True
    save()
    print(json.dumps(state))

sys.exit(0 if state['passed'] else 1)
