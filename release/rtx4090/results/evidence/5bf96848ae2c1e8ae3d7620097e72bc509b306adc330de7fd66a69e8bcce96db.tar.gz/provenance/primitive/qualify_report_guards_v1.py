"""Admit an actual complete SM89 primitive receipt without promoting model scope."""

def admit(report, *, returncode, python, sources, script_sha256):
    assert returncode == 0, 'Qualifier subprocess failed'
    assert report['schema'] == 'instinctflash.sm89_fp8_primitive_qualification.v1'
    assert report['passed'] is True and report['scope'] == 'synthetic primitives only'
    assert report['model_constructed'] is False and report['model_weights_downloaded'] is False
    assert report['task_quality_status'] == 'unverified'
    assert report['script_sha256'] == script_sha256
    runtime = report['runtime']
    assert runtime['torch'] == '2.10.0+cu130' and runtime['triton'] == '3.6.0'
    assert runtime['torch_cuda'] == '13.0' and runtime['python_executable'] == python
    assert report['device']['capability'] == [8, 9]
    assert report['device']['name'] == 'NVIDIA GeForce RTX 4090'
    assert {name: row['sha256'] for name, row in report['source'].items()} == sources
    assert len(report['packing']) == 12 and all(row['passed'] is True for row in report['packing'])
    assert len(report['projections']) == 6
    for row in report['projections']:
        assert all(row[key] is True for key in ['passed', 'reference_recipe_equal', 'changed_input_graph_replay_equal', 'cpu_gpu_packing_equal'])
    assert len(report['module_residency']) == 2
    assert {row['precision'] for row in report['module_residency']} == {'native', 'fp8'}
    assert all(row['passed'] is True for row in report['module_residency'])
