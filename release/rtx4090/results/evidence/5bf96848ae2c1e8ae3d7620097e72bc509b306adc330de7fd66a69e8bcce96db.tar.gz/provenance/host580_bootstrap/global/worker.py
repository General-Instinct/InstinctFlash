import fcntl,json,os,pathlib,subprocess,time,traceback
R=pathlib.Path('/workspace/ifl_rtx4090_580_20260916')
OUT=R/'bootstrap_execution_v1'; SOURCE=R/'source-c5'
state={'schema':'instinctflash.host580_bootstrap.v1','status':'starting','started':time.time(),'source_commit':'c5c1cbbdbc1579258be41cf1c621829dfeeb80f3','stages':[],'GPU_used':False,'automatic_retries':0}
def save():
 p=OUT/'status.tmp';p.write_text(json.dumps(state,indent=2)+'\n');p.replace(OUT/'status.json')
handle=(R/'host-timing.lock').open('a');fcntl.flock(handle,fcntl.LOCK_EX)
try:
 assert json.loads((R/'inputs_admission.json').read_text())['status']=='passed'
 for family in ('edge','nano'):
  argv=['/usr/bin/python3.13',str(SOURCE/'scripts/bootstrap_vendor.py'),'install',family,'--target','rtx4090','--checkout',str(SOURCE),'--root',str(R/'families'/(family+'-v1')),'--python','/usr/bin/python3.13','--uv','/usr/bin/uv','--cache-dir',str(R/'uv-cache'),'--link-mode','hardlink','--vendor-source',str(R/'vendor/cosmos.bundle'),'--dependency-wheelhouse',str(R/('wheelhouse-'+family)),'--dependency-artifact-cache',str(R/'canonical-dependency-artifacts'),'--native-tool-wheelhouse',str(R/'hf_tool'),'--ptxas','/usr/local/cuda-13.0/bin/ptxas','--timeout','1800']
  row={'family':family,'argv':argv,'started':time.time()};state['stages'].append(row);state['status']='install_'+family;save()
  env={k:v for k,v in os.environ.items() if not k.startswith(('IFL_','UV_','PIP_')) and k not in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV')};env['CUDA_VISIBLE_DEVICES']=''
  with (OUT/(family+'.log')).open('xb') as log:
   process=subprocess.Popen(argv,env=env,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
   row['pid']=process.pid;save()
   try:rc=process.wait(timeout=3600)
   except subprocess.TimeoutExpired:
    process.terminate();process.wait(timeout=20);raise
  row.update(returncode=rc,finished=time.time());save()
  assert rc==0,'Bootstrap failed for '+family
  done=json.loads((R/'families'/(family+'-v1')/'completion.json').read_text())
  assert done['CPU_doctor_passed'] is True and done['GPU_verified'] is False
 state['status']='complete'
except BaseException as e:state.update(status='failed_preserved',error=repr(e),traceback=traceback.format_exc())
finally:
 state['finished']=time.time();save();fcntl.flock(handle,fcntl.LOCK_UN);handle.close()
 (OUT/('completion.json' if state['status']=='complete' else 'failure.json')).write_text(json.dumps(state,indent=2)+'\n')
