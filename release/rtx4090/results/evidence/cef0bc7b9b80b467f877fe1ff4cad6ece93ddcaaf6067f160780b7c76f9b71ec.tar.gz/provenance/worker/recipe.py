"""Frozen supplemental VA protocol and CPU receipt validation; no inference imports."""
from __future__ import annotations
import argparse
from copy import deepcopy
import hashlib
import json
from pathlib import Path
import statistics

TARGET = {'name':'rtx4090','capability':[8,9]}
NFE = {'video':2,'action':4}
DEFAULT = {'video':25,'action':50}
GPU = 'GPU-34f3da96-a7b2-ed04-c766-05e7862d940c'
FIXTURE = '37843e22fa6dd9a2abf2bae390ccb8e5c4319446e3d3fab5d0d477860065f411'
IDS = ('va-eager_native-2v4a','va-2v4a-native')

def require(value, message):
    if not value: raise ValueError(message)

def require_gpu(value):
    # Torch reports the UUID without nvidia-smi's GPU- prefix on this host.
    require(isinstance(value,str) and value in (GPU,GPU.removeprefix('GPU-')),'Different physical GPU')

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(4<<20),b''):digest.update(block)
    return digest.hexdigest()

def write(path, value):
    with Path(path).open('x') as handle:json.dump(value,handle,indent=2,allow_nan=False);handle.write('\n')

def installed_sources(review_path,output):
    import importlib.util,sys
    from benchmarks.regression.reproduce import require_installed
    require_installed()
    review=json.loads(Path(review_path).read_text());sources={}
    for relative,digest in review['installed_source_sha256'].items():
        spec=importlib.util.find_spec(relative[:-3].replace('/','.'))
        require(spec is not None and spec.origin,'Installed module missing: '+relative)
        path=Path(spec.origin).resolve()
        require(sha(path)==digest,'Installed source differs: '+relative)
        sources[relative]={'path':str(path),'sha256':digest}
    require('torch' not in sys.modules,'Source admission unexpectedly imported Torch')
    write(output,{'schema':'instinctflash.task_owned_installed_sources.v1','status':'passed',
                  'review_sha256':sha(review_path),'interpreter':sys.executable,'sources':sources,'torch_imported':False})

def check_installed_admissions(root,review_path,review,receipts):
    records=[]
    for name in ('installed_sources_before.json','installed_sources_after.json'):
        record=json.loads((root.parent/name).read_text());records.append(record)
        require(record['status']=='passed' and record['torch_imported'] is False,'Installed source admission failed')
        require(record['review_sha256']==sha(review_path),'Installed source review binding differs')
        require(set(record['sources'])==set(review['installed_source_sha256']),'Installed source coverage differs')
        for relative,digest in review['installed_source_sha256'].items():
            entry=record['sources'][relative]
            require(entry['sha256']==digest and sha(entry['path'])==digest,'Installed source bytes changed: '+relative)
    require(records[0]==records[1],'Installed source paths/bytes changed between capture phases')
    require(all(r['interpreter']==records[0]['interpreter'] for r in receipts),'Capture interpreter differs from source admission')
    return records[0]

def matrix_from_plan(plan):
    require(plan['model']=='va' and plan['execution_mode']=='2v4a-native' and plan['target']==TARGET,'Wrong public prepared plan')
    require(plan['fixture_sha256']==FIXTURE,'Wrong fixed public fixture')
    runtime, = [deepcopy(c) for c in plan['matrix']['cells'] if c['id']==IDS[1]]
    native, = [deepcopy(c) for c in plan['matrix']['cells'] if c['arm']=='eager_native']
    require(native['effective_schedule']['nfe']==DEFAULT,'Public checkpoint declaration changed')
    require(runtime['effective_schedule']['nfe']==NFE and runtime['expected_runtime_kwargs']['precision']=='native','Wrong operating point')
    native.update(id=IDS[0],receipt=f'cells/{IDS[0]}/receipt.json',native_nfe=dict(NFE),default_schedule=dict(DEFAULT),
                  effective_schedule=deepcopy(runtime['effective_schedule']),comparison_group=runtime['comparison_group'],experimental=True)
    runtime['default_schedule']=dict(DEFAULT)
    matrix=deepcopy(plan['matrix'])
    matrix.update(expected_main_cells=1,expected_operating_point_cells=1,cells=[native,runtime],
                  supplementary_only=True,publication_ready=False,quality_certified=False)
    return matrix

def expected_cases(fixture):
    from benchmarks.regression.user_e2e import RecordedInputs,prompt,request_hash
    require(sha(fixture)==FIXTURE,'Fixture byte hash differs')
    data=RecordedInputs(fixture);cases=[]
    for i in range(21):
        episode,cycle=divmod(i,3)
        cases.append({'i':i,'episode':episode,'cycle':cycle,'phase':'warmup' if episode==0 else 'measured',
                      'seed':1300+episode*3+cycle,'input_sha256':request_hash({'observation':data.observation('va',i,cycle),'prompt':prompt(episode)}),
                      'feedback_sha256':request_hash({'executed_action':data.feedback[cycle].copy()}),'call_kind':'generation'})
    return cases

def expected_serve_cases(fixture):
    from benchmarks.regression.user_e2e import RecordedInputs,prompt,request_hash
    require(sha(fixture)==FIXTURE,'Serving fixture byte hash differs')
    data=RecordedInputs(fixture);cases=[]
    for i in range(6):
        episode,cycle=divmod(i,3);observation=data.observation('va',i,cycle)
        observation['prompt']=prompt(episode);observation['executed_action']=data.feedback[cycle].copy()
        cases.append({'episode':episode,'cycle':cycle,'request_sha256':request_hash(observation)})
    return cases

def prepare(prepared, output, review):
    from benchmarks.regression.reproduce import validate_bundle
    plan,_=validate_bundle(Path(prepared))
    frozen=json.loads(Path(review).read_text())
    matrix=matrix_from_plan(plan)
    require(matrix==frozen['matrix'],'Prepared settings differ from the pre-reviewed supplemental matrix')
    require(plan==frozen['public_plan'],'Public prepared plan differs from frozen source-v10 plan')
    require(expected_cases(Path(prepared)/'inputs/recorded_inputs_v1.npz')==frozen['request_cases'],'Fixed request recipe differs')
    write(Path(output)/'matrix.json',matrix)
    write(Path(output)/'recipe_binding.json',{'review_sha256':sha(review),'prepared_plan_sha256':sha(Path(prepared)/'plan.json'),
          'prepared_preparation_sha256':sha(Path(prepared)/'preparation.json'),'matrix_sha256':sha(Path(output)/'matrix.json')})

def check_hardware(receipt):
    from benchmarks.regression.hardware import validate_device_receipt
    require(receipt.get('target')==TARGET,'Wrong receipt target')
    validate_device_receipt(receipt.get('hardware'),TARGET)
    hardware=receipt['hardware']
    require_gpu(hardware['uuid'])
    require(23*(1<<30) <= hardware['total_memory_bytes'] <= 24*(1<<30),'Unexpected RTX4090 memory capacity')
    require(receipt['device']=='NVIDIA GeForce RTX 4090','Wrong public device label')

def check_common(receipt,cell,matrix_sha,review,root):
    require(receipt['matrix_sha256']==matrix_sha,'Matrix byte binding differs')
    require(receipt['input_archive_sha256']==FIXTURE,'Fixture byte binding differs')
    require(receipt['cases']==review['request_cases'],'Paired request/feedback/seed/history protocol differs')
    require(receipt['default_schedule']==DEFAULT,'Original 25V/50A checkpoint declaration changed')
    require(receipt['observed_nfe_before']==receipt['observed_nfe_after']==NFE,'Actual native sampler settings differ')
    require(receipt['effective_schedule']==cell['effective_schedule'],'Effective schedule differs')
    require(receipt['numeric_environment']=={'matmul_tf32':False,'cudnn_tf32':False,'cudnn_benchmark':False},'Numeric environment differs')
    require(receipt['precision']=='native' and not receipt.get('e4m3_tensors'),'Native cell packed FP8 weights')
    require(receipt['torch']==review['torch_version'],'Torch version differs')
    check_hardware(receipt)
    for relative,digest in review['capture_source_sha256'].items():
        if relative.endswith('native_reference.py') and cell['arm']!='eager_native':continue
        matches=[(path,value) for path,value in receipt['sources'].items() if path.endswith('/'+relative)]
        # python -m executes this entrypoint as __main__, outside the capture's
        # module-name source inventory. Separate installed before/after receipts
        # bind its exact bytes and the same interpreter used by both cells.
        if relative=='benchmarks/regression/user_e2e.py' and not matches:continue
        require(len(matches)==1 and matches[0][1]==digest and sha(matches[0][0])==digest,'Public capture source binding differs: '+relative)
    for path,digest in receipt['sources'].items():require(sha(path)==digest,'Loaded source changed after capture: '+path)
    require(receipt['input_contract']=={'family':'va','fixture_sha256':FIXTURE,
            'fixture_protocol':'recorded_cameras_synthetic_states_v1','action_shape':[16,2,16]},'Input contract differs')
    policy=receipt['execution_policy']
    if cell['arm']=='eager_native':
        require(receipt['native_nfe_override']==NFE and policy['native_nfe_override']==NFE,'Native override differs')
        require(policy['checkpoint_nfe']==DEFAULT and policy['nfe']==NFE and policy['schedule_changed'] is True,'Native policy declaration differs')
        require(policy['reference']=='upstream eager native policy with declared weight residency changes','Native reference not declared')
        residency=policy['native_residency']
        require(residency['schema']=='instinctflash.native_va_residency.v1','Native residency schema differs')
        require_gpu(residency['device']['uuid'])
        require(residency['native_math']=='unchanged FSDP, attention, dtype, CFG and sampling schedule','Native math contract differs')
        require(not receipt['applied_passes'] and not receipt['graph_stats'] and not receipt.get('backend_stats'),'Native accelerator state present')
    else:
        require(policy['nfe']==NFE and policy['tier_ceiling']=='behavioral','Runtime policy differs')
    archive=root/cell['receipt'];require(sha(archive.with_suffix('.npz'))==receipt['actions_sha256'],'Action archive byte hash differs')

def validate(run,review_path,parent_run,output):
    from benchmarks.regression.user_report import _validate_cell,_action_difference
    root=Path(run);review=json.loads(Path(review_path).read_text());matrix=json.loads((root/'matrix.json').read_text())
    require(matrix==review['matrix'],'Frozen matrix differs')
    binding=json.loads((root/'recipe_binding.json').read_text())
    require(binding['review_sha256']==sha(review_path) and binding['matrix_sha256']==sha(root/'matrix.json'),'Frozen recipe binding differs')
    rows=[];evidence=[];receipts=[]
    for cell in matrix['cells']:
        receipt=json.loads((root/cell['receipt']).read_text())
        row,details=_validate_cell(cell,root,require_observed_schedule=True)
        check_common(receipt,cell,sha(root/'matrix.json'),review,root)
        primary=[i for i in range(3,21) if i%3]
        require(details['primary_indices']==primary and len(primary)==12,'Continuation sample selection differs')
        require(statistics.median(receipt['calls'][i]['ms'] for i in primary)==row['primary']['p50_ms'],'Independent median differs')
        rows.append(row);evidence.append(details);receipts.append(receipt)
    source_admission=check_installed_admissions(root,review_path,review,receipts)
    require(receipts[0]['cases']==receipts[1]['cases'] and receipts[0]['guidance']==receipts[1]['guidance'],'Native pair input/guidance mismatch')
    parent=Path(parent_run);parent_matrix=json.loads((parent/'matrix.json').read_text())
    fp8,=[c for c in parent_matrix['cells'] if c['id']=='va-2v4a-fp8']
    fp8_row,fp8_evidence=_validate_cell(fp8,parent,require_observed_schedule=True)
    fp8_receipt=json.loads((parent/fp8['receipt']).read_text())
    require(fp8_receipt['matrix_sha256']==sha(parent/'matrix.json') and fp8_receipt['input_archive_sha256']==FIXTURE,'Parent FP8 matrix/fixture binding differs')
    require(fp8_receipt['cases']==review['request_cases'] and fp8_receipt['default_schedule']==DEFAULT,'Parent FP8 request/default schedule differs')
    require(fp8_receipt['precision']=='fp8' and fp8_receipt.get('e4m3_tensors'),'Parent FP8 route not packed')
    require(fp8_receipt['observed_nfe_before']==fp8_receipt['observed_nfe_after']==NFE,'Parent FP8 schedule differs')
    require(fp8_receipt['torch']==review['torch_version'] and fp8_receipt['guidance']==receipts[0]['guidance'],'Parent FP8 stack/guidance differs')
    require(fp8_receipt['interpreter']==source_admission['interpreter'],'Parent FP8 interpreter differs')
    check_hardware(fp8_receipt)
    result={'schema':'instinctflash.task_owned_va_2v4a_supplement.v2','status':'passed_recorded_input_protocol_and_latency',
            'quality_certified':False,'publication_ready':False,'matrix_sha256':sha(root/'matrix.json'),'review_sha256':sha(review_path),
            'default_checkpoint_nfe':DEFAULT,'matched_effective_nfe':NFE,'native':rows[0],'runtime_native':rows[1],'existing_runtime_fp8':fp8_row,
            'runtime_native_vs_upstream_actions':_action_difference(evidence[0]['actions'],evidence[1]['actions']),
            'runtime_fp8_vs_upstream_actions':_action_difference(evidence[0]['actions'],fp8_evidence['actions']),
            'matched_schedule_speedups':{'runtime_native_vs_upstream':rows[0]['primary']['p50_ms']/rows[1]['primary']['p50_ms'],
                                         'runtime_fp8_vs_upstream':rows[0]['primary']['p50_ms']/fp8_row['primary']['p50_ms']},
            'scope':'21 calls each, fixed recorded cameras and feedback, paired RNG; 12 measured continuation samples. Changed 2V/4A schedule, no robot-task quality claim.'}
    write(output,result)
    return result

def validate_serve(path,review_path,output):
    import numpy as np
    from benchmarks.regression.serve_smoke import validate_metadata
    from benchmarks.regression.hardware import validate_device_receipt
    root=Path(path);receipt=json.loads((root/'receipt.json').read_text());review=json.loads(Path(review_path).read_text())
    cell=review['matrix']['cells'][1]
    require(receipt['status']=='passed' and receipt['server_exit_code']==0,'WebSocket/shutdown failed')
    require(receipt['cell_id']==IDS[1] and receipt['fixture_sha256']==FIXTURE,'Wrong serving fixture/cell')
    require(receipt['plan_sha256']==review['public_plan_sha256'],'Serving prepared plan differs')
    require(receipt['target']==TARGET and receipt['seed']==9173 and receipt['latency_benchmark'] is False,'Serving protocol differs')
    validate_device_receipt(receipt['hardware'],TARGET);require_gpu(receipt['hardware']['uuid'])
    validate_metadata(receipt['metadata'],cell)
    require([{k:c[k] for k in ('episode','cycle','request_sha256')} for c in receipt['calls']]==review['serve_request_cases'],'Serving request bytes/reset/history differ')
    require(sha(root/'actions.npz')==receipt['action_archive_sha256'],'Serving action bytes differ')
    with np.load(root/'actions.npz',allow_pickle=False) as z:
        require(z['actions'].shape==(6,16,2,16) and np.isfinite(z['actions']).all(),'Serving action shape/finite gate failed')
    require(sha(root/'server_device.json')==receipt['server_device_sha256'],'Server device receipt changed')
    write(output,{'status':'passed','receipt_sha256':sha(root/'receipt.json'),'scope':'Native 2V/4A public WebSocket reset/history/shape/metadata/shutdown, not paired timing','GPU_uuid':GPU})

def main():
    parser=argparse.ArgumentParser();parser.add_argument('action',choices=('prepare','validate','serve','sources'))
    parser.add_argument('--review',required=True,type=Path);parser.add_argument('--output',required=True,type=Path)
    parser.add_argument('--prepared',type=Path);parser.add_argument('--run',type=Path);parser.add_argument('--parent-run',type=Path)
    args=parser.parse_args()
    if args.action=='sources':installed_sources(args.review,args.output)
    elif args.action=='prepare':prepare(args.prepared,args.output,args.review)
    elif args.action=='validate':validate(args.run,args.review,args.parent_run,args.output)
    else:validate_serve(args.run,args.review,args.output)

if __name__=='__main__':main()
