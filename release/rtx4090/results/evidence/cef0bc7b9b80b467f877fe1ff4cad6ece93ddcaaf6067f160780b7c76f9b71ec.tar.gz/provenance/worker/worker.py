"""Prepared, never automatically launched: two additional VA cells plus native WebSocket."""
from __future__ import annotations
import csv
import datetime
import fcntl
import hashlib
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

ROOT=Path('/workspace/ifl_rtx4090_20260916')
GPU='GPU-34f3da96-a7b2-ed04-c766-05e7862d940c'
COMMIT='a0dc86cc7447ce894663540adf49cfb6e96af97d'

def require(value,message):
    if not value:raise ValueError(message)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(4<<20),b''):digest.update(block)
    return digest.hexdigest()

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def admit_parent(parent):
    parent=Path(parent);completion=parent/'completion.json'
    require(completion.is_file() and not (parent/'failure.json').exists(),'Parent VA-v4 has not passed; do not launch early')
    main=json.loads(completion.read_text())
    require(main.get('schema')=='instinctflash.rtx4090_family_pipeline.v1'
            and main.get('family')=='va' and main.get('GPU_uuid')==GPU
            and main.get('passed') is True and main.get('lease_released') is True
            and main.get('source_commit')==COMMIT,'Parent VA-v4 did not finish on pinned source/device')
    return sha(completion)

def proc(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'parent':int(fields[1]),'start':fields[19],'state':fields[0]}
    except FileNotFoundError:return None

def stop_owned_tree(child):
    # A WebSocket server has its own session. Save exact descendant identities
    # before stopping the parent so cleanup cannot miss its separate process group.
    tree={child.pid:proc(child.pid)}
    records={int(p.name):proc(int(p.name)) for p in Path('/proc').iterdir() if p.name.isdigit()}
    changed=True
    while changed:
        changed=False
        for pid,row in records.items():
            if row and row['parent'] in tree and pid not in tree:tree[pid]=row;changed=True
    def send(sig):
        for pid,row in reversed(list(tree.items())):
            current=proc(pid)
            if row and current and current['start']==row['start'] and current['state']!='Z':
                try:os.kill(pid,sig)
                except ProcessLookupError:pass
    send(signal.SIGTERM)
    try:child.wait(timeout=15)
    except subprocess.TimeoutExpired:pass
    send(signal.SIGKILL)
    child.wait(timeout=10)

def run(config):
    out=Path(config['output']);source=Path(config['source']);family=Path(config['family_root'])
    assets=Path(config['assets']);python=str(family/'env/bin/python');worker_dir=Path(__file__).resolve().parent
    state={'schema':'instinctflash.task_owned_va_2v4a_worker.v2','status':'prerequisites','worker_pid':os.getpid(),
           'started_at':utc(),'passed':False,'source_commit':COMMIT,'automatic_retries':0,'GPU_uuid':GPU,
           'config_sha256':sha(worker_dir/'config.json'),'worker_sha256':sha(__file__),'stages':[],
           'task_quality_validated':False,'publication_ready':False}
    locks=[];child=None;asset_stats={}
    require(not out.exists() and not out.is_symlink(),'Supplement output already exists')
    out.mkdir(mode=0o700)
    def save():
        tmp=out/'status.tmp';tmp.write_text(json.dumps(state,indent=2)+'\n');tmp.replace(out/'status.json')
    def acquire(path):
        handle=path.open('a');deadline=time.monotonic()+14400
        try:
            while True:
                try:fcntl.flock(handle,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(handle);return
                except BlockingIOError:
                    if time.monotonic()>deadline:raise TimeoutError('Lease deadline expired')
                    state.update(status='waiting_lease',lease=str(path),updated_at=utc());save();time.sleep(5)
        except BaseException:handle.close();raise
    def stage(name,argv,env,timeout):
        nonlocal child
        row={'name':name,'argv':argv,'started_at':utc(),'timeout_seconds':timeout};state['stages'].append(row)
        state['status']=name;save();log=out/(name+'.log');start=time.monotonic()
        with log.open('xb') as handle:
            child=subprocess.Popen(argv,cwd=out,env=env,stdin=subprocess.DEVNULL,stdout=handle,stderr=subprocess.STDOUT,start_new_session=True)
            row['pid']=child.pid;row['start_ticks']=proc(child.pid)['start'];save()
            try:code=child.wait(timeout=timeout)
            except BaseException:stop_owned_tree(child);raise
        row.update(exit_code=code,elapsed_seconds=time.monotonic()-start,log_sha256=sha(log),finished_at=utc());save()
        require(code==0,name+' failed; original log preserved')
    def interrupted(signum, _frame):
        raise RuntimeError('Owned supplemental worker interrupted by signal '+str(signum))
    old_handlers={sig:signal.signal(sig,interrupted) for sig in (signal.SIGTERM,signal.SIGINT)}
    try:
        save()
        parent=Path(config['parent_pipeline']);completion=parent/'completion.json'
        state['parent_completion_sha256']=admit_parent(parent)
        require(subprocess.check_output(['git','-C',str(source),'rev-parse','HEAD'],text=True,timeout=30).strip()==COMMIT,'Source-v10 commit changed')
        upgrade=json.loads((ROOT/'va-core-v10/completion.json').read_text())
        require(upgrade['passed'] is True and upgrade['source_commit']==COMMIT,'Installed VA core upgrade missing')
        state['core_upgrade_completion_sha256']=sha(ROOT/'va-core-v10/completion.json')
        for relative,digest in config['source_files'].items():require(sha(source/relative)==digest,'Frozen source byte mismatch: '+relative)
        for name,digest in config['worker_files'].items():require(sha(worker_dir/name)==digest,'Prepared worker input changed: '+name)
        installed=json.loads((family/'completion.json').read_text())
        require(installed['CPU_doctor_passed'] is True and installed['family']=='va' and installed['deployment_target']=='rtx4090','Wrong existing installed family')
        state['bootstrap_completion_sha256']=sha(family/'completion.json')
        require(sha(assets/'completion.json')==config['assets_completion_sha256'],'Original VA asset receipt changed')
        receipt=json.loads((assets/'completion.json').read_text());require(receipt['status']=='assets_hash_verified','Original asset admission failed')
        acquire(ROOT/'host-timing.lock');acquire(Path('/tmp/ifl-robolab-renderer-gpu0.lock'));acquire(ROOT/'gpu-leases'/(GPU+'.lock'))
        # Heavy byte admission runs only after the exclusive host lease, outside timings.
        files=receipt['files']+receipt['primary_checkpoint']['files']
        for entry in files:
            path=Path(entry['destination']);stat=path.stat()
            require(stat.st_size==entry['bytes'] and sha(path)==entry['sha256'],'Original VA asset bytes differ')
            asset_stats[str(path)]=[stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns]
        state['asset_byte_admission']={'files':len(files),'bytes':sum(e['bytes'] for e in files),'receipt_sha256':sha(assets/'completion.json')}
        env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME','VIRTUAL_ENV','DYNAMIC_CACHE_SCHEDULE','NUM_DIT_STEPS','LOAD_TRT_ENGINE','ENABLE_TENSORRT') and not k.startswith(('IFL_','UV_','PIP_'))}
        env.update(CUDA_VISIBLE_DEVICES='',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1',ENABLE_TENSORRT='false')
        env.update(installed.get('compiler_preparation',{}).get('environment',{}));env.update(receipt['environment'])
        env['LINGBOT_ROOT']=installed['vendor']
        for key,folder in {'TRITON_CACHE_DIR':'triton-cache','TORCHINDUCTOR_CACHE_DIR':'inductor-cache','CUDA_CACHE_PATH':'cuda-cache','TORCH_EXTENSIONS_DIR':'extensions-cache','XDG_CACHE_HOME':'xdg-cache','TMPDIR':'tmp'}.items():
            path=out/folder;path.mkdir();env[key]=str(path)
        state['explicit_environment']={k:v for k,v in env.items() if k in receipt['environment'] or k in ('LINGBOT_ROOT','CUDA_VISIBLE_DEVICES','TRITON_PTXAS_PATH','ENABLE_TENSORRT','HF_HUB_OFFLINE','TRANSFORMERS_OFFLINE','HF_DATASETS_OFFLINE')}
        prepared=out/'prepared';capture=out/'capture';capture.mkdir()
        stage('prepare_public',[python,'-I','-m','benchmarks.regression.reproduce','prepare','--model','va','--mode','2v4a-native','--target','rtx4090','--local-files-only','--cache-dir',str(assets/'hf/hub'),'--output',str(prepared)],env,1200)
        recipe=worker_dir/'recipe.py';review=worker_dir/'review.json'
        stage('prepare_two_cell_recipe',[python,'-I',str(recipe),'prepare','--prepared',str(prepared),'--review',str(review),'--output',str(capture)],env,120)
        stage('admit_installed_sources_before',[python,'-I',str(recipe),'sources','--review',str(review),'--output',str(out/'installed_sources_before.json')],env,120)
        gpu_csv=subprocess.check_output(['nvidia-smi','--query-gpu=index,uuid,name,memory.used,utilization.gpu','--format=csv,noheader,nounits'],text=True,timeout=30)
        rows=[r for r in csv.reader(gpu_csv.splitlines()) if r[1].strip()==GPU]
        processes=subprocess.check_output(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'],text=True,timeout=30)
        require(len(rows)==1 and rows[0][2].strip()=='NVIDIA GeForce RTX 4090' and int(rows[0][3])<=64 and int(rows[0][4])==0 and GPU not in processes,'Selected GPU is not idle RTX4090')
        state['GPU_before_csv']=gpu_csv;state['compute_before_csv']=processes;env['CUDA_VISIBLE_DEVICES']=GPU
        for cell in ('va-eager_native-2v4a','va-2v4a-native'):
            stage('capture_'+cell,[python,'-I','-m','benchmarks.regression.user_e2e','--matrix',str(capture/'matrix.json'),'--cell',cell,'--output-root',str(capture),'--fixture',str(prepared/'inputs/recorded_inputs_v1.npz')],env,7200)
        cpu_env=dict(env,CUDA_VISIBLE_DEVICES='')
        stage('admit_installed_sources_after',[python,'-I',str(recipe),'sources','--review',str(review),'--output',str(out/'installed_sources_after.json')],cpu_env,120)
        stage('validate_native_pair',[python,'-I',str(recipe),'validate','--run',str(capture),'--review',str(review),'--parent-run',str(parent/'capture'),'--output',str(out/'validation.json')],cpu_env,180)
        stage('serve_native_2v4a',[python,'-I','-m','benchmarks.regression.serve_smoke','--prepared',str(prepared),'--output',str(out/'serve'),'--cell','va-2v4a-native','--startup-timeout','1800','--request-timeout','1200','--seed','9173'],env,10000)
        stage('validate_serve',[python,'-I',str(recipe),'serve','--run',str(out/'serve'),'--review',str(review),'--output',str(out/'serve_validation.json')],cpu_env,120)
        for path,expected in asset_stats.items():
            stat=Path(path).stat();require([stat.st_dev,stat.st_ino,stat.st_size,stat.st_mtime_ns,stat.st_ctime_ns]==expected,'Original VA asset metadata changed during supplemental run')
        require(sha(completion)==state['parent_completion_sha256'] and sha(assets/'completion.json')==config['assets_completion_sha256'],'Original prior evidence changed')
        state.update(status='complete',passed=True,validation_sha256=sha(out/'validation.json'),serve_validation_sha256=sha(out/'serve_validation.json'))
    except BaseException as error:
        state.update(status='failed_preserved',passed=False,error_type=type(error).__name__,error=str(error),traceback=traceback.format_exc())
    finally:
        if child is not None and child.poll() is None:stop_owned_tree(child)
        for lock in reversed(locks):fcntl.flock(lock,fcntl.LOCK_UN);lock.close()
        for sig,handler in old_handlers.items():signal.signal(sig,handler)
        state.update(lease_released=True,finished_at=utc());save()
        with (out/('completion.json' if state['passed'] else 'failure.json')).open('x') as handle:json.dump(state,handle,indent=2);handle.write('\n')
        print(json.dumps(state),flush=True)
    return 0 if state['passed'] else 1

if __name__=='__main__':sys.exit(run(json.loads(Path(sys.argv[1]).read_text())))
