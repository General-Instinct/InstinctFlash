import csv,datetime,fcntl,hashlib,json,os,pathlib,signal,subprocess,time,traceback
ROOT=pathlib.Path('/workspace/ifl_rtx4090_20260916'); OUT=ROOT/'pi05-model-e2e-v2';SOURCE=ROOT/'source-v5'
INPUTS=pathlib.Path('/dev/shm/ifl_rtx4090_20260916/checkpoints/pi05-native-inputs-v1')
ASSETS=pathlib.Path('/dev/shm/ifl_rtx4090_20260916/checkpoints/pi05-public-assets-v1')
PYTHON=str(ROOT/'families/pi05-v3/env/bin/python'); GPU='GPU-34f3da96-a7b2-ed04-c766-05e7862d940c'
COMMIT='7d69e9c7fd46550a3a105faa53bd372f33db80d3'
state={'schema':'instinctflash.rtx4090_model_e2e.v1','family':'pi05','worker_pid':os.getpid(),'source_commit':COMMIT,'status':'waiting_verified_inputs','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'automatic_retries':0,'GPU_uuid':GPU,'stages':[],'task_quality_validated':False}
locks=[];child=None

def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(name,value):
 p=OUT/name;t=p.with_suffix('.tmp');t.write_text(json.dumps(value,indent=2)+'\n');t.replace(p)
def save():write('status.json',state)
def query(args):return subprocess.check_output(args,text=True,timeout=30).strip()
def stage(name,args,env,timeout):
 global child
 row={'name':name,'command':args,'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'timeout_seconds':timeout};state['stages'].append(row);state['status']=name;save();started=time.monotonic()
 with (OUT/(name+'.log')).open('xb') as log:
  child=subprocess.Popen(args,env=env,cwd=OUT,stdin=subprocess.DEVNULL,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  row['pid']=child.pid;save()
  try:code=child.wait(timeout=timeout)
  except subprocess.TimeoutExpired:
   os.killpg(child.pid,signal.SIGTERM)
   try:child.wait(timeout=15)
   except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
   raise
 row.update(exit_code=code,elapsed_seconds=time.monotonic()-started,log_sha256=sha(OUT/(name+'.log')));save()
 if code:raise RuntimeError(name+' exited '+str(code))
try:
 save();assert query(['git','-C',str(SOURCE),'rev-parse','HEAD'])==COMMIT
 assert json.loads((ROOT/'pi05-core-v5/completion.json').read_text())['passed']
 assert json.loads((ROOT/'sm89-pinned-torch211-v1/report.json').read_text())['passed']
 deadline=time.monotonic()+1800
 while not (INPUTS/'completion.json').is_file():
  if (INPUTS/'failure.json').is_file():raise RuntimeError('Input assembler failed; see preserved evidence')
  if time.monotonic()>deadline:raise TimeoutError('Waiting for verified inputs exceeded1800s')
  time.sleep(5)
 inputs=json.loads((INPUTS/'completion.json').read_text());state['native_inputs_completion_sha256']=sha(INPUTS/'completion.json')
 env={k:v for k,v in os.environ.items() if k not in ('PYTHONPATH','PYTHONHOME') and not k.startswith(('IFL_','UV_','PIP_'))}
 env.update(json.loads((ROOT/'families/pi05-v3/completion.json').read_text())['compiler_preparation']['environment'])
 env.update(CUDA_VISIBLE_DEVICES='',CUDA_DEVICE_ORDER='PCI_BUS_ID',PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1',HF_HUB_OFFLINE='1',TRANSFORMERS_OFFLINE='1',HF_DATASETS_OFFLINE='1')
 for key,name in {'TRITON_CACHE_DIR':'triton-cache','TORCHINDUCTOR_CACHE_DIR':'inductor-cache','CUDA_CACHE_PATH':'cuda-cache','TORCH_EXTENSIONS_DIR':'extensions-cache','XDG_CACHE_HOME':'xdg-cache','TMPDIR':'tmp'}.items():
  p=OUT/name;p.mkdir();env[key]=str(p)
 assets=json.loads((ASSETS/'completion.json').read_text());assert assets['status']=='assets_hash_verified';env.update(assets['environment']);state['assets_completion_sha256']=sha(ASSETS/'completion.json')
 state['prepared_from_prior_run']=str(ROOT/'pi05-model-e2e-v1/prepared');state['prior_failure_preserved']=str(ROOT/'pi05-model-e2e-v1/failure.json')
 # Avoid installation IO during the actual timed cells; VA v2 is the sole CPU installer.
 deadline=time.monotonic()+1200
 while True:
  p=ROOT/'va-bootstrap-v2/status.json'
  s=json.loads(p.read_text()) if p.is_file() else {}
  if s.get('stage') in ('complete','failed_preserved'):break
  if time.monotonic()>deadline:raise TimeoutError('VA installer still active; timing not launched')
  state['status']='waiting_installer_terminal';save();time.sleep(5)
 for p in (pathlib.Path('/tmp/ifl-robolab-renderer-gpu0.lock'), ROOT/'gpu-leases'/(GPU+'.lock')):
  p.parent.mkdir(exist_ok=True);f=p.open('a');fcntl.flock(f,fcntl.LOCK_EX|fcntl.LOCK_NB);locks.append(f)
 before=query(['nvidia-smi','--query-gpu=index,uuid,name,memory.used,utilization.gpu','--format=csv,noheader,nounits']);processes=query(['nvidia-smi','--query-compute-apps=gpu_uuid,pid,process_name,used_memory','--format=csv,noheader,nounits'])
 selected=[row for row in csv.reader(before.splitlines()) if row[1].strip()==GPU];assert len(selected)==1 and int(selected[0][3])<=64 and int(selected[0][4])==0;assert GPU not in processes
 state['GPU_before_csv']=before;state['compute_before_csv']=processes;env['CUDA_VISIBLE_DEVICES']=GPU
 stage('paired_public_api',[PYTHON,'-I','-m','benchmarks.regression.reproduce','run','--prepared',str(ROOT/'pi05-model-e2e-v1/prepared'),'--output',str(OUT/'capture'),'--cell-timeout','7200'],env,22500)
 result=json.loads((OUT/'capture/run.json').read_text());assert result['status']=='passed';state['capture_run_sha256']=sha(OUT/'capture/run.json')
 for cell in ('pi05-runtime_default','pi05-runtime_selected'):
  stage('serve_'+cell,[PYTHON,'-I','-m','benchmarks.regression.serve_smoke','--prepared',str(ROOT/'pi05-model-e2e-v1/prepared'),'--output',str(OUT/('serve_'+cell)),'--cell',cell,'--startup-timeout','1200','--request-timeout','600'],env,6000)
  assert json.loads((OUT/('serve_'+cell)/'receipt.json').read_text())['status']=='passed'
 state.update(status='complete',passed=True);write('completion.json',state)
except BaseException as e:
 state.update(status='failed_preserved',passed=False,error_type=type(e).__name__,error=str(e),traceback=traceback.format_exc());write('failure.json',state)
finally:
 if child is not None and child.poll() is None:
  os.killpg(child.pid,signal.SIGTERM)
  try:child.wait(timeout=15)
  except subprocess.TimeoutExpired:os.killpg(child.pid,signal.SIGKILL);child.wait()
 for f in reversed(locks):fcntl.flock(f,fcntl.LOCK_UN);f.close()
 state['lease_released']=True;state['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save();print(json.dumps(state))
