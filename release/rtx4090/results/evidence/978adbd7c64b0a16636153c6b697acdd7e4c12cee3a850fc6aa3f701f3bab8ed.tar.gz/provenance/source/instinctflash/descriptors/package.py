"""The published form of a checkpoint: directory layout, validation, and `from_pretrained`.

`checkpoint.py` answers *what a checkpoint declares*. This module answers *what a checkpoint IS on
disk*, so that a third party can publish one to the Hugging Face Hub and this runtime can serve it
without either side knowing anything about the other's training code.

THE LAYOUT

    my-checkpoint/
      instinctflash.json          REQUIRED. The declaration. Two namespaces: execution, provenance.
      config.json              REQUIRED. Backbone architecture, as the modelling library expects it.
      model.safetensors        REQUIRED (or a sharded set + model.safetensors.index.json).
      README.md                optional, strongly encouraged. The model card.
      tokenizer/ ...           optional, whatever the backbone needs.

Nothing else is required, and in particular nothing about training is required. A checkpoint is
publishable with `provenance` reduced to `{}` -- see `publishability()`. That is the property that
makes the platform claim true from the author's side: you can ship weights that this runtime serves
without shipping your recipe, your dataset, your teacher, or your loss curves.

WHY A SEPARATE MODULE. `load_declaration()` deliberately reads one file and returns one dataclass. It
should not also know about safetensors shards, Hub repo ids, or what a model card is. Packaging is a
different concern with a different failure mode: `load_declaration` fails when a declaration is wrong,
this fails when a *directory* is not a checkpoint.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from pathlib import Path

from instinctflash.descriptors.checkpoint import (
    FORBIDDEN_IN_EXECUTION, SCHEMA_VERSION, ExecutionDeclaration, load_declaration,
)

#: Read by the runtime. Every one of these must be present for `from_pretrained` to succeed.
REQUIRED = ("instinctflash.json", "config.json")

#: One of these must be present. A sharded checkpoint declares its shards in the index.
#:
#: The diffusers-named INDEX was missing from this list until the first real export tripped over it:
#: a sharded diffusers checkpoint has `diffusion_pytorch_model-0000N-of-0000M.safetensors` plus
#: `diffusion_pytorch_model.safetensors.index.json`, and only the unsharded name was listed. The
#: docstring already promised "or a sharded set + index"; the enumeration just did not match it.
WEIGHTS_ANY = (
    "model.safetensors",
    "model.safetensors.index.json",
    "diffusion_pytorch_model.safetensors",
    "diffusion_pytorch_model.safetensors.index.json",
)

#: Encouraged, never required, never read by the runtime.
OPTIONAL = ("README.md", "LICENSE", "tokenizer", "scheduler", "vae")

#: The smallest `execution` block that can be served. Everything else has a defensible default.
MINIMAL_EXECUTION = ("model_id", "backbone", "servable")


@dataclass(frozen=True)
class PackageReport:
    """What a directory is, and what it is missing. Never raises; the caller decides."""

    path: str
    is_checkpoint: bool
    missing: tuple[str, ...] = ()
    problems: tuple[str, ...] = ()
    notes: tuple[str, ...] = ()
    declaration: ExecutionDeclaration | None = None

    @property
    def ok(self) -> bool:
        return self.is_checkpoint and not self.missing and not self.problems

    def explain(self) -> str:
        out = [f"{self.path}", f"  servable package: {'YES' if self.ok else 'NO'}"]
        if self.declaration is not None:
            d = self.declaration
            out.append(f"  model_id={d.model_id!r} backbone={d.backbone!r} servable={d.servable} "
                       f"{'[LEGACY delta.json]' if d.legacy else ''}")
            if d.output_projection is not None:
                p = d.output_projection
                out.append(f"  output_projection: {p.kind} "
                           f"n_intervals={p.n_intervals} block={p.block} "
                           f"convention={p.velocity_convention}")
        for m in self.missing:
            out.append(f"  MISSING  {m}")
        for p in self.problems:
            out.append(f"  PROBLEM  {p}")
        for n in self.notes:
            out.append(f"  note     {n}")
        return "\n".join(out)


#: peft's adapter layout. adapter_config.json is the manifest; the adapter_model.* file carries
#: ONLY the low-rank deltas. lerobot's peft flow saves the policy's own config.json next to these
#: (`PreTrainedPolicy.push_model_to_hub`: "we need to store the policy config ourselves since PEFT
#: can't"), so an adapter directory carries a PERFECT family fingerprint while carrying none of
#: the weights that fingerprint promises.
PEFT_ADAPTER_MARKERS = ("adapter_config.json", "adapter_model.safetensors", "adapter_model.bin")


def peft_adapter_markers(ckpt_dir: str | Path) -> list[str]:
    """The peft adapter files present in this directory, in marker order. Empty == not an adapter."""
    d = Path(ckpt_dir)
    return [m for m in PEFT_ADAPTER_MARKERS if (d / m).is_file()]


def unmerged_adapter_problem(ckpt_dir: str | Path) -> "str | None":
    """The refusal for an UNMERGED peft/LoRA adapter directory, carrying the exact merge command.

    None when the layout is not adapter-only: no adapter markers, or full weights sit beside them
    (a merged package that kept its adapter residue is a note, not a refusal).

    The refusal exists because every downstream reading of an adapter-only directory is silently
    WRONG, not merely incomplete — measured before this check existed: the family fingerprint
    (config.json) matches the base, `param_bytes` inherits the base's bytes, `base_weights`
    resolves to the PLAIN BASE, and the scaffolded declaration validated and served — answering
    with the base model while the user believes their fine-tune is running. The deltas are the
    fine-tune; a package that drops them on the floor must fail loudly.

    The merge command loads the base with the FINE-TUNE's config (`config=cfg` from this
    directory, use_peft cleared): the trainer saved the trained features there — measured on a
    real lerobot-train LoRA (2026-08-28): merging under the base's own config re-padded
    output_features.action to [32] while the fine-tune's saved postprocessor unnormalizes [7],
    and the merged model failed inside its own pipeline ("size of tensor a (32) must match
    ... b (7)"). Same class of silent-wrong as serving the plain base, one config file later.
    """
    d = Path(ckpt_dir)
    markers = peft_adapter_markers(d)
    if not markers or any((d / w).exists() for w in WEIGHTS_ANY):
        return None
    try:
        base = json.loads((d / "adapter_config.json").read_text()).get("base_model_name_or_path")
    except Exception:                                            # noqa: BLE001 - marker may be absent
        base = None
    base = base if isinstance(base, str) and base else \
        "<the base checkpoint this adapter was trained from>"
    try:
        policy_type = json.loads((d / "config.json").read_text()).get("type")
    except Exception:                                            # noqa: BLE001 - config may be absent
        policy_type = None
    if isinstance(policy_type, str) and policy_type:
        # the loader class comes from the checkpoint's OWN config.json type string — registry
        # data, exactly like the scaffold's family fingerprints, never a model-name branch here.
        merge = (f"python -c \"from lerobot.policies.factory import get_policy_class; "
                 f"from lerobot.configs.policies import PreTrainedConfig; "
                 f"from peft import PeftModel; "
                 f"cfg = PreTrainedConfig.from_pretrained('{d}'); cfg.use_peft = False; "
                 f"base = get_policy_class('{policy_type}').from_pretrained('{base}', config=cfg); "
                 f"PeftModel.from_pretrained(base, '{d}').merge_and_unload()"
                 f".save_pretrained('{d}-merged')\"")
    else:
        merge = (f"python -c \"from peft import PeftModel; "
                 f"base = ...  # load '{base}' with its own modelling library; "
                 f"PeftModel.from_pretrained(base, '{d}').merge_and_unload()"
                 f".save_pretrained('{d}-merged')\"")
    return (f"this is an unmerged LoRA adapter ({', '.join(markers)} present, no full weight "
            f"file): the directory carries the fine-tune's low-rank deltas, not the model, and a "
            f"declaration written here would describe the plain base and silently serve it "
            f"without the fine-tune. Merge into the base first —\n"
            f"      {merge}\n"
            f"    then copy the processor/tokenizer sidecar files next to the merged weights — "
            f"the ones saved BESIDE the adapter when the trainer wrote them (lerobot's peft flow "
            f"does; they carry the fine-tune's own normalization stats), else the base "
            f"package's — and validate the MERGED output")


def _training_layout_hint(d: Path) -> "str | None":
    """One actionable line when a FAILING directory is a training-output tree.

    Trainers write `<run>/transformer/*.safetensors`; the package convention is the transformer
    contents FLAT at the package root, next to the declaration (the layout `materialize()`
    composes from — see adapters/lingbot_va.py). A user pointing `validate` at the training
    output gets "MISSING config.json" and "no local weight files; referenced by base_weights",
    both true and both useless without this line, because the weights are sitting one directory
    down. Only emitted when validation is already failing: a composed upstream package
    legitimately carries a transformer/ component and must not be told to flatten itself.

    Two trainer families are recognized:

      * wan_va-style: `<run>/transformer/*.safetensors` — the package is the flat transformer
        contents at the root; the fix is one `mv`.
      * lerobot-train: `<run>/checkpoints/<step>/pretrained_model/` — the servable checkpoint
        already exists IN FULL one or two levels down; the fix is pointing the command at it.
        Found by fine-tuning pi05 with lerobot-train and serving the run root: "no built-in
        declaration matches this checkpoint" was true and useless while the trained model sat
        under checkpoints/000400/pretrained_model.
    """
    t = d / "transformer"
    if t.is_dir() and any(t.glob("*.safetensors")):
        return ("this looks like a training-output layout: the weight files sit under transformer/. "
                "An InstinctFlash package is the FLAT transformer contents at the package root, next "
                f"to instinctflash.json — run  mv {t}/* {d}/  (config.json and the *.safetensors land "
                "at the root); the frozen vae/text_encoder/tokenizer are never packaged, they come "
                "from the execution.base_weights pointer")
    servable = _lerobot_servable_child(d)
    if servable is not None:
        return (f"this looks like a lerobot-train output: the servable checkpoint the trainer "
                f"wrote is  {servable}  (config.json + weights + the processor pipeline), and "
                f"the levels above it are run bookkeeping. Point the command there:\n"
                f"  instinctflash serve {servable}")
    return None


def _lerobot_servable_child(d: Path) -> "Path | None":
    """The `pretrained_model` dir under a lerobot-train run root or step dir, when this is one.

    lerobot-train writes `<run>/checkpoints/<NNNNNN>/{pretrained_model,training_state}` plus a
    `checkpoints/last` symlink to the newest step, so both the run root and the step dir are
    natural wrong answers to "which directory do I serve". Returns the newest servable child as
    a concrete path: what `last` resolves to when it is valid, else the highest step that
    actually carries a config.json. None when `d` is not this layout.
    """
    if (d / "pretrained_model" / "config.json").is_file():
        return d / "pretrained_model"
    ckpts = d / "checkpoints"
    if not ckpts.is_dir():
        return None
    last = ckpts / "last" / "pretrained_model"
    if (last / "config.json").is_file():
        return last.resolve()
    steps = sorted(p for p in ckpts.iterdir()
                   if (p / "pretrained_model" / "config.json").is_file())
    return (steps[-1] / "pretrained_model").resolve() if steps else None


def validate_package(ckpt_dir: str | Path) -> PackageReport:
    """Check a directory against the published layout. Reports everything, raises nothing."""
    d = Path(ckpt_dir)
    missing: list[str] = []
    problems: list[str] = []
    notes: list[str] = []

    if not d.is_dir():
        return PackageReport(str(d), False, problems=(f"{d} is not a directory",))

    # An unmerged peft adapter GATES, declaration or not: whatever else the directory looks like,
    # serving it means serving the base without the fine-tune. This must outrank the layout
    # diagnostics below, which would truthfully-but-uselessly ask for weight files.
    adapter_problem = unmerged_adapter_problem(d)
    if adapter_problem is not None:
        problems.append(adapter_problem)
    elif peft_adapter_markers(d):
        notes.append("peft adapter files sit next to full weights; the runtime ignores them — "
                     "remove them if the merge already happened, or merge properly if it has not")

    from instinctflash.descriptors.checkpoint import _declaration_file
    has_new, has_old = _declaration_file(d) is not None, (d / "delta.json").exists()
    if not has_new and not has_old:
        if adapter_problem is not None:
            return PackageReport(str(d), False, missing=("instinctflash.json",),
                                 problems=tuple(problems))
        hint = _training_layout_hint(d)
        return PackageReport(str(d), False, missing=("instinctflash.json",),
                             problems=("no declaration: this directory is not a checkpoint",),
                             notes=(hint,) if hint else ())
    if not has_new and has_old:
        notes.append("legacy delta.json. Supported as a compatibility layer; publish instinctflash.json "
                     "for anything new. See `migrate_legacy()`.")

    extra: dict = {}
    try:
        extra = dict(load_declaration(d).extra or {})
    except Exception:                                            # reported below by the real load
        pass
    for f in REQUIRED:
        if f == "instinctflash.json":
            if has_new or has_old:
                continue                       # any accepted declaration name satisfies it
        if f == "config.json":
            # A declaration may state WHERE the backbone config lives: upstream bundles keep the
            # HF checkpoint nested (execution.checkpoint_subdir), and the hub path's
            # `_declared_view` already trusts exactly this fact to expose the nested config. A
            # local copy of such a bundle must validate the same way the hub id does, or the
            # identical bytes pass by repo id and fail by path.
            subdir = extra.get("checkpoint_subdir")
            if isinstance(subdir, str) and subdir and (d / subdir / "config.json").is_file():
                notes.append(f"config.json is at the declared execution.checkpoint_subdir "
                             f"({subdir}/config.json); the adapter loads it from there")
                continue
        if not (d / f).exists():
            missing.append(f)
    # WEIGHTS MAY BE SUPPLIED BY REFERENCE, and until this existed they could not be. `base_weights`
    # was already an execution fact -- LingBot-VA uses it to point at a frozen VAE/text-encoder stack
    # it does not vendor -- but the validator still demanded local weight files, so a declaration
    # could not adopt an upstream checkpoint wholesale. Found by declaring a LeRobot ACT policy:
    # every byte lives in `lerobot/act_...`, and the only sane package is a declaration plus a
    # pointer. Requiring a copy of somebody else's gigabytes to describe them is not a contract, it
    # is a tax. A package with neither local weights nor a pointer is still incomplete.
    has_local = any((d / w).exists() for w in WEIGHTS_ANY)
    pointer = extra.get("base_weights")
    if not has_local and not pointer:
        missing.append(f"weights -- one of {', '.join(WEIGHTS_ANY)}, "
                       f"or an execution.base_weights pointer")
    elif not has_local:
        notes.append(f"no local weight files; they are referenced by "
                     f"execution.base_weights = {pointer!r}. The adapter resolves it at load, so "
                     f"that repo must stay reachable.")
    if not (d / "README.md").exists():
        notes.append("no README.md. Not required, but a published checkpoint without a model card is "
                     "hard to adopt.")

    def finished_notes() -> tuple[str, ...]:
        # The layout hint rides on FAILING reports only, appended last so it reads as the fix.
        hint = _training_layout_hint(d) if (missing or problems) else None
        return tuple([*notes, hint] if hint else notes)

    decl = None
    try:
        decl = load_declaration(d)
    except Exception as e:                                   # the declaration is the whole contract
        problems.append(f"declaration rejected: {e}")
        return PackageReport(str(d), True, tuple(missing), tuple(problems), finished_notes())

    if not decl.servable:
        notes.append("execution.servable is false, so the runtime will refuse to serve it. That is a "
                     "valid thing to publish -- weights people can fine-tune but not serve as-is.")
    for k in MINIMAL_EXECUTION:
        if not getattr(decl, k, None) and k != "servable":
            problems.append(f"execution.{k} is empty; it is part of the minimal serving metadata")

    return PackageReport(str(d), True, tuple(missing), tuple(problems), finished_notes(), decl)


def verify_weights_indexes(ckpt_dir: str | Path) -> list[str]:
    """Integrity of a sharded-weights index: every declared shard exists, inside the package.

    Three failure classes, each of which `validate_package` used to wave through because it reads
    declarations, not weights: a weight_map that is missing or empty, a referenced shard that does
    not exist, and a shard path that escapes the package directory (a symlink or ../ that would
    make a 'validated' package read files it does not contain). Returns problems; empty is good.
    A package with no index file (single-file weights, pointer-only) has nothing to verify.
    """
    root = Path(ckpt_dir)
    problems: list[str] = []
    for name in ("model.safetensors.index.json", "diffusion_pytorch_model.safetensors.index.json"):
        p = root / name
        if not p.is_file():
            continue
        try:
            doc = json.loads(p.read_text())
            weight_map = doc.get("weight_map")
            if not isinstance(weight_map, dict) or not weight_map:
                problems.append(f"{name}: missing non-empty weight_map")
                continue
            for shard in sorted(set(weight_map.values())):
                target = root / str(shard)
                try:
                    target.resolve().relative_to(root.resolve())
                except ValueError:
                    problems.append(f"{name}: shard escapes package: {shard}")
                    continue
                if not target.is_file():
                    problems.append(f"{name}: referenced shard is missing: {shard}")
        except Exception as e:                                   # noqa: BLE001
            problems.append(f"{name}: invalid index: {type(e).__name__}: {e}")
    return problems


def publishability(ckpt_dir: str | Path) -> tuple[bool, list[str]]:
    """Can this be published without exposing training internals?

    Returns (publishable, findings). Publishable means: the runtime can serve it with the
    `provenance` block removed entirely. If that is not true, something the runtime needs is
    currently living in the wrong namespace, which is the failure this whole two-namespace design
    exists to prevent.
    """
    d = Path(ckpt_dir)
    findings: list[str] = []
    from instinctflash.descriptors.checkpoint import _declaration_file
    p = _declaration_file(d)
    if p is None:
        return False, [f"{d}: no instinctflash.json. The legacy delta.json format has one flat namespace, "
                       f"so it cannot be published without also publishing training keys."]
    doc = json.loads(p.read_text())
    ex = dict(doc.get("execution") or {})

    leaked = sorted(k for k in FORBIDDEN_IN_EXECUTION if k in ex)
    if leaked:
        findings.append(f"execution block carries provenance keys {leaked} -- move them to provenance")

    # the real test: strip provenance and see whether it still loads and still declares enough
    stripped = {"instinctflash_schema": doc.get("instinctflash_schema", SCHEMA_VERSION), "execution": ex}
    import tempfile
    with tempfile.TemporaryDirectory() as td:
        (Path(td) / "instinctflash.json").write_text(json.dumps(stripped))
        try:
            decl = load_declaration(td)
        except Exception as e:
            findings.append(f"with provenance removed the declaration no longer loads: {e}")
            return False, findings
    if not decl.servable:
        findings.append("servable=false with provenance removed; the runtime would refuse it")

    prov = dict(doc.get("provenance") or {})
    if prov:
        findings.append(f"provenance present with {len(prov)} keys -- it will be published unless you "
                        f"remove it. The runtime never reads it either way.")
    return not any(f.startswith(("execution block carries", "with provenance removed")) for f in findings), findings


def migrate_legacy(ckpt_dir: str | Path, *, write: bool = False) -> dict:
    """Produce the `instinctflash.json` equivalent of a legacy `delta.json`.

    The execution block is what `_from_legacy_delta` already derives; everything else in the flat
    file becomes provenance, because the legacy format could not tell the difference and guessing
    the other way round would move a training key into the namespace the runtime reads.
    """
    from instinctflash.descriptors.checkpoint import provenance_of
    d = Path(ckpt_dir)
    decl = load_declaration(d)
    ex: dict = {"model_id": decl.model_id, "backbone": decl.backbone, "servable": decl.servable}
    if decl.guidance:
        ex["guidance"] = dict(decl.guidance)
    if decl.nfe:
        ex["nfe"] = dict(decl.nfe)
    if decl.output_projection is not None:
        p = decl.output_projection
        ex["output_projection"] = {"kind": p.kind, "n_intervals": p.n_intervals, "block": p.block,
                                   "velocity_convention": p.velocity_convention,
                                   "foldable": p.foldable}
    doc = {"instinctflash_schema": SCHEMA_VERSION, "execution": ex, "provenance": provenance_of(d)}
    if write:
        (d / "instinctflash.json").write_text(json.dumps(doc, indent=2) + "\n")
    return doc


@dataclass(frozen=True)
class Checkpoint:
    """A validated, servable checkpoint. Holds execution facts and a path; never provenance."""

    path: str
    execution: ExecutionDeclaration
    report: PackageReport = field(repr=False, default=None)  # type: ignore[assignment]

    @property
    def model_id(self) -> str:
        return self.execution.model_id

    def capabilities(self) -> frozenset[str]:
        """The capability tokens the runtime may plan against.

        Derived ONLY from the execution block. A planner that wants to know whether some optimization
        applies asks this; it never asks how the checkpoint was trained, because there is nothing here
        that could answer.
        """
        caps = set()
        if self.execution.servable:
            caps.add("servable")
        if self.execution.backbone:
            caps.add(f"backbone:{self.execution.backbone}")
        p = self.execution.output_projection
        if p is not None and p.kind:
            caps.add(f"output_projection:{p.kind}")
            if p.foldable:
                caps.add("output_projection:foldable")
        from instinctflash.descriptors.guidance import capability_token
        for k, v in (self.execution.guidance or {}).items():
            # the mode-string form keeps its historical token (guidance:video=cfg); a declared
            # scale is part of the token (guidance:video=cfg@3) -- a plan must tell w=3 from w=5
            caps.add(capability_token(k, v))
        for k in (self.execution.extra or {}):
            caps.add(f"declares:{k}")
        return frozenset(caps)


def _declared_view(snapshot: Path, model_id: str, doc: dict) -> Path:
    """A checkpoint directory for an upstream snapshot that carries no declaration.

    Symlinks every snapshot entry (weights stay in the HF cache, nothing is copied or mutated)
    and writes the known declaration next to them. A snapshot and declaration own an
    immutable view: loading another revision cannot change an existing runtime's files.
    """
    import json as _json
    import os
    import hashlib
    import shutil
    import tempfile
    snapshot = snapshot.absolute()
    declaration = _json.dumps(doc, sort_keys=True, indent=1)
    key = hashlib.sha256((str(snapshot) + "\0" + declaration).encode()).hexdigest()
    base = Path(os.environ.get("XDG_CACHE_HOME") or Path.home() / ".cache")
    parent = base / "instinctflash" / "declared" / model_id.replace("/", "__")
    parent.mkdir(parents=True, exist_ok=True)
    view = parent / key
    if view.is_dir():
        if (view / "instinctflash.json").read_text() != declaration:
            raise RuntimeError(f"Declared checkpoint cache was modified: {view}")
        return view
    # Build beside the destination and publish the complete tree with one rename.
    # Concurrent readers never observe a half-populated checkpoint.
    temporary = Path(tempfile.mkdtemp(prefix=".building-", dir=parent))
    try:
        _populate_declared_view(temporary, snapshot, doc, declaration)
        try:
            temporary.rename(view)
        except OSError:
            if not view.is_dir() or (view / "instinctflash.json").read_text() != declaration:
                raise
        return view
    finally:
        if temporary.exists():
            shutil.rmtree(temporary)


def _populate_declared_view(view: Path, snapshot: Path, doc: dict, declaration: str) -> None:
    for entry in snapshot.iterdir():
        (view / entry.name).symlink_to(entry)
    if not (view / "config.json").exists() and (snapshot / "transformer" / "config.json").exists():
        # diffusers-composed upstream layout: the backbone architecture config lives under
        # transformer/; the package contract wants it at top level, and it is the same file
        (view / "config.json").symlink_to(snapshot / "transformer" / "config.json")
    # Some upstream repositories are release bundles rather than flat HF checkpoints. Their
    # declaration names the directory that contains the actual model. Validation still wants a
    # root config, while the adapter needs the original nested layout for neighbouring metadata.
    execution = dict(doc.get("execution") or {})
    subdir = execution.get("checkpoint_subdir")
    nested = snapshot / str(subdir) if subdir else None
    if (not (view / "config.json").exists() and nested is not None
            and (nested / "config.json").exists()):
        (view / "config.json").symlink_to(nested / "config.json")
    (view / "instinctflash.json").write_text(declaration)


def from_pretrained(model_id_or_path: str | Path, *, revision: str | None = None,
                    require_servable: bool = True) -> Checkpoint:
    """Load a checkpoint by local path, or by Hub repo id if `huggingface_hub` is installed.

    Reads the EXECUTION block only. There is no argument that selects a training method, and no code
    path in this function that could branch on one -- `load_declaration` does not return provenance,
    so there is nothing to branch on.

    `require_servable=False` is for tooling that wants to inspect a checkpoint it will not serve.
    """
    p = Path(model_id_or_path)
    if not p.exists():
        try:
            from huggingface_hub import snapshot_download        # optional dependency
        except ImportError as e:
            raise RuntimeError(
                f"{model_id_or_path!r} is not a local directory and huggingface_hub is not installed, "
                f"so it cannot be resolved as a Hub repo id. Install huggingface_hub, or pass a path."
            ) from e
        download_options = {"revision": revision}
        # A commit hash can skip Hub revision resolution. Some Hub versions
        # then attempt a tree request even with HF_HUB_OFFLINE enabled, so
        # explicitly select the local snapshot branch for offline deployments.
        if os.environ.get("HF_HUB_OFFLINE", "").upper() in {"1", "ON", "YES", "TRUE"}:
            download_options["local_files_only"] = True
        p = Path(snapshot_download(str(model_id_or_path), **download_options))
        from instinctflash.descriptors.checkpoint import _declaration_file
        if _declaration_file(p) is None:
            # A known upstream release: its authors publish weights without a declaration, and we
            # serve them without republishing. Materialize a declared view — symlinks into the HF
            # snapshot plus our declaration — so every check below runs unchanged on it.
            from instinctflash.descriptors.known import lookup
            doc = lookup(str(model_id_or_path))
            if doc is not None:
                p = _declared_view(p, str(model_id_or_path), doc)

    report = validate_package(p)
    if not report.is_checkpoint or report.declaration is None:
        raise RuntimeError(f"{p} is not a servable checkpoint:\n{report.explain()}")
    if report.missing or report.problems:
        raise RuntimeError(f"{p} is incomplete:\n{report.explain()}")
    if require_servable:
        report.declaration.require_servable(f"from_pretrained({model_id_or_path!r})")
    return Checkpoint(str(p), report.declaration, report)


if __name__ == "__main__":                                   # python -m instinctflash.descriptors.package
    import sys as _s
    if len(_s.argv) != 2:
        print("usage: python -m instinctflash.descriptors.package <checkpoint-dir>")
        raise SystemExit(2)
    _rep = validate_package(_s.argv[1])
    print(_rep.explain())
    _ok, _find = (False, ["not an instinctflash.json package"])
    try:
        _ok, _find = publishability(_s.argv[1])
    except Exception as _e:                                  # noqa: BLE001
        _find = [str(_e)]
    print(f"  publishable without training internals: {'YES' if _ok else 'NO'}")
    for _f in _find:
        print(f"    - {_f}")
    raise SystemExit(0 if _rep.ok else 1)
