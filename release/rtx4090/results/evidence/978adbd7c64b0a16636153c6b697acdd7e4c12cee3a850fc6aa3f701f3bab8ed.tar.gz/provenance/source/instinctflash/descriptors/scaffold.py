"""Scaffolding a fine-tune's declaration from a built-in base: copy, infer, or say FILL_ME.

`instinctflash validate <dir> --validate.scaffold=<base-hub-id|auto>` is the one-command path from
"a training output with no declaration" to "a package `validate` can judge". The scaffold copies
the base's built-in declaration (`known.KNOWN_DECLARATIONS`), then goes field by field:

    inherited   copied from the base — facts a fine-tune keeps (step schedule, servable) unless
                its author says otherwise. Guidance is inherited too, and CLASSIFIED honestly:
                a per-stream guidance scale is a SERVING choice (the operating point's second
                leg), not a training fact and not a base invariant — so it is inheritable, but
                the scaffold prints the resolved (mode@scale, CFG batching) it will serve.
    inferred    read out of the checkpoint ITSELF, with the evidence quoted: backbone identity
                from config.json fingerprints, param_bytes measured from the weight files,
                pi05 obs_features from the checkpoint's own input_features reconciled with its
                trained normalizer stats (the stats are the wire contract), and so on.
    FILL_ME     a fact the checkpoint does not carry and the scaffold refuses to guess. Written
                into the file as the literal string "FILL_ME" so the follow-up validate flags
                every one of them; each carries a one-line explanation of what belongs there.

THE RULE IS THE SAME ONE THE ADAPTERS ENFORCE AT SERVE TIME: auto-fill only what is provable.
The wan_va adapter refuses to serve guessed camera geometry (`resolve_observation_geometry`),
the pi05 adapter refuses a fine-tune without `obs_features`, cosmos3 refuses a missing serving
config — so the scaffold writing a plausible-looking wrong value would just move the failure
from a loud refusal to silently wrong conditioning. FILL_ME keeps it loud.

Inference depth is per family and stated in the output, because it genuinely differs: a pi05
checkpoint states its own observation contract in config.json; a wan_va training output does not
carry its cameras anywhere the scaffold can read.
"""

from __future__ import annotations

import copy
import json
import os
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Mapping

from instinctflash.descriptors.checkpoint import _declaration_file
from instinctflash.descriptors.known import KNOWN_DECLARATIONS, lookup

#: The sentinel a scaffolded declaration carries for every fact it could not prove. `validate`
#: flags each occurrence as a PROBLEM, and the adapters treat it as "not declared" (never as a
#: value), so a half-filled scaffold cannot serve.
FILL_ME = "FILL_ME"

INHERITED, INFERRED, TO_FILL = "inherited", "inferred", "FILL_ME"


class ScaffoldError(ValueError):
    """The scaffold refuses: unknown base, no fingerprint match, or an ambiguous match."""


@dataclass(frozen=True)
class ScaffoldField:
    """One execution-block field and how the scaffold decided it."""

    key: str
    status: str      # INHERITED | INFERRED | TO_FILL
    value: Any
    #: evidence for an inferred value, the one-line "what belongs here" for a FILL_ME,
    #: context for an inherited value.
    note: str


@dataclass(frozen=True)
class ScaffoldPlan:
    """A scaffolded declaration document plus the per-field record of how it was built."""

    path: str
    base_id: str
    backbone: str
    #: one honest sentence: what this family's scaffold can prove and what it cannot.
    depth: str
    fields: tuple[ScaffoldField, ...]
    document: dict

    def counts(self) -> dict:
        return {s: sum(1 for f in self.fields if f.status == s)
                for s in (INFERRED, INHERITED, TO_FILL)}

    def explain(self) -> str:
        c = self.counts()
        out = [f"declaration scaffold: base {self.base_id} -> {self.path}",
               f"  inference depth for backbone {self.backbone!r}: {self.depth}"]
        for f in self.fields:
            if f.status == TO_FILL:
                out.append(f"  FILL_ME    {f.key:18} — {f.note}")
            else:
                v = json.dumps(f.value, ensure_ascii=False)
                if len(v) > 58:
                    v = v[:55] + "..."
                out.append(f"  {f.status:9}  {f.key:18} = {v}" + (f"   [{f.note}]" if f.note else ""))
        out.append(f"  {c[INFERRED]} inferred, {c[INHERITED]} inherited, {c[TO_FILL]} to fill")
        return "\n".join(out)

    def to_result(self) -> dict:
        return {"base": self.base_id, "backbone": self.backbone, "depth": self.depth,
                "fields": [{"key": f.key, "status": f.status, "value": f.value, "note": f.note}
                           for f in self.fields]}


# --- reading the checkpoint ----------------------------------------------------------------------

def _json_at(d: Path, rel: str) -> dict:
    p = d / rel
    if not p.is_file():
        return {}
    try:
        doc = json.loads(p.read_text())
    except Exception:                                            # noqa: BLE001 - fingerprints only
        return {}
    return doc if isinstance(doc, dict) else {}


def _first_config(d: Path, names: tuple[str, ...]) -> tuple[dict, str]:
    for rel in names:
        cfg = _json_at(d, rel)
        if cfg:
            return cfg, rel
    return {}, ""


def _measure_weights(d: Path, subdir: str = "") -> "tuple[int, str] | None":
    """Total bytes of the weight files under `d/subdir`, and which files were measured.

    File sizes (`st_size`, symlinks followed), matching how every built-in declaration's
    `param_bytes` was produced — the fans export and lerobot/pi05_libero_finetuned_v044 both
    equal the safetensors file size exactly. Sharded sets are enumerated through their index so
    processor-pipeline safetensors sitting next to the model are never miscounted as weights.
    """
    root = d / subdir if subdir else d
    for index_name, single_name in (("model.safetensors.index.json", "model.safetensors"),
                                    ("diffusion_pytorch_model.safetensors.index.json",
                                     "diffusion_pytorch_model.safetensors")):
        idx = _json_at(root, index_name)
        shards = sorted(set((idx.get("weight_map") or {}).values()))
        if shards:
            present = [root / s for s in shards if (root / s).is_file()]
            if present:
                total = sum(p.stat().st_size for p in present)
                where = f"{subdir}/" if subdir else ""
                return total, f"{len(present)} shards of {where}{index_name}"
        p = root / single_name
        if p.is_file():
            where = f"{subdir}/" if subdir else ""
            return p.stat().st_size, f"{where}{single_name}"
    return None


# --- per-family knowledge -------------------------------------------------------------------------
#
# One entry per backbone. `detect` fingerprints the checkpoint's own files and names the base
# entry (or entries) it matches; `build` returns the family-specific field decisions. Both read
# the same facts the family's adapter reads at serve time — the scaffold is those adapters'
# declaration knowledge applied at packaging time, not a second opinion.

@dataclass(frozen=True)
class _Family:
    backbone: str
    #: e.g. 'config.json with type == "pi05"' — quoted in refusals so the user knows what was
    #: looked for and where.
    fingerprint: str
    detect: Callable[[Path], list]           # -> [(base_id, evidence)], len>1 == ambiguous
    build: Callable[[Path, Mapping, str], dict]
    depth: str
    #: True when `detect` distinguishes between this family's base ids (cosmos3 Edge vs Nano),
    #: so an explicit base contradicting the fingerprint is refused rather than obeyed.
    strict_ids: bool = False


def _local_pointer(d: Path, decisions: dict, evidence: str) -> None:
    """base_weights = this directory, when the package itself carries what the loader needs."""
    decisions["base_weights"] = ScaffoldField(
        "base_weights", INFERRED, str(d.resolve()),
        evidence + " — replace with the published repo id when you upload this package")


# wan_va ------------------------------------------------------------------------------------------

_WAN_CONFIGS = ("config.json", "transformer/config.json")


def _detect_wan_va(d: Path) -> list:
    cfg, src = _first_config(d, _WAN_CONFIGS)
    if cfg.get("_class_name") == "WanTransformer3DModel" and "action_dim" in cfg:
        return [("robbyant/lingbot-va-posttrain-robotwin",
                 f"{src}: _class_name=WanTransformer3DModel with action_dim={cfg['action_dim']} "
                 f"(a plain Wan transformer has no action head)")]
    return []


#: Why each wan_va geometry key is FILL_ME: they are training facts (wan_va/configs/*.py) the
#: checkpoint does not carry, and the adapter's own rule is declare-or-fail-loud, never guess —
#: the base's robotwin values are deliberately NOT inherited, because serving a fine-tune under
#: another robot's cameras corrupts conditioning with no warning. Each note quotes the base's
#: value, so filling them for a same-robot fine-tune is a copy, not a search.
_WAN_GEOMETRY_REASONS = {
    "obs_cam_keys": "the camera keys this fine-tune was trained on — copy obs_cam_keys from your "
                    "wan_va training config; the base's robotwin cameras "
                    "(observation.images.cam_high/cam_left_wrist/cam_right_wrist) are not "
                    "inherited because a wrong camera list silently corrupts conditioning",
    "height": "native frame height from your training config (base declares 256)",
    "width": "native frame width from your training config (base declares 320)",
    "env_type": "view compositing mode from your training config, e.g. 'none' or "
                "'robotwin_tshape' (base declares 'robotwin_tshape')",
}

#: The keys `_wan_training_cfg` may read, and the literal type each must parse as. Geometry the
#: adapter refuses to guess, plus the two denoise-step counts the upstream config states.
_WAN_TRAIN_CFG_TYPES = {
    "obs_cam_keys": list, "height": int, "width": int, "env_type": str,
    "num_inference_steps": int, "action_num_inference_steps": int,
}


def _wan_training_cfg(d: Path) -> "tuple[dict, dict]":
    """Facts read from a wan_va training-config artifact shipped IN the package, if any.

    Real training-output dirs often carry the config that produced them. The upstream format is
    a module of EasyDict attribute assignments (``cfg.obs_cam_keys = [...]``) whose values are
    literals, so a static ``ast`` parse can read them — the file is never imported or executed.
    Returns ``({key: value}, {key: evidence})``. A key assigned two different literals (in one
    file or across files) is dropped: evidence that disagrees with itself proves nothing, and
    the key stays FILL_ME with the disagreement noted.
    """
    import ast

    values: dict = {}
    sources: dict = {}
    conflicted: set = set()
    for p in sorted(d.glob("*.py")):
        try:
            tree = ast.parse(p.read_text())
        except Exception:                                        # noqa: BLE001 - not a config artifact
            continue
        for node in ast.walk(tree):
            if not isinstance(node, ast.Assign):
                continue
            for tgt in node.targets:
                key = (tgt.attr if isinstance(tgt, ast.Attribute)
                       else tgt.id if isinstance(tgt, ast.Name) else None)
                want = _WAN_TRAIN_CFG_TYPES.get(key or "")
                if want is None:
                    continue
                try:
                    val = ast.literal_eval(node.value)
                except Exception:                                # noqa: BLE001 - not a literal
                    continue
                if not isinstance(val, want) or isinstance(val, bool):
                    continue
                if want is list and not (val and all(isinstance(x, str) for x in val)):
                    continue
                if key in values and values[key] != val:
                    conflicted.add(key)
                    continue
                values[key] = val
                sources[key] = (f"{p.name}: {key} = {json.dumps(val, ensure_ascii=False)} "
                                f"(training-config artifact shipped in the package)")
    for key in conflicted:
        values.pop(key, None)
        sources[key] = "conflicting values across the package's training-config artifacts"
    return values, sources


def _build_wan_va(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    m = _measure_weights(d) or _measure_weights(d, "transformer")
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
    frozen = ("vae", "text_encoder", "tokenizer")
    if all((d / c).is_dir() for c in frozen):
        _local_pointer(d, decisions, f"{', '.join(c + '/' for c in frozen)} are present, so the "
                                     f"package carries its own frozen stack")
    else:
        decisions["base_weights"] = ScaffoldField(
            "base_weights", INHERITED, base_ex.get("base_weights"),
            "the frozen vae/text_encoder/tokenizer are fetched from this pointer at load")
    cfg_vals, cfg_src = _wan_training_cfg(d)
    for key, why in _WAN_GEOMETRY_REASONS.items():
        if key in cfg_vals:
            decisions[key] = ScaffoldField(key, INFERRED, cfg_vals[key], cfg_src[key])
        else:
            conflict = cfg_src.get(key)
            decisions[key] = ScaffoldField(key, TO_FILL, FILL_ME,
                                           f"{why} ({conflict})" if conflict else why)
    steps = cfg_vals.get("num_inference_steps"), cfg_vals.get("action_num_inference_steps")
    if all(isinstance(s, int) and s > 0 for s in steps):
        decisions["nfe"] = ScaffoldField(
            "nfe", INFERRED, {"video": steps[0], "action": steps[1]},
            f"{cfg_src['num_inference_steps'].split(':')[0]}: num_inference_steps / "
            f"action_num_inference_steps — the schedule this fine-tune was configured with, "
            f"not the base's operating point")
    return decisions


# pi05 --------------------------------------------------------------------------------------------

def _detect_pi05(d: Path) -> list:
    cfg = _json_at(d, "config.json")
    if cfg.get("type") == "pi05":
        return [("lerobot/pi05_base", 'config.json: type == "pi05"')]
    return []


def _pi05_input_features(d: Path) -> "tuple[dict, str, dict] | None":
    for rel, getter in (("config.json", lambda c: c.get("input_features")),
                        ("train_config.json",
                         lambda c: (c.get("policy") or {}).get("input_features"))):
        feats = getter(_json_at(d, rel))
        if isinstance(feats, dict) and feats:
            try:
                shapes = {str(k): [int(x) for x in v["shape"]] for k, v in feats.items()}
                types = {str(k): str(v.get("type") or "") for k, v in feats.items()}
            except Exception:                                    # noqa: BLE001 - not the shape we know
                continue
            return shapes, rel, types
    return None


def _safetensors_header(p: Path) -> "dict | None":
    """A safetensors file's JSON header (tensor name -> dtype/shape/offsets), read without torch."""
    try:
        with p.open("rb") as f:
            n = int.from_bytes(f.read(8), "little")
            if not 0 < n <= 100_000_000:
                return None
            doc = json.loads(f.read(n).decode("utf-8"))
        return doc if isinstance(doc, dict) else None
    except Exception:                                            # noqa: BLE001 - evidence, not a gate
        return None


def _pi05_trained_state_dims(d: Path, state_keys) -> dict:
    """{state key: (dim, stats filename)} as the checkpoint's TRAINED normalizer stats carry it.

    lerobot >= 0.6 keeps the policy's own (padded) input_features in the fine-tune's config.json
    — pi05_base declares observation.state [32], max_state_dim — while the saved preprocessor
    normalizes the wire observation with dataset-shaped stats BEFORE the policy pads it. The
    stats tensors are the arithmetic the model actually applies, so they are the wire contract;
    a declaration transcribing config.json's [32] builds observations the checkpoint's own
    pipeline rejects ("size of tensor a (32) must match ... b (8)" — the first real lerobot-train
    fine-tune served, 2026-08-28). Image stats are per-channel [C,1,1], not geometry, so only
    STATE keys are read. Older exports (pi05_libero_finetuned_v044) already agree with their
    stats and are unchanged by construction.
    """
    out: dict = {}
    for p in sorted(d.glob("policy_preprocessor_step_*_normalizer_processor.safetensors")):
        header = _safetensors_header(p) or {}
        for k in state_keys:
            ent = header.get(f"{k}.mean")
            shape = ent.get("shape") if isinstance(ent, dict) else None
            if isinstance(shape, list) and len(shape) == 1:
                out.setdefault(k, (int(shape[0]), p.name))
    return out


def _build_pi05(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    cfg = _json_at(d, "config.json")
    feats = _pi05_input_features(d)
    if feats:
        shapes, rel, types = feats
        evidence = (f"{rel} input_features ({len(shapes)} keys) — the same source the two "
                    f"built-in pi05 declarations were transcribed from")
        trained = _pi05_trained_state_dims(d, [k for k, t in types.items() if t == "STATE"])
        for key, (dim, src) in trained.items():
            if shapes.get(key) != [dim]:
                evidence += (f"; {key} {shapes.get(key)} -> [{dim}] from the trained normalizer "
                             f"stats ({src}): lerobot keeps the policy's padded dim in "
                             f"input_features, but the saved preprocessor normalizes the wire "
                             f"observation BEFORE padding, so the stats' dim is the contract")
                shapes[key] = [dim]
        decisions["obs_features"] = ScaffoldField("obs_features", INFERRED, shapes, evidence)
    else:
        decisions["obs_features"] = ScaffoldField(
            "obs_features", TO_FILL, FILL_ME,
            "observation key -> per-observation shape; your checkpoint's config.json / "
            "train_config.json carries it as input_features")
    if isinstance(cfg.get("num_inference_steps"), int):
        decisions["nfe"] = ScaffoldField(
            "nfe", INFERRED, {"prefix": 1, "action": int(cfg["num_inference_steps"])},
            "config.json num_inference_steps")
    if (d / "policy_preprocessor.json").is_file() and _measure_weights(d):
        _local_pointer(d, decisions, "model.safetensors + policy_preprocessor.json are present, "
                                     "so the package is the loadable policy")
    m = _measure_weights(d)
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
    return decisions


# groot_n17 ---------------------------------------------------------------------------------------

def _sole_metadata_tag(d: Path) -> "str | None":
    meta = _json_at(d, "experiment_cfg/metadata.json")
    return list(meta)[0] if len(meta) == 1 else None


def _detect_groot(d: Path) -> list:
    cfg = _json_at(d, "config.json")
    if cfg.get("type") == "groot":
        return [("nvidia/GR00T-N1.7-3B", 'config.json: type == "groot" (the lerobot-converted '
                                         "layout)")]
    if cfg.get("model_type") == "Gr00tN1d7" or "Gr00tN1d7" in (cfg.get("architectures") or []):
        return [("nvidia/GR00T-N1.7-3B", 'config.json: model_type == "Gr00tN1d7" (the native '
                                         "Isaac-GR00T N1.7 release layout)")]
    return []


def _build_groot(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    cfg = _json_at(d, "config.json")
    # The evidence chain for the action-space head, strongest first: the checkpoint's own
    # config.json, the sole key of the lerobot-converted metadata, the sole key of the native
    # layout's statistics.json. A multi-head statistics.json is genuinely ambiguous — the
    # scaffold lists this checkpoint's own candidates rather than picking one.
    stats = _json_at(d, "statistics.json")
    tag = (cfg.get("embodiment_tag") or _sole_metadata_tag(d)
           or (list(stats)[0] if len(stats) == 1 else None))
    if tag:
        src = ("config.json embodiment_tag" if cfg.get("embodiment_tag")
               else "the sole statistics key of experiment_cfg/metadata.json"
               if _sole_metadata_tag(d) else "the sole statistics key of statistics.json")
        decisions["embodiment_tag"] = ScaffoldField("embodiment_tag", INFERRED, str(tag), src)
    else:
        candidates = (f"; this checkpoint's own statistics.json carries {len(stats)} heads to "
                      f"choose from: {', '.join(sorted(stats))}" if len(stats) > 1
                      else " (your training config states it)")
        decisions["embodiment_tag"] = ScaffoldField(
            "embodiment_tag", TO_FILL, FILL_ME,
            "names the action-space head; the base's OXE_DROID_RELATIVE_EEF_RELATIVE_JOINT tag "
            "is not inherited because a fine-tune usually retargets it" + candidates)
    if isinstance(cfg.get("num_inference_timesteps"), int):
        decisions["nfe"] = ScaffoldField(
            "nfe", INFERRED, {"backbone": 1, "action": int(cfg["num_inference_timesteps"])},
            "config.json num_inference_timesteps")
    m = _measure_weights(d)
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
        _local_pointer(d, decisions, "local weights are present")
    return decisions


# the GEAR-Dreams WAM (backbone string "dreamzero") --------------------------------------------
#
# Identifiers below avoid the model name on purpose: test_checkpoint_platform forbids executable
# identifiers under descriptors/ naming a model, and the invariant it protects holds here — the
# family knowledge is REGISTRY DATA keyed by the backbone string, exactly like known.py, never a
# code branch on a model name.

def _detect_gear_wam(d: Path) -> list:
    cfg = _json_at(d, "config.json")
    if (cfg.get("model_type") == "vla" and cfg.get("architectures") == ["VLA"]
            and "action_horizon" in cfg):
        return [("GEAR-Dreams/DreamZero-DROID",
                 f"config.json: model_type=vla, architectures=[VLA], "
                 f"action_horizon={cfg['action_horizon']}")]
    return []


def _build_gear_wam(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    tag = _sole_metadata_tag(d)
    if tag:
        decisions["embodiment_tag"] = ScaffoldField(
            "embodiment_tag", INFERRED, str(tag),
            "the sole statistics key of experiment_cfg/metadata.json")
    else:
        meta = _json_at(d, "experiment_cfg/metadata.json")
        candidates = (f" — this checkpoint's own metadata carries {len(meta)}: "
                      f"{', '.join(sorted(meta))}" if len(meta) > 1 else "")
        decisions["embodiment_tag"] = ScaffoldField(
            "embodiment_tag", TO_FILL, FILL_ME,
            "which experiment_cfg/metadata.json statistics entry this checkpoint acts as "
            f"(several are present, so the scaffold refuses to pick{candidates}; "
            f"the DROID base declares 'oxe_droid')")
    decisions["dynamic_cache_schedule"] = ScaffoldField(
        "dynamic_cache_schedule", INHERITED, bool(base_ex.get("dynamic_cache_schedule", False)),
        "upstream's velocity-cosine skipper: SCREEN-tier, it changes outputs, never default-on")
    m = _measure_weights(d)
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
        _local_pointer(d, decisions, "local weights are present")
    return decisions


# cosmos3_policy ----------------------------------------------------------------------------------

def _detect_cosmos3(d: Path) -> list:
    cfg = _json_at(d, "config.json")
    if cfg.get("model_type") != "cosmos3_omni":
        return []
    tower = (cfg.get("text_config") or {}).get("model_type")
    if tower == "cosmos3_edge_text":
        return [("nvidia/Cosmos3-Edge-Policy-DROID",
                 "config.json: model_type=cosmos3_omni with an Edge text tower "
                 "(text_config.model_type=cosmos3_edge_text)")]
    if tower == "qwen3_vl_text":
        return [("nvidia/Cosmos3-Nano-Policy-DROID",
                 "config.json: model_type=cosmos3_omni with the Nano text tower "
                 "(text_config.model_type=qwen3_vl_text)")]
    # cosmos3_omni without a text tower the fingerprint knows: genuinely ambiguous.
    return [("nvidia/Cosmos3-Edge-Policy-DROID",
             "config.json: model_type=cosmos3_omni; the text tower does not identify Edge vs Nano"),
            ("nvidia/Cosmos3-Nano-Policy-DROID",
             "config.json: model_type=cosmos3_omni; the text tower does not identify Edge vs Nano")]


#: All five serving keys are per-checkpoint measurement facts the adapter refuses to guess
#: (`REQUIRED_SERVING_KEYS` in examples/cosmos3_policy) — so the scaffold does too. The base's
#: DROID values are quoted so filling them for a DROID fine-tune is a copy, not a search.
_COSMOS3_SERVING_REASONS = {
    "domain_name": "the data domain the server's normalization/decoding uses "
                   "(the DROID base declares 'droid_lerobot')",
    "action_dim": "the robot's action dimensionality, as trained (DROID base: 8)",
    "action_chunk_size": "actions returned per request, as trained (DROID base: 16)",
    "image_height": "the request image height the service enforces (DROID base: 540)",
    "image_width": "the request image width the service enforces (DROID base: 640)",
}


def _build_cosmos3(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    # checkpoint.json is upstream's own serving artifact (its policy block is what the Cosmos3
    # inference stack reads), so a policy fact stated there is checkpoint evidence, not a guess.
    # The Edge DROID release states domain_name and action_chunk_size; the Nano release ships an
    # empty checkpoint.json, and its keys honestly stay FILL_ME.
    policy = _json_at(d, "checkpoint.json").get("policy")
    policy = policy if isinstance(policy, dict) else {}
    for key, why in _COSMOS3_SERVING_REASONS.items():
        val = policy.get(key)
        want = str if key == "domain_name" else int
        if isinstance(val, want) and not isinstance(val, bool):
            note = f"checkpoint.json policy.{key} — upstream's own serving artifact"
            if key in base_ex and base_ex[key] != val:
                note += (f" (differs from the DROID base declaration's measured "
                         f"{json.dumps(base_ex[key])})")
            decisions[key] = ScaffoldField(key, INFERRED, val, note)
        else:
            decisions[key] = ScaffoldField(key, TO_FILL, FILL_ME, why)
    m = _measure_weights(d)
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
        _local_pointer(d, decisions, "local weights are present")
    return decisions


# lingbot_vla / lingbot_vla_v2 ---------------------------------------------------------------------

def _detect_lingbot_vla(d: Path) -> list:
    cfg = _json_at(d, "config.json")
    if cfg.get("type") == "pi0" and (d / "lingbotvla_cli.yaml").is_file():
        return [("robbyant/lingbot-vla-4b-posttrain-robotwin",
                 'config.json: type == "pi0" next to lingbotvla_cli.yaml (the upstream '
                 "LingBot-VLA release layout)")]
    return []


def _lingbot_cli_data(d: Path) -> dict:
    """The `data:` block of lingbotvla_cli.yaml — the training config the upstream release ships
    next to its weights, and the same file the family fingerprint already trusts for identity."""
    p = d / "lingbotvla_cli.yaml"
    if not p.is_file():
        return {}
    try:
        import yaml  # ships with huggingface_hub, the one core dependency
        doc = yaml.safe_load(p.read_text())
    except Exception:                                            # noqa: BLE001 - evidence only
        return {}
    data = doc.get("data") if isinstance(doc, dict) else None
    return data if isinstance(data, dict) else {}


def _lingbot_robot_decision(d: Path, base_ex: Mapping, base_note: str) -> ScaffoldField:
    """`robot` from the training config, only when two of its statements corroborate.

    `data.data_name` names what the model was trained as, and the serving profile is selected
    by that same name upstream — but `data_name` can also name a dataset mix ('multi' in the V2
    release), which is not a servable profile. The scaffold therefore writes it only when the
    yaml's own `data.norm_stats_file` is named after it (robotwin -> robotwin_50.json): two
    independent statements in the checkpoint's own config agreeing. Anything less stays FILL_ME
    with the yaml's value quoted for the human who knows.
    """
    data = _lingbot_cli_data(d)
    name = data.get("data_name")
    stats_file = data.get("norm_stats_file")
    if (isinstance(name, str) and name and isinstance(stats_file, str)
            and Path(stats_file).name.startswith(name)):
        return ScaffoldField(
            "robot", INFERRED, name,
            f"lingbotvla_cli.yaml: data.data_name = {name!r}, corroborated by "
            f"data.norm_stats_file = {stats_file!r}")
    seen = (f" (lingbotvla_cli.yaml says data.data_name = {name!r}, but that names the training "
            f"data mix and nothing in the config corroborates it as a serving profile)"
            if isinstance(name, str) and name else "")
    return ScaffoldField("robot", TO_FILL, FILL_ME, base_note + seen)


def _build_lingbot_vla(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    decisions["robot"] = _lingbot_robot_decision(
        d, base_ex,
        "selects the upstream serving profile (norm stats, action channel map); the base "
        "declares 'robotwin' and a fine-tune on another robot must not inherit it")
    stats = sorted((d / "assets" / "norm_stats").glob("*.json")) \
        if (d / "assets" / "norm_stats").is_dir() else []
    yaml_stats = _lingbot_cli_data(d).get("norm_stats_file")
    if len(stats) == 1:
        decisions["norm_stats"] = ScaffoldField(
            "norm_stats", INFERRED, str(stats[0].relative_to(d)),
            "the only norm-stats file shipped in the package")
    elif not stats and isinstance(yaml_stats, str) and yaml_stats:
        decisions["norm_stats"] = ScaffoldField(
            "norm_stats", INFERRED, yaml_stats,
            "lingbotvla_cli.yaml data.norm_stats_file — the stats ship with the upstream "
            "checkout when not in the package; the path is resolved and verified at load")
    else:
        decisions["norm_stats"] = ScaffoldField(
            "norm_stats", TO_FILL, FILL_ME,
            "package-relative path to the action norm-stats JSON "
            + ("(none found under assets/norm_stats/)" if not stats
               else f"({len(stats)} candidates under assets/norm_stats/)"))
    m = _measure_weights(d)
    if m:
        decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                 f"measured: {m[1]}")
        _local_pointer(d, decisions, "local weights are present")
    return decisions


def _v2_subdirs(d: Path) -> list:
    return sorted(p.relative_to(d) for p in d.glob("checkpoints/*/hf_ckpt")
                  if (p / "config.json").is_file())


def _detect_lingbot_vla_v2(d: Path) -> list:
    if not (d / "lingbotvla_cli.yaml").is_file():
        return []
    subs = _v2_subdirs(d)
    for sub in subs:
        if "vlm_family" in _json_at(d, str(sub / "config.json")):
            return [("robbyant/lingbot-vla-v2-6b-robotwin",
                     f"lingbotvla_cli.yaml next to {sub}/config.json declaring vlm_family "
                     f"(the V2 release bundle layout)")]
    return []


def _build_lingbot_vla_v2(d: Path, base_ex: Mapping, backbone_evidence: str) -> dict:
    decisions: dict = {}
    subs = _v2_subdirs(d)
    if len(subs) == 1:
        sub = str(subs[0])
        decisions["checkpoint_subdir"] = ScaffoldField(
            "checkpoint_subdir", INFERRED, sub, "the only checkpoints/*/hf_ckpt in the bundle")
        m = _measure_weights(d, sub)
        if m:
            decisions["param_bytes"] = ScaffoldField("param_bytes", INFERRED, m[0],
                                                     f"measured: {m[1]}")
            _local_pointer(d, decisions, "the HF checkpoint is present in the bundle")
    else:
        decisions["checkpoint_subdir"] = ScaffoldField(
            "checkpoint_subdir", TO_FILL, FILL_ME,
            "which checkpoints/*/hf_ckpt to serve"
            + (f" ({len(subs)} present: {', '.join(map(str, subs))})" if subs else
               " (none found under checkpoints/)"))
    decisions["robot"] = _lingbot_robot_decision(
        d, base_ex,
        "selects the upstream serving profile; the base declares 'robotwin' and a fine-tune "
        "on another robot must not inherit it")
    return decisions


_FAMILIES: dict[str, _Family] = {
    "wan_va": _Family(
        "wan_va", 'config.json (or transformer/config.json) with _class_name == '
                  '"WanTransformer3DModel" and an action_dim',
        _detect_wan_va, _build_wan_va,
        depth="deep — backbone proven from the transformer config, param_bytes measured from "
              "the weight files, frozen-stack pointer resolved; the four observation-geometry "
              "keys are training facts, read (never executed) from a training-config artifact "
              "shipped in the package when one is, FILL_ME otherwise"),
    "pi05": _Family(
        "pi05", 'config.json with type == "pi05"',
        _detect_pi05, _build_pi05,
        depth="deep — backbone, observation contract (obs_features), denoise schedule and "
              "param_bytes are all read from the checkpoint's own config.json and weight files"),
    "groot_n17": _Family(
        "groot_n17", 'config.json with type == "groot" (lerobot-converted) or model_type == '
                     '"Gr00tN1d7" (the native Isaac-GR00T release)',
        _detect_groot, _build_groot,
        depth="medium — backbone and param_bytes inferred; embodiment_tag read from the "
              "checkpoint's own config/metadata/statistics when unambiguous, FILL_ME with the "
              "checkpoint's own candidates listed otherwise"),
    "dreamzero": _Family(
        "dreamzero", 'config.json with model_type == "vla", architectures == ["VLA"] and an '
                     "action_horizon",
        _detect_gear_wam, _build_gear_wam,
        depth="medium — backbone and param_bytes inferred; embodiment_tag read from "
              "experiment_cfg/metadata.json when unambiguous, FILL_ME otherwise"),
    "cosmos3_policy": _Family(
        "cosmos3_policy", 'config.json with model_type == "cosmos3_omni" (the text tower '
                          "distinguishes Edge from Nano)",
        _detect_cosmos3, _build_cosmos3,
        depth="medium — backbone identity (Edge vs Nano) and param_bytes inferred, and any "
              "serving-config key stated in the checkpoint's own checkpoint.json policy block "
              "is read from it; the rest are measurement facts the adapter refuses to guess, "
              "FILL_ME with the DROID base's values quoted",
        strict_ids=True),
    "lingbot_vla": _Family(
        "lingbot_vla", 'config.json with type == "pi0" next to lingbotvla_cli.yaml',
        _detect_lingbot_vla, _build_lingbot_vla,
        depth="medium — backbone and param_bytes inferred; norm_stats and the robot profile "
              "read from the shipped lingbotvla_cli.yaml when its statements corroborate, "
              "FILL_ME otherwise"),
    "lingbot_vla_v2": _Family(
        "lingbot_vla_v2", "lingbotvla_cli.yaml next to a checkpoints/*/hf_ckpt/config.json "
                          "declaring vlm_family",
        _detect_lingbot_vla_v2, _build_lingbot_vla_v2,
        depth="medium — backbone, checkpoint_subdir and param_bytes inferred from the bundle "
              "layout; the robot profile is read from lingbotvla_cli.yaml only when its "
              "statements corroborate, FILL_ME otherwise"),
}


# --- the scaffold itself ---------------------------------------------------------------------------

def _refuse_unmerged_adapter(d: Path) -> None:
    """An unmerged peft/LoRA adapter is refused before any family fingerprinting runs.

    The layout knowledge and the message (with the exact merge command) live in
    `package.unmerged_adapter_problem`, the same check plain `validate` gates on — one rule,
    two surfaces, so the scaffold can never write what validate would then reject as garbage.
    """
    from instinctflash.descriptors.package import unmerged_adapter_problem
    problem = unmerged_adapter_problem(d)
    if problem is not None:
        raise ScaffoldError(f"{d}: {problem}\n    Scaffold the merged output, not the adapter.")


def known_bases() -> list[str]:
    return sorted(KNOWN_DECLARATIONS)


def detect_base(ckpt_dir: str | Path) -> list:
    """Every built-in base whose family fingerprint matches this checkpoint: [(base_id, evidence)]."""
    d = Path(ckpt_dir)
    out: list = []
    for fam in _FAMILIES.values():
        out.extend(fam.detect(d))
    return out


def scaffold_declaration(ckpt_dir: str | Path, base_id: str) -> ScaffoldPlan:
    """Build (do not write) the scaffolded declaration for `ckpt_dir` from `base_id`."""
    d = Path(ckpt_dir)
    _refuse_unmerged_adapter(d)
    doc = lookup(base_id)
    if doc is None:
        raise ScaffoldError(
            f"{base_id!r} is not a built-in declaration. Known bases:\n  "
            + "\n  ".join(known_bases())
            + "\n(or --validate.scaffold=auto to detect one from the checkpoint's config)")
    base_ex = dict(doc.get("execution") or {})
    backbone = str(base_ex.get("backbone") or "")
    fam = _FAMILIES.get(backbone)
    if fam is None:
        raise ScaffoldError(f"no scaffold knowledge for backbone {backbone!r} (base {base_id})")

    matches = fam.detect(d)
    if not matches:
        raise ScaffoldError(
            f"{d} does not look like a {backbone} checkpoint — expected {fam.fingerprint}. "
            f"Refusing to scaffold from {base_id}: a declaration copied onto the wrong family "
            f"would fail at load with a worse message than this one.")
    if fam.strict_ids and all(mid != base_id for mid, _ in matches) and len(matches) == 1:
        mid, evidence = matches[0]
        raise ScaffoldError(
            f"{d} identifies as {mid} ({evidence}), but --validate.scaffold={base_id} was "
            f"passed. Refusing to write the wrong sibling's declaration.")
    backbone_evidence = matches[0][1]

    decisions = fam.build(d, base_ex, backbone_evidence)
    decisions["backbone"] = ScaffoldField("backbone", INFERRED, backbone, backbone_evidence)
    decisions.setdefault("model_id", ScaffoldField(
        "model_id", INFERRED, d.resolve().name,
        "the directory name — set your org/name id before publishing"))
    decisions.setdefault("servable", ScaffoldField(
        "servable", INHERITED, bool(base_ex.get("servable", False)),
        "the base is servable; set false if this fine-tune is not fit to serve"))
    if "nfe" not in decisions and "nfe" in base_ex:
        decisions["nfe"] = ScaffoldField(
            "nfe", INHERITED, copy.deepcopy(base_ex["nfe"]),
            "the base's declared step schedule; a step-distilled fine-tune declares its own")
    if "guidance" not in decisions and "guidance" in base_ex:
        decisions["guidance"] = _guidance_decision(
            backbone, base_ex, decisions["nfe"].value if "nfe" in decisions else None)
    if "param_bytes" not in decisions and "param_bytes" in base_ex:
        decisions["param_bytes"] = ScaffoldField(
            "param_bytes", INHERITED, base_ex["param_bytes"],
            "no local weight files found to measure; kept from the base")
    for key, value in base_ex.items():
        decisions.setdefault(key, ScaffoldField(key, INHERITED, copy.deepcopy(value),
                                                "copied from the base declaration"))

    order = list(base_ex) + [k for k in decisions if k not in base_ex]
    fields = tuple(decisions[k] for k in order)
    execution = {f.key: f.value for f in fields}
    fill_notes = {f.key: f.note for f in fields if f.status == TO_FILL}
    document = {
        "instinctflash_schema": int(doc.get("instinctflash_schema", 1)),
        "execution": execution,
        "provenance": {
            "scaffold": {
                "base": base_id,
                "generated_by": "instinctflash validate --validate.scaffold",
                **({"fill_me": fill_notes} if fill_notes else {}),
            },
        },
    }
    return ScaffoldPlan(str(d), base_id, backbone, fam.depth, fields, document)


def _guidance_decision(backbone: str, base_ex: Mapping, nfe) -> ScaffoldField:
    """Guidance is INHERITED, with its classification stated rather than assumed.

    The honest call, made once here: a per-stream guidance scale is a SERVING choice -- the
    second leg of the operating point (schedule grid, per-stream guidance scale, CFG batching;
    docs/rfc/fewstep-distillation.md §11) -- not a training fact the checkpoint carries and not
    an invariant of the base weights. A fine-tune of the same family inherits the base's served
    point by default (same sampler, same combine), which is why it is copied; but because the
    campaign measured the same schedule swinging 60 points across scales, the inheritance is
    PRINTED as the resolved tuple so the author sees exactly what will run, and knows that a
    re-tuned scale or a guidance-distilled / CFG-folded student must declare its own {mode, scale}.
    """
    declared = base_ex["guidance"]
    head = ("SERVING choice, not a training fact: inherited from the base and served as ")
    tail = ("; a re-tuned scale or a CFG-folded student declares its own {mode, scale}")
    try:
        from instinctflash.runtime.loader import load as load_adapter
        spec = load_adapter(backbone).spec()
        if isinstance(nfe, Mapping) and nfe and all(isinstance(v, int) for v in nfe.values()):
            spec = spec.with_nfe(nfe)
        spec = spec.with_guidance(declared)
        served = ", ".join(
            f"{name}={rule.mode.value}@{rule.scale:g}"
            + (" (scale inherited)" if spec.guidance_resolution.get(name, "declared") != "declared" else "")
            for name, rule in sorted(spec.guidance.items()))
        b = spec.cfg_batching()
        batching = (f"batch-2 on {b['batch2_forwards']} of {spec.total_forwards()} declared forwards"
                    if b["negative_branch_requested_by"] else "batch-1 on every forward")
        note = f"{head}{served} => {batching}{tail}"
    except Exception:                                            # noqa: BLE001 - adapter not importable here
        from instinctflash.descriptors.guidance import describe_guidance, resolve
        note = (f"{head}{describe_guidance(resolve(declared))} (scales are the family defaults; "
                f"the {backbone!r} adapter is not importable in this environment){tail}")
    return ScaffoldField("guidance", INHERITED, copy.deepcopy(declared), note)


# --- writing, guarding, and the FILL_ME scan ------------------------------------------------------

def _atomic_write(path: Path, content: str) -> None:
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", dir=str(path.parent))
    try:
        with os.fdopen(fd, "w") as f:
            f.write(content)
        os.replace(tmp, path)
    except Exception:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _diff_lines(old_doc: Mapping, new_doc: Mapping) -> list[str]:
    old = dict(old_doc.get("execution") or {})
    new = dict(new_doc.get("execution") or {})
    out: list[str] = []
    for k, v in new.items():
        if k not in old:
            out.append(f"  + execution.{k} = {json.dumps(v, ensure_ascii=False)}")
        elif old[k] != v:
            out.append(f"  ~ execution.{k}: {json.dumps(old[k], ensure_ascii=False)} -> "
                       f"{json.dumps(v, ensure_ascii=False)}")
    for k in old:
        if k not in new:
            out.append(f"  - execution.{k} (present only in the existing file)")
    same = [k for k in new if k in old and old[k] == new[k]]
    out.append(f"  = unchanged: {', '.join(same) if same else '(none)'}")
    return out


def run_scaffold(ckpt_dir: str | Path, base: str, *, force: bool = False) -> tuple[dict, str, bool]:
    """The `--validate.scaffold` verb body: detect/copy/infer, guard, write.

    Returns (result-dict, text, wrote). Never overwrites an existing declaration without
    `force`; in that case the text carries the full would-be document and a field-level diff,
    and `wrote` is False so the caller can refuse to report success for work it did not do.
    """
    d = Path(ckpt_dir)
    if not d.is_dir():
        raise ScaffoldError(f"{d} is not a directory")
    # BEFORE fingerprinting: lerobot's peft flow saves the policy's config.json next to the
    # adapter files, so an unmerged adapter fingerprints EXACTLY like its base — the scaffold
    # would inherit the base's param_bytes and base_weights and write a declaration that
    # validates, serves, and silently answers with the base model minus the fine-tune.
    _refuse_unmerged_adapter(d)
    lines: list[str] = []
    if base == "auto":
        matches = detect_base(d)
        if not matches:
            # A training-output tree is the common way to land here with a REAL model nearby:
            # the fix is pointing at it, not picking a base. Same knowledge as plain `validate`.
            from instinctflash.descriptors.package import _training_layout_hint
            hint = _training_layout_hint(d)
            if hint is not None:
                raise ScaffoldError(
                    f"{d}: no built-in declaration matches this directory — {hint}")
            raise ScaffoldError(
                f"{d}: no built-in declaration matches this checkpoint. Fingerprints looked "
                "for:\n  " + "\n  ".join(f"{f.backbone}: {f.fingerprint}"
                                         for f in _FAMILIES.values())
                + "\nPass --validate.scaffold=<base> explicitly; known bases:\n  "
                + "\n  ".join(known_bases()))
        if len(matches) > 1:
            raise ScaffoldError(
                f"{d}: ambiguous — {len(matches)} built-in declarations match, and the "
                "scaffold refuses to pick:\n  "
                + "\n  ".join(f"{mid}  ({ev})" for mid, ev in matches)
                + "\nPass --validate.scaffold=<one of them>.")
        base, evidence = matches[0]
        lines.append(f"auto-detected base: {base}  ({evidence})")
    plan = scaffold_declaration(d, base)
    lines.append(plan.explain())

    existing = _declaration_file(d)
    wrote = False
    if existing is not None and not force:
        try:
            old = json.loads(existing.read_text())
        except Exception:                                        # noqa: BLE001 - still refuse to clobber
            old = {}
        lines += ["", f"NOT WRITTEN: {existing.name} already exists. What the scaffold would "
                      f"change (--validate.force=true to overwrite):"]
        lines += _diff_lines(old, plan.document)
        lines += ["", "the full document the scaffold would write:",
                  json.dumps(plan.document, indent=2, ensure_ascii=False)]
    else:
        if existing is not None:
            try:
                old = json.loads(existing.read_text())
            except Exception:                                    # noqa: BLE001
                old = {}
            lines += [f"overwriting {existing.name} (--validate.force=true); changes:"]
            lines += _diff_lines(old, plan.document)
        target = d / "instinctflash.json"
        _atomic_write(target, json.dumps(plan.document, indent=2, ensure_ascii=False) + "\n")
        wrote = True
        lines.append(f"wrote {target}")
    result = {**plan.to_result(), "written": wrote}
    return result, "\n".join(lines), wrote


def fill_me_findings(ckpt_dir: str | Path) -> list[tuple[str, str]]:
    """Every FILL_ME sentinel in the package's declaration: [(dotted path, why it must be filled)].

    Read by `validate` on EVERY run, not only after a scaffold, so a half-filled declaration
    keeps failing until the last sentinel is gone. The one-line reasons ride in
    provenance.scaffold.fill_me — provenance, because they are notes for a human, and the
    runtime never reads them.
    """
    p = _declaration_file(Path(ckpt_dir))
    if p is None:
        return []
    try:
        doc = json.loads(p.read_text())
    except Exception:                                            # noqa: BLE001 - structure check reports it
        return []
    reasons = (((doc.get("provenance") or {}).get("scaffold") or {}).get("fill_me") or {})

    found: list[tuple[str, str]] = []

    def walk(prefix: str, top: str, value: Any) -> None:
        if isinstance(value, str) and value == FILL_ME:
            found.append((prefix, str(reasons.get(
                top, "the scaffold could not prove a value; fill in this checkpoint's real one"))))
        elif isinstance(value, Mapping):
            for k, v in value.items():
                walk(f"{prefix}.{k}", top, v)
        elif isinstance(value, (list, tuple)):
            for i, v in enumerate(value):
                walk(f"{prefix}[{i}]", top, v)

    for key, value in (doc.get("execution") or {}).items():
        walk(f"execution.{key}", key, value)
    return found
