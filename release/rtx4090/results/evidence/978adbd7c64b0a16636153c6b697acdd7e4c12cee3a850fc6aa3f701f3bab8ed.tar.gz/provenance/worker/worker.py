"""Run one explicitly prepared additional mode only after its primary run passes."""
from __future__ import annotations
import csv
import fcntl
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import time
import traceback

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))
from common import (COMMIT, GPU, ROOT, TARGET, admit_installed, proc, require,
                    restore_installed_environment, sha, stop_owned_tree, utc)
from validate import parent_gate, read


def apply_environment(base, delta):
    result = dict(base)
    for key in delta['remove']:
        result.pop(key, None)
    result.update(delta['set'])
    return result


def run(config_path):
    config = read(config_path)
    out, source = Path(config['output']), Path(config['source'])
    require(config['schema'] == 'instinctflash.task_owned_mode_supplement_config.v1'
            and config['source_commit'] == COMMIT and config['target'] == TARGET and config['GPU_uuid'] == GPU,
            'Wrong source/target supplement config')
    require(not out.exists() and not out.is_symlink(), 'Refuse existing supplemental output')
    for value in config['timeouts'].values():
        require(type(value) is int and 0 < value <= 86400, 'Invalid bounded timeout')
    out.mkdir(mode=0o700)
    state = {'schema': 'instinctflash.task_owned_mode_supplement.v1', 'status': 'prerequisites',
             'passed': False, 'family': config['family'], 'mode': config['mode'], 'source_commit': COMMIT,
             'worker_pid': os.getpid(), 'config_sha256': sha(config_path), 'started_at': utc(),
             'automatic_retries': 0, 'GPU_uuid': GPU, 'stages': [], 'captured_cells': [],
             'full_public_run_completed': False, 'task_quality_validated': False, 'publication_ready': False}
    locks, asset_stats = [], {}
    child = None

    def save():
        path = out / 'status.tmp'
        path.write_text(json.dumps(state, indent=2) + '\n')
        path.replace(out / 'status.json')

    def acquire(path):
        handle = path.open('a')
        deadline = time.monotonic() + config['timeouts']['lease']
        try:
            while True:
                try:
                    fcntl.flock(handle, fcntl.LOCK_EX | fcntl.LOCK_NB)
                    locks.append(handle)
                    return
                except BlockingIOError:
                    require(time.monotonic() < deadline, 'Lease wait expired')
                    state.update(status='waiting_lease', lease=str(path), updated_at=utc())
                    save()
                    time.sleep(5)
        except BaseException:
            handle.close()
            raise

    def stage(name, argv, environment, timeout):
        nonlocal child
        row = {'name': name, 'argv': argv, 'started_at': utc(), 'timeout_seconds': timeout}
        state['stages'].append(row)
        state['status'] = name
        save()
        log, start = out / (name + '.log'), time.monotonic()
        with log.open('xb') as handle:
            child = subprocess.Popen(argv, cwd=out, env=environment, stdin=subprocess.DEVNULL,
                                     stdout=handle, stderr=subprocess.STDOUT, start_new_session=True)
            identity = proc(child.pid)
            row.update(pid=child.pid, start_ticks=identity['start'] if identity else None)
            save()
            try:
                code = child.wait(timeout=timeout)
            except BaseException:
                stop_owned_tree(child)
                raise
        row.update(exit_code=code, elapsed_seconds=time.monotonic() - start,
                   log_sha256=sha(log), finished_at=utc())
        save()
        require(code == 0, name + ' failed; first logs/receipts retained')

    def interrupted(signum, _frame):
        raise RuntimeError('Owned supplemental worker interrupted: ' + str(signum))

    signals = (signal.SIGTERM, signal.SIGINT, signal.SIGALRM)
    old_handlers = {sig: signal.signal(sig, interrupted) for sig in signals}
    signal.alarm(sum(config['timeouts'].values()) + 600)
    try:
        save()
        parent = parent_gate(config)
        parent_path = Path(config['parent_pipeline']) / 'completion.json'
        state['parent_completion_sha256'] = sha(parent_path)
        require(subprocess.check_output(['git', '-C', str(source), 'rev-parse', 'HEAD'], text=True, timeout=30).strip() == COMMIT,
                'Pinned source checkout changed')
        for path, digest in config['source_files'].items():
            require(sha(source / path) == digest, 'Frozen source changed: ' + path)
        for name, digest in config['worker_files'].items():
            require(sha(TASK / name) == digest, 'Frozen worker input changed: ' + name)
        family = Path(config['family_root'])
        installed = read(family / 'completion.json')
        state['actual_install_admission'] = admit_installed(config, installed)
        require(installed['family'] == config['family'] and installed['deployment_target'] == 'rtx4090', 'Different installed family')
        require(parent['bootstrap_completion_sha256'] == sha(family / 'completion.json'), 'Installed bootstrap receipt differs from parent')
        state['bootstrap_completion_sha256'] = sha(family / 'completion.json')
        state['historical_bootstrap_CPU_doctor_passed'] = installed.get('CPU_doctor_passed')
        state['parent_additional_install_admissions'] = {
            key: value for key, value in parent.items() if 'doctor' in key.lower() or key == 'core_upgrade_completion_sha256'}
        require(config['interpreter'] == str(family / 'env/bin/python'), 'Interpreter must be the admitted family environment')
        assets_root = Path(config['assets'])
        assets = read(assets_root / 'completion.json')
        require(assets['status'] == 'assets_hash_verified'
                and parent['assets_completion_sha256'] == sha(assets_root / 'completion.json'), 'Original assets differ from parent')
        state['assets_completion_sha256'] = sha(assets_root / 'completion.json')
        acquire(ROOT / 'host-timing.lock')
        acquire(Path('/tmp/ifl-robolab-renderer-gpu0.lock'))
        acquire(ROOT / 'gpu-leases' / (GPU + '.lock'))
        files = assets['files'] + assets['primary_checkpoint']['files']
        require(bool(assets['primary_checkpoint']['files']), 'Primary checkpoint byte admission missing')
        deadline = time.monotonic() + config['timeouts']['asset_admission']
        for entry in files:
            require(time.monotonic() < deadline, 'Asset byte admission deadline expired')
            path = Path(entry['destination'])
            stat = path.stat()
            require(stat.st_size == entry['bytes'] and sha(path) == entry['sha256'], 'Original checkpoint/auxiliary bytes differ')
            asset_stats[str(path)] = [stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns]
        state['asset_admission'] = {'files': len(files), 'bytes': sum(v['bytes'] for v in files)}
        env = {key: value for key, value in os.environ.items()
               if not key.startswith(('IFL_', 'UV_', 'PIP_')) and key not in
               ('PYTHONPATH', 'PYTHONHOME', 'VIRTUAL_ENV', 'DYNAMIC_CACHE_SCHEDULE', 'NUM_DIT_STEPS', 'LOAD_TRT_ENGINE', 'ENABLE_TENSORRT')}
        env.update(CUDA_VISIBLE_DEVICES='', CUDA_DEVICE_ORDER='PCI_BUS_ID', PYTHONDONTWRITEBYTECODE='1',
                   PYTHONNOUSERSITE='1', HF_HUB_OFFLINE='1', TRANSFORMERS_OFFLINE='1', HF_DATASETS_OFFLINE='1', ENABLE_TENSORRT='false')
        restore_installed_environment(env, installed, config)
        env.update(assets['environment'])
        root_env = config['candidate_plan']['vendor']['root_env']
        if root_env:
            env[root_env] = installed['vendor']
        for key, folder in {'TRITON_CACHE_DIR': 'triton-cache', 'TORCHINDUCTOR_CACHE_DIR': 'inductor-cache',
                            'CUDA_CACHE_PATH': 'cuda-cache', 'TORCH_EXTENSIONS_DIR': 'extensions-cache',
                            'XDG_CACHE_HOME': 'xdg-cache', 'TMPDIR': 'tmp'}.items():
            path = out / folder
            path.mkdir()
            env[key] = str(path)
        python, validator = config['interpreter'], str(TASK / 'validate.py')
        prepared, capture, admission = out / 'prepared', out / 'capture', out / 'admission.json'
        stage('prepare', [python, '-I', '-m', 'benchmarks.regression.reproduce', 'prepare', '--model', config['family'],
                         '--mode', config['mode'], '--target', 'rtx4090', '--cache-dir', str(assets_root / 'hf/hub'),
                         '--local-files-only', '--output', str(prepared)], env, config['timeouts']['prepare'])
        common = ['--config', str(config_path), '--prepared', str(prepared)]
        stage('admit', [python, '-I', validator, 'admit', *common, '--output', str(admission)], env, config['timeouts']['source_admission'])
        capture.mkdir()
        (capture / 'matrix.json').write_bytes((prepared / 'matrix.json').read_bytes())
        env = apply_environment(env, read(out / 'capture_environment.json'))
        state['optimizer_environment'] = next(c for c in config['candidate_plan']['matrix']['cells']
                                            if c['id'] == config['cell_id'])['expected_optimizer_environment']
        gpu_csv = subprocess.check_output(['nvidia-smi', '--query-gpu=index,uuid,name,memory.used,utilization.gpu',
                                           '--format=csv,noheader,nounits'], text=True, timeout=30)
        processes = subprocess.check_output(['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory',
                                             '--format=csv,noheader,nounits'], text=True, timeout=30)
        rows = [row for row in csv.reader(gpu_csv.splitlines()) if row[1].strip() == GPU]
        require(len(rows) == 1 and rows[0][0].strip() == '0' and rows[0][2].strip() == 'NVIDIA GeForce RTX 4090'
                and int(rows[0][3]) <= 64 and int(rows[0][4]) == 0 and GPU not in processes, 'Physical GPU0 is not idle')
        state.update(GPU_before_csv=gpu_csv, compute_before_csv=processes)
        env['CUDA_VISIBLE_DEVICES'] = GPU
        stage('capture_selected', [python, '-I', '-m', 'benchmarks.regression.user_e2e', '--matrix', str(capture / 'matrix.json'),
                                  '--cell', config['cell_id'], '--output-root', str(capture), '--fixture', str(prepared / 'inputs/recorded_inputs_v1.npz')],
              env, config['timeouts']['capture'])
        state['captured_cells'] = [config['cell_id']]
        cpu_env = dict(env, CUDA_VISIBLE_DEVICES='')
        stage('validate_capture', [python, '-I', validator, 'capture', *common, '--run', str(capture), '--admission', str(admission),
                                   '--output', str(out / 'validation.json')], cpu_env, config['timeouts']['source_admission'])
        stage('serve', [python, '-I', '-m', 'benchmarks.regression.serve_smoke', '--prepared', str(prepared), '--cell', config['cell_id'],
                        '--output', str(out / 'serve'), '--seed', '9173', '--startup-timeout', '1800', '--request-timeout', '1200'],
              env, config['timeouts']['serve'])
        stage('validate_serve', [python, '-I', validator, 'serve', *common, '--run', str(out / 'serve'), '--admission', str(admission),
                                 '--output', str(out / 'serve_validation.json')], cpu_env, config['timeouts']['source_admission'])
        for path, expected in asset_stats.items():
            stat = Path(path).stat()
            require([stat.st_dev, stat.st_ino, stat.st_size, stat.st_mtime_ns, stat.st_ctime_ns] == expected, 'Original assets changed during supplement')
        require(sha(parent_path) == state['parent_completion_sha256']
                and sha(assets_root / 'completion.json') == state['assets_completion_sha256'], 'Prior evidence changed')
        state.update(status='completed_supplement_only', passed=True, validation_sha256=sha(out / 'validation.json'),
                     serve_validation_sha256=sha(out / 'serve_validation.json'))
    except BaseException as error:
        state.update(status='failed_preserved', error_type=type(error).__name__, error=str(error), traceback=traceback.format_exc())
    finally:
        signal.alarm(0)
        if child is not None and child.poll() is None:
            stop_owned_tree(child)
        for handle in reversed(locks):
            fcntl.flock(handle, fcntl.LOCK_UN)
            handle.close()
        for sig, handler in old_handlers.items():
            signal.signal(sig, handler)
        state.update(lease_released=True, finished_at=utc())
        save()
        with (out / ('completion.json' if state['passed'] else 'failure.json')).open('x') as handle:
            json.dump(state, handle, indent=2)
            handle.write('\n')
        print(json.dumps(state), flush=True)
    return 0 if state['passed'] else 1


if __name__ == '__main__':
    sys.exit(run(Path(sys.argv[1]).resolve()))
