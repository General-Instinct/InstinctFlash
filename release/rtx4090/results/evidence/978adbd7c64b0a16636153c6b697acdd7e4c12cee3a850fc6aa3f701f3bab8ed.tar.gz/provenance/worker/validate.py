"""CPU admission of one additional public mode, retaining its complete plan."""
from __future__ import annotations
import argparse
import ast
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys

TASK = Path(__file__).resolve().parent
sys.path.insert(0, str(TASK))
from common import COMMIT, FIXTURE, GPU, TARGET, require, sha


def read(path):
    return json.loads(Path(path).read_text())


def write(path, value):
    with Path(path).open('x') as handle:
        json.dump(value, handle, indent=2, allow_nan=False)
        handle.write('\n')


def expected_cases(family, fixture):
    from benchmarks.regression.user_e2e import RecordedInputs, prompt, request_hash
    require(sha(fixture) == FIXTURE, 'Wrong public fixture')
    inputs, result = RecordedInputs(fixture), []
    history = family == 'dreamzero'
    for i in range(21 if history else 25):
        episode, cycle = divmod(i, 3) if history else (i, 0)
        result.append({'i': i, 'episode': episode, 'cycle': cycle,
                       'phase': 'warmup' if (episode == 0 if history else i < 5) else 'measured',
                       'seed': 1300 + i if history else 707 + i,
                       'input_sha256': request_hash({'observation': inputs.observation(family, i, cycle),
                                                    'prompt': prompt(episode)}),
                       'feedback_sha256': request_hash({}), 'call_kind': 'generation'})
    return result


def expected_serve_cases(family, fixture):
    from benchmarks.regression.user_e2e import RecordedInputs, prompt, request_hash
    require(sha(fixture) == FIXTURE, 'Wrong serving fixture')
    inputs, result = RecordedInputs(fixture), []
    for i in range(6):
        episode, cycle = divmod(i, 3)
        observation = inputs.observation(family, i, cycle)
        observation['prompt'] = prompt(episode)
        result.append({'episode': episode, 'cycle': cycle, 'request_sha256': request_hash(observation)})
    return result


def selected(plan, cell_id):
    cells = [cell for cell in plan['matrix']['cells'] if cell['id'] == cell_id]
    require(len(cells) == 1, 'Selected cell absent or ambiguous')
    return cells[0]


def gpu(receipt):
    from benchmarks.regression.hardware import validate_device_receipt
    require(receipt['target'] == TARGET, 'Wrong target')
    hardware = receipt['hardware']
    validate_device_receipt(hardware, TARGET)
    require(hardware['uuid'] in (GPU, GPU.removeprefix('GPU-')), 'Different physical GPU')
    require(23 << 30 <= hardware['total_memory_bytes'] <= 24 << 30, 'Wrong GPU memory capacity')


def installed_sources(config):
    from benchmarks.regression.reproduce import require_installed
    require_installed()
    require(sys.executable == config['interpreter'], 'Different installed interpreter')
    sources = {}
    for package, files in config['installed_packages'].items():
        spec = importlib.util.find_spec(package)
        require(spec is not None and spec.origin, 'Installed package absent: ' + package)
        root = Path(spec.origin).resolve().parent
        for relative, digest in files.items():
            path = root / relative
            require(path.is_file() and sha(path) == digest, 'Installed source differs: ' + str(path))
            sources[str(path)] = digest
    return sources


def declared_torch_version(config, distribution):
    """Read the official version source as data; never execute or import Torch."""
    path = Path(distribution.locate_file('torch/version.py'))
    require(path.is_file() and sha(path) == config['torch_version_source_sha256'],
            'Installed Torch version source differs before inference')
    declarations = []
    for node in ast.parse(path.read_bytes()).body:
        if isinstance(node, ast.Assign):
            targets = node.targets
        elif isinstance(node, ast.AnnAssign):
            targets = [node.target]
        else:
            continue
        if any(isinstance(target, ast.Name) and target.id == '__version__' for target in targets):
            declarations.append(ast.literal_eval(node.value))
    require(declarations == [config['torch_version']],
            'Declared Torch runtime version differs before inference')
    return {'distribution_version': distribution.version,
            'runtime_version': declarations[0], 'version_source_path': str(path),
            'version_source_sha256': sha(path), 'torch_imported': False}


def dependency_versions(config):
    import importlib.metadata
    distributions = list(importlib.metadata.distributions())
    versions = {d.metadata['Name']: d.version for d in distributions}
    require(versions == config['installed_distributions'],
            'Installed dependency versions differ from actual frozen bootstrap environment')
    torch_distributions = [d for d in distributions if d.metadata['Name'].lower() == 'torch']
    require(len(torch_distributions) == 1, 'Installed Torch distribution is absent or ambiguous')
    require(torch_distributions[0].version == config['torch_distribution_version'],
            'Installed Torch distribution version differs before inference')
    torch_binding = declared_torch_version(config, torch_distributions[0])
    parent_root = Path(config['parent_pipeline'])
    parent_config = read(parent_root / 'config.json')
    baseline = {'scope': 'successful parent with hash-bound bootstrap; current complete version snapshot'}
    if parent_config.get('core_upgrade'):
        path = Path(parent_config['core_upgrade']) / 'completion.json'
        upgrade = read(path)
        parent = read(parent_root / 'completion.json')
        require(parent.get('core_upgrade_completion_sha256') == sha(path)
                and upgrade.get('passed') is True and upgrade.get('source_commit') == COMMIT
                and upgrade.get('family') == config['family'], 'Parent core-upgrade admission differs')
        require(versions == upgrade['versions'], 'Installed dependency versions changed since the parent core upgrade')
        baseline = {'scope': 'exact complete parent core-upgrade version snapshot', 'receipt_sha256': sha(path)}
    return {'versions': versions, 'baseline': baseline, 'torch_binding': torch_binding}


def parent_gate(config):
    root = Path(config['parent_pipeline'])
    require(not (root / 'failure.json').exists(), 'Parent failed; preserve it and do not launch')
    completion, parent_config = read(root / 'completion.json'), read(root / 'config.json')
    require(completion.get('schema') == 'instinctflash.rtx4090_family_pipeline.v1'
            and completion.get('passed') is True and completion.get('lease_released') is True
            and completion.get('family') == config['family'] and completion.get('GPU_uuid') == GPU
            and completion.get('source_commit') == COMMIT, 'Parent completion is not the expected successful run')
    require(completion['config_sha256'] == sha(root / 'config.json'), 'Parent config changed')
    require(completion['config_sha256'] == config['parent_config_sha256'],
            'Parent config differs from actual frozen main')
    require(parent_config['family_root'] == config['family_root']
            and parent_config['source'] == config['source'] and parent_config['source_commit'] == COMMIT
            and parent_config['assets'] == config['assets'], 'Parent uses different installed source, family, or assets')
    return completion


def parent_numeric_environment(config):
    """Preserve the actual common loaded-parent flags, rather than pre-load defaults."""
    root = Path(config['parent_pipeline']) / 'capture'
    environments = []
    for cell in config['parent_plan']['matrix']['cells']:
        observed = read(root / cell['receipt'])['numeric_environment']
        require(set(observed) == {'matmul_tf32', 'cudnn_tf32', 'cudnn_benchmark'}
                and all(type(value) is bool for value in observed.values()),
                'Parent numeric environment fields are incomplete or invalid')
        environments.append(observed)
    require(bool(environments) and all(value == environments[0] for value in environments),
            'Parent arms do not share one numeric environment')
    return environments[0]


def validated_cell(config, plan, root, cell_id):
    from benchmarks.regression.user_report import _validate_cell
    cell = selected(plan, cell_id)
    root = Path(root)
    row, evidence = _validate_cell(cell, root, require_observed_schedule=True)
    receipt = read(root / cell['receipt'])
    require(receipt['matrix_sha256'] == sha(root / 'matrix.json'), 'Matrix byte binding differs')
    require(read(root / 'matrix.json') == plan['matrix'], 'Full public matrix changed')
    require(receipt['input_archive_sha256'] == FIXTURE and receipt['cases'] == config['request_cases'],
            'Fixture, paired seeds, prompts or history differ')
    require(receipt['interpreter'] == config['interpreter'] and receipt['torch'] == config['torch_version'],
            'Different installed interpreter/Torch')
    require(receipt['numeric_environment'] == parent_numeric_environment(config),
            'Different numeric environment')
    require(receipt['default_schedule'] == config['parent_plan']['matrix']['cells'][0]['effective_schedule']['nfe'],
            'Full checkpoint declaration changed')
    precision = cell['expected_runtime_kwargs'].get('precision', 'native')
    require(receipt['precision'] == precision, 'Different requested precision')
    if precision == 'fp8':
        weights = receipt.get('e4m3_tensors')
        require(isinstance(weights, list) and bool(weights) and all(
            isinstance(v.get('path'), str) and len(v.get('shape', [])) == 2
            and all(type(n) is int and n > 0 for n in v['shape']) for v in weights),
            'No actual E4M3 projection evidence from the pinned capture code')
    else:
        require(not receipt.get('e4m3_tensors'), 'Native-precision candidate reports FP8 weights')
    gpu(receipt)
    require(receipt.get('sources'), 'No loaded source inventory')
    for path, digest in receipt['sources'].items():
        require(sha(path) == digest, 'Loaded source changed: ' + path)
    return row, evidence, receipt


def admit(config, config_path, prepared, output):
    from benchmarks.regression.reproduce import validate_bundle, child_environment
    completion = parent_gate(config)
    parent = Path(config['parent_pipeline']) / 'capture'
    parent_plan, _ = validate_bundle(parent)
    candidate, preparation = validate_bundle(prepared)
    require(parent_plan == config['parent_plan'], 'Parent public plan differs')
    require(candidate == config['candidate_plan'], 'Candidate public plan differs')
    require(expected_cases(config['family'], Path(prepared) / 'inputs/recorded_inputs_v1.npz') == config['request_cases'],
            'Prepared request recipe differs')
    sources = installed_sources(config)
    dependencies = dependency_versions(config)
    rows = {}
    for cell in parent_plan['matrix']['cells']:
        row, _, receipt = validated_cell(config, parent_plan, parent, cell['id'])
        rows[cell['id']] = {'receipt_sha256': row['receipt']['sha256'], 'actions_sha256': receipt['actions_sha256']}
    cell = selected(candidate, config['cell_id'])
    environment = child_environment(candidate, cell, preparation, inherited=os.environ)
    require('torch' not in sys.modules, 'CPU admission imported Torch')
    write(output, {'schema': 'instinctflash.task_owned_mode_admission.v1', 'status': 'passed',
                   'config_sha256': sha(config_path), 'parent_completion_sha256': sha(Path(config['parent_pipeline']) / 'completion.json'),
                   'parent_config_sha256': completion['config_sha256'], 'parent_cells': rows,
                   'parent_matrix_sha256': sha(parent / 'matrix.json'), 'candidate_matrix_sha256': sha(Path(prepared) / 'matrix.json'),
                   'candidate_plan_sha256': sha(Path(prepared) / 'plan.json'), 'installed_sources': sources,
                   'dependency_versions': dependencies,
                   'numeric_environment': parent_numeric_environment(config),
                   'interpreter': sys.executable, 'torch_imported': False})
    # Transfer only changes made by the public helper, not inherited credentials.
    path = Path(output).with_name('capture_environment.json')
    with path.open('x') as handle:
        os.chmod(path, 0o600)
        json.dump({'remove': sorted(set(os.environ) - set(environment)),
                   'set': {key: value for key, value in environment.items() if os.environ.get(key) != value}}, handle)


def compare(left, right, left_receipt, right_receipt, *, same_schedule):
    from benchmarks.regression.user_report import _action_difference
    keys = ('model_id', 'revision', 'device', 'torch', 'action_shape', 'requests',
            'primary_indices', 'timing_scope', 'input_contract')
    require(all(left[1][key] == right[1][key] for key in keys), 'Unpaired comparison protocol')
    require(left_receipt['default_schedule'] == right_receipt['default_schedule'], 'Checkpoint declaration differs')
    if same_schedule:
        require(left[1]['schedule'] == right[1]['schedule'] and left[1]['guidance'] == right[1]['guidance'],
                'Expected matching sampler/guidance')
    indices = left[1]['primary_indices']
    return {'kind': 'matched_schedule' if same_schedule else 'changed_schedule_tradeoff',
            'baseline_p50_ms': left[0]['primary']['p50_ms'], 'candidate_p50_ms': right[0]['primary']['p50_ms'],
            'ratio_of_p50': left[0]['primary']['p50_ms'] / right[0]['primary']['p50_ms'],
            'median_paired_ratio': statistics.median(left[1]['timings'][i] / right[1]['timings'][i] for i in indices),
            'paired_samples': len(indices), 'actions': _action_difference(left[1]['actions'], right[1]['actions']),
            'task_quality_validated': False}


def validate_capture(config, config_path, prepared, run, admission_path, output):
    from benchmarks.regression.reproduce import validate_bundle
    parent_gate(config)
    admission = read(admission_path)
    require(admission['status'] == 'passed' and admission['config_sha256'] == sha(config_path), 'Admission/config differs')
    require(admission['parent_completion_sha256'] == sha(Path(config['parent_pipeline']) / 'completion.json'), 'Parent completion changed')
    require(installed_sources(config) == admission['installed_sources'], 'Installed sources changed during capture')
    require(dependency_versions(config) == admission['dependency_versions'], 'Installed dependencies changed during capture')
    plan, _ = validate_bundle(prepared)
    require(plan == config['candidate_plan'], 'Candidate plan changed')
    root = Path(run)
    candidate = validated_cell(config, plan, root, config['cell_id'])
    require(sha(root / 'matrix.json') == admission['candidate_matrix_sha256'], 'Candidate matrix changed')
    require({p.parent.name for p in (root / 'cells').glob('*/receipt.json')} == {config['cell_id']},
            'Unexpected additional capture cells')
    parent = Path(config['parent_pipeline']) / 'capture'
    parent_plan, _ = validate_bundle(parent)
    require(parent_plan == config['parent_plan'] and sha(parent / 'matrix.json') == admission['parent_matrix_sha256'], 'Parent matrix changed')
    baselines = [config['family'] + '-eager_native', config['family'] + '-runtime_selected']
    if config['family'] == 'dreamzero':
        baselines.append('dreamzero-dynamic-fp8')
    comparisons = {}
    for cell_id in baselines:
        baseline = validated_cell(config, parent_plan, parent, cell_id)
        require(baseline[0]['receipt']['sha256'] == admission['parent_cells'][cell_id]['receipt_sha256'], 'Parent receipt changed')
        require(baseline[2]['actions_sha256'] == admission['parent_cells'][cell_id]['actions_sha256'], 'Parent action bytes changed')
        same = config['family'] != 'dreamzero' or cell_id == 'dreamzero-dynamic-fp8'
        comparisons[cell_id] = compare(baseline, candidate, baseline[2], candidate[2], same_schedule=same)
    write(output, {'schema': 'instinctflash.task_owned_mode_validation.v1', 'status': 'passed_supplement_only',
                   'config_sha256': sha(config_path), 'admission_sha256': sha(admission_path),
                   'full_public_matrix_sha256': sha(root / 'matrix.json'), 'captured_cells': [config['cell_id']],
                   'uncaptured_candidate_plan_cells': [c['id'] for c in plan['matrix']['cells'] if c['id'] != config['cell_id']],
                   'candidate': candidate[0], 'comparisons': comparisons,
                   'full_public_run_completed': False, 'task_quality_validated': False, 'publication_ready': False})


def validate_serve(config, prepared, root, admission_path, output):
    import numpy as np
    from benchmarks.regression.serve_smoke import validate_metadata
    from benchmarks.regression.reproduce import validate_bundle
    root = Path(root)
    plan, _ = validate_bundle(prepared)
    require(plan == config['candidate_plan'], 'Serving preparation changed')
    cell = selected(plan, config['cell_id'])
    receipt = read(root / 'receipt.json')
    require(receipt['status'] == 'passed' and receipt['server_exit_code'] == 0, 'WebSocket/shutdown failed')
    require(receipt['cell_id'] == config['cell_id'] and receipt['checkpoint'] == plan['checkpoint'], 'Wrong served checkpoint/mode')
    require(receipt['fixture_sha256'] == FIXTURE and receipt['plan_sha256'] == sha(Path(prepared) / 'plan.json'), 'Serving plan/fixture mismatch')
    require(receipt['seed'] == 9173 and receipt['latency_benchmark'] is False and receipt['interpreter'] == config['interpreter'], 'Wrong serving seed/interpreter')
    gpu(receipt)
    validate_metadata(receipt['metadata'], cell)
    require([{k: call[k] for k in ('episode', 'cycle', 'request_sha256')} for call in receipt['calls']] == config['serve_request_cases'],
            'Serving request/reset/history mismatch')
    require(sha(root / 'actions.npz') == receipt['action_archive_sha256'], 'Serving action archive changed')
    with np.load(root / 'actions.npz', allow_pickle=False) as data:
        require(list(data['actions'].shape) == [6, *cell['action_shape']] and np.isfinite(data['actions']).all(), 'Serving action shape/nonfinite')
    require(sha(root / 'server_device.json') == receipt['server_device_sha256'], 'Server device receipt changed')
    require(installed_sources(config) == read(admission_path)['installed_sources'], 'Installed sources changed during serving')
    require(dependency_versions(config) == read(admission_path)['dependency_versions'], 'Installed dependencies changed during serving')
    write(output, {'status': 'passed_six_request_transport', 'receipt_sha256': sha(root / 'receipt.json'),
                   'latency_benchmark': False, 'task_quality_validated': False})


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('action', choices=('admit', 'capture', 'serve'))
    for name in ('config', 'prepared', 'output'):
        parser.add_argument('--' + name, required=True, type=Path)
    parser.add_argument('--run', type=Path)
    parser.add_argument('--admission', type=Path)
    args = parser.parse_args()
    config = read(args.config)
    if args.action == 'admit':
        admit(config, args.config, args.prepared, args.output)
    elif args.action == 'capture':
        validate_capture(config, args.config, args.prepared, args.run, args.admission, args.output)
    else:
        validate_serve(config, args.prepared, args.run, args.admission, args.output)


if __name__ == '__main__':
    main()
