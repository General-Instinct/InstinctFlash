"""Task-owned bounded process control copied from the CPU-tested VA supplement."""
from __future__ import annotations
import datetime
import hashlib
import os
from pathlib import Path
import signal
import subprocess

COMMIT = "c5c1cbbdbc1579258be41cf1c621829dfeeb80f3"
GPU = "GPU-cc9b08f5-0925-2946-48f6-a576bc6b28bc"
TARGET = {"name": "rtx4090", "capability": [8, 9]}
ROOT = Path("/workspace/ifl_rtx4090_580_20260916")
FIXTURE = "37843e22fa6dd9a2abf2bae390ccb8e5c4319446e3d3fab5d0d477860065f411"


def require(value,message):
    if not value:raise ValueError(message)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(4<<20),b''):digest.update(block)
    return digest.hexdigest()

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def proc(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'parent':int(fields[1]),'start':fields[19],'state':fields[0]}
    except FileNotFoundError:return None

def stop_owned_tree(child):
    # A WebSocket server has its own session. Save exact descendant identities
    # before stopping the parent so cleanup cannot miss its separate process group.
    tree={child.pid:proc(child.pid)}
    records={int(p.name):proc(int(p.name)) for p in Path('/proc').iterdir() if p.name.isdigit()}
    changed=True
    while changed:
        changed=False
        for pid,row in records.items():
            if row and row['parent'] in tree and pid not in tree:tree[pid]=row;changed=True
    def send(sig):
        for pid,row in reversed(list(tree.items())):
            current=proc(pid)
            if row and current and current['start']==row['start'] and current['state']!='Z':
                try:os.kill(pid,sig)
                except ProcessLookupError:pass
    send(signal.SIGTERM)
    try:child.wait(timeout=15)
    except subprocess.TimeoutExpired:pass
    send(signal.SIGKILL)
    child.wait(timeout=10)


def admit_installed(config, installed):
    require(config['family'] == 'edge' and config['mode'] == 'numeric',
            'This successor admits only Edge NUMERIC')
    root = Path(config['family_root'])
    require(sha(root / 'completion.json') == config['bootstrap_completion_sha256'],
            'Actual installed bootstrap receipt changed')
    require(installed.get('CPU_doctor_passed') is True
            and installed.get('family') == 'edge'
            and installed.get('deployment_target') == 'rtx4090',
            'Installed CPU admission differs')
    require(installed['wheels'] == config['installed_wheels'], 'Installed wheel inventory changed')
    for wheel in config['installed_wheels']:
        path = Path(wheel['path'])
        require(path.is_relative_to(root / 'wheels') and sha(path) == wheel['sha256'],
                'Installed original source-wheel bytes changed')
    native = installed['native_tool_preparation']
    require(native['environment'] == config['native_tool_environment']
            and native.get('first_preparation_offline') is True, 'Pinned native-tool environment changed')
    compiler = installed['compiler_preparation']
    require(compiler['environment'] == config['compiler_environment']
            and compiler.get('returncode') == 0, 'Pinned compiler environment changed')
    return {'bootstrap_completion_sha256': config['bootstrap_completion_sha256'],
            'source_wheels_verified': len(config['installed_wheels'])}


def restore_installed_environment(environment, installed, config):
    require(installed['native_tool_preparation']['environment'] == config['native_tool_environment']
            and installed['compiler_preparation']['environment'] == config['compiler_environment'],
            'Native-tool/compiler environment differs from actual frozen bootstrap')
    environment.update(config['native_tool_environment'])
    environment.update(config['compiler_environment'])
    return environment
