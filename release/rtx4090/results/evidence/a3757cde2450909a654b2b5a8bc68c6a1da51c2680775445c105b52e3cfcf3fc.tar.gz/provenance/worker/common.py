"""Task-owned bounded process control copied from the CPU-tested VA supplement."""
from __future__ import annotations
import datetime
import hashlib
import os
from pathlib import Path
import signal
import subprocess

COMMIT = "a0dc86cc7447ce894663540adf49cfb6e96af97d"
GPU = "GPU-34f3da96-a7b2-ed04-c766-05e7862d940c"
TARGET = {"name": "rtx4090", "capability": [8, 9]}
ROOT = Path("/workspace/ifl_rtx4090_20260916")
FIXTURE = "37843e22fa6dd9a2abf2bae390ccb8e5c4319446e3d3fab5d0d477860065f411"


def require(value,message):
    if not value:raise ValueError(message)

def sha(path):
    digest=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for block in iter(lambda:handle.read(4<<20),b''):digest.update(block)
    return digest.hexdigest()

def utc():return datetime.datetime.now(datetime.timezone.utc).isoformat()

def proc(pid):
    try:
        fields=Path('/proc',str(pid),'stat').read_text().rsplit(')',1)[1].split()
        return {'pid':pid,'parent':int(fields[1]),'start':fields[19],'state':fields[0]}
    except FileNotFoundError:return None

def stop_owned_tree(child):
    # A WebSocket server has its own session. Save exact descendant identities
    # before stopping the parent so cleanup cannot miss its separate process group.
    tree={child.pid:proc(child.pid)}
    records={int(p.name):proc(int(p.name)) for p in Path('/proc').iterdir() if p.name.isdigit()}
    changed=True
    while changed:
        changed=False
        for pid,row in records.items():
            if row and row['parent'] in tree and pid not in tree:tree[pid]=row;changed=True
    def send(sig):
        for pid,row in reversed(list(tree.items())):
            current=proc(pid)
            if row and current and current['start']==row['start'] and current['state']!='Z':
                try:os.kill(pid,sig)
                except ProcessLookupError:pass
    send(signal.SIGTERM)
    try:child.wait(timeout=15)
    except subprocess.TimeoutExpired:pass
    send(signal.SIGKILL)
    child.wait(timeout=10)
